import StudentOnboardingQuiz from "../components/StudentOnboardingQuiz";

interface StudentOnboardingProps {
  onComplete: (data: any) => void;
  onBack: () => void;
  onSignIn: () => void;
}

export default function StudentOnboarding({ onComplete, onBack, onSignIn }: StudentOnboardingProps) {
  return (
    <StudentOnboardingQuiz 
      onComplete={onComplete}
      onBack={onBack}
      onSignIn={onSignIn}
    />
  );
}
