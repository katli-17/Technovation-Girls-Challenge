import React, { useState } from "react";
import { motion } from "motion/react";
import { Mail, ArrowLeft, Send, CheckCircle, Lock, UserPlus, LogIn } from "lucide-react";
import { cn, validateEmail } from "../lib/utils";

interface AuthMethodSelectorProps {
  onSelectProvider: (method: "email-login" | "email-register" | "google", data?: any) => void;
  onBack: () => void;
}

export default function AuthMethodSelector({ onSelectProvider, onBack }: AuthMethodSelectorProps) {
  const [view, setView] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      setError("Please enter a valid email address with '@'.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }
    
    setIsLoading(true);
    try {
      if (view === "register") {
        if (password !== confirmPassword) {
          setError("Passwords do not match.");
          setIsLoading(false);
          return;
        }
        setError("");
        await onSelectProvider("email-register", { email, password });
      } else {
        setError("");
        await onSelectProvider("email-login", { email, password });
      }
    } catch (err: any) {
      if (err.code === "auth/invalid-credential") {
        setError("Invalid email or password.");
      } else if (err.code === "auth/email-already-in-use") {
        setError("This email is already in use. Please sign in.");
      } else if (err.code === "auth/weak-password") {
        setError("Password is too weak. Please use a stronger password.");
      } else {
        setError(err.message || "An error occurred during authentication.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-radiant-bg flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-white rounded-[40px] p-8 shadow-xl space-y-8"
      >
        <header className="text-center">
          <button 
            onClick={onBack}
            className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-radiant-pink transition-colors mb-6"
          >
            <ArrowLeft size={14} />
            Go Back
          </button>
          
          <div className="flex bg-gray-50 p-1 rounded-2xl mb-6 shadow-inner">
            <button
              onClick={() => { setView("login"); setError(""); }}
              className={cn(
                "flex-1 py-3 text-sm font-bold rounded-xl transition-all",
                view === "login" ? "bg-white text-gray-900 shadow-sm" : "text-gray-400 hover:text-gray-600"
              )}
            >
              Sign In
            </button>
            <button
              onClick={() => { setView("register"); setError(""); }}
              className={cn(
                "flex-1 py-3 text-sm font-bold rounded-xl transition-all",
                view === "register" ? "bg-white text-gray-900 shadow-sm" : "text-gray-400 hover:text-gray-600"
              )}
            >
              Register
            </button>
          </div>

          <h1 className="text-3xl font-serif">
            {view === "login" ? "Welcome Back" : "Create Account"}
          </h1>
          <p className="text-gray-500 italic mt-2">
            {view === "login" ? "Enter your email and password to sign in." : "Create a new account with your email and password."}
          </p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-2">Email Address</label>
            <div className="relative group">
              <Mail className={cn("absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-radiant-pink transition-colors", error && error.includes("email") && "text-red-400")} size={18} />
              <input 
                type="email"
                required
                placeholder="name@example.com"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setError("");
                }}
                className={cn(
                  "w-full pl-12 pr-4 py-4 rounded-2xl border border-black/5 bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 transition-all text-sm",
                  error && error.includes("email") && "border-red-500 focus:ring-red-500/10"
                )}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-2">Password</label>
            <div className="relative group">
              <Lock className={cn("absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-radiant-pink transition-colors", error && error.includes("Password") && "text-red-400")} size={18} />
              <input 
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError("");
                }}
                className={cn(
                  "w-full pl-12 pr-4 py-4 rounded-2xl border border-black/5 bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 transition-all text-sm",
                  error && error.includes("Password") && "border-red-500 focus:ring-red-500/10"
                )}
              />
            </div>
          </div>

          {view === "register" && (
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-2">Confirm Password</label>
              <div className="relative group">
                <Lock className={cn("absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-radiant-pink transition-colors", error && error.includes("match") && "text-red-400")} size={18} />
                <input 
                  type="password"
                  required
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    setError("");
                  }}
                  className={cn(
                    "w-full pl-12 pr-4 py-4 rounded-2xl border border-black/5 bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 transition-all text-sm",
                    error && error.includes("match") && "border-red-500 focus:ring-red-500/10"
                  )}
                />
              </div>
            </div>
          )}

          {error && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest px-2 text-center mt-2">{error}</p>}

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full py-4 bg-radiant-pink text-white rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-radiant-pink/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
          >
            {isLoading ? "Please wait..." : view === "login" ? <><LogIn size={14} /> Sign In</> : <><UserPlus size={14} /> Create Account</>}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
