import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, ArrowLeft, Sparkles, CheckCircle2, Info } from "lucide-react";
import { cn } from "@/src/lib/utils";

interface StudentOnboardingQuizProps {
  onComplete: (data: any) => void;
  onBack: () => void;
  onSignIn?: () => void;
}

interface Option {
  id: string;
  text: string;
  value: string;
  info?: string;
}

interface Question {
  id: string;
  question: string;
  options?: Option[];
  type?: "text" | "scroll_select" | "challenge" | "info";
  placeholder?: string;
  condition?: (answers: any) => boolean;
  footer?: string;
}

const QUESTIONS: Question[] = [
  {
    id: "transition_help",
    question: "Now let's customize how we can help you ✨",
    type: "info",
    footer: "We'll ask a few questions to understand your needs better and tailor your Radiant experience.",
  },
  {
    id: "stress",
    question: "How often do you feel overwhelmed by stress or anxiety?",
    options: [
      { id: "A", text: "Almost every day — It's hard to focus", value: "daily" },
      { id: "B", text: "A few times a week — It comes and goes", value: "weekly" },
      { id: "C", text: "Rarely — I generally feel in control", value: "rarely" },
      { id: "D", text: "Almost never — I feel very balanced", value: "never" },
    ], 
  },
  {
    id: "confidence",
    question: "How would you describe your current level of self-confidence?",
    options: [
      { id: "A", text: "Low — I often doubt my abilities and worth", value: "low" },
      { id: "B", text: "Medium — I have good days and bad days", value: "medium" },
      { id: "C", text: "High — I feel capable and self-assured", value: "high" },
      { id: "D", text: "Very High — I'm ready to lead and inspire", value: "very_high" },
    ], 
  },
  {
    id: "goal",
    question: "What is your primary focus for this journey?",
    options: [
      { id: "A", text: "Self-Discovery — Understanding my emotions", value: "discovery" },
      { id: "B", text: "Growth — Building resilience and social skills", value: "confidence" },
      { id: "C", text: "Connection — Finding a supportive community", value: "community" },
      { id: "D", text: "Awareness — Learning about mental wellness", value: "tracking" },
      { id: "E", text: "Not sure yet", value: "dontKnow"},
    ],
  },
  {
    id: "coping",
    question: "What is your typical response to difficult emotions?",
    options: [
      { id: "A", text: "Reflection — I write or create to process", value: "journaling" },
      { id: "B", text: "Outreach — I talk to someone I trust", value: "talking" },
      { id: "C", text: "Internalization — I keep it to myself", value: "internalizing" },
      { id: "D", text: "Action — I find a hobby or distraction", value: "distraction" },
    ], 
  },
  {
    id: "community_support",
    question: "How would you rate your current support system?",
    options: [
      { id: "A", text: "Strong — I have people I can always count on", value: "yes" },
      { id: "B", text: "Limited — I often feel lonely or misunderstood", value: "no" },
      { id: "C", text: "Growing — I have some support but want more", value: "some" },
      { id: "D", text: "Unsure — I'm still looking for my tribe", value: "unsure" },
    ], 
  },
  {
    id: "triggers",
    question: "What usually triggers your stress the most?",
    options: [
      { id: "A", text: "Academic Pressure — Grades and expectations", value: "school" },
      { id: "B", text: "Social Dynamics — Friendships and fitting in", value: "social" },
      { id: "C", text: "Home Life — Family relationships and stress", value: "family" },
      { id: "D", text: "The Future — Uncertainty and big decisions", value: "future" },
    ],
  },
  {
    id: "self_image",
    question: "How do you perceive your own self-image?",
    options: [
      { id: "A", text: "Positive — I'm proud of who I'm becoming", value: "positive" },
      { id: "B", text: "Comparison-Heavy — I often look at others", value: "comparison" },
      { id: "C", text: "Invisible — I feel like I don't belong", value: "invisible" },
      { id: "D", text: "Evolving — I'm still discovering my identity", value: "exploring" },
    ],
  },
  {
    id: "school_attendance",
    question: "How often do you find it difficult to attend school?",
    options: [
      { id: "A", text: "Rarely — I attend almost every day", value: "rarely" },
      { id: "B", text: "Sometimes — A few days a month", value: "sometimes" },
      { id: "C", text: "Often — Once or twice a week", value: "often" },
      { id: "D", text: "Very Often — It's hard to go consistently", value: "very_often" },
    ],
  },
  {
    id: "challenge_breath",
    question: "Challenge: The Power Breath 🌬️",
    type: "challenge",
    footer: "Take 3 slow, deep breaths right now. Feel your shoulders drop and your mind clear.",
  },
  {
    id: "challenge_gratitude",
    question: "Challenge: The Gratitude Spark ✨",
    type: "challenge",
    footer: "Think of one thing you are truly grateful for today. It can be something small, like a warm drink or a kind word.",
  },
  {
    id: "challenge_smile",
    question: "Challenge: The Mirror Smile 😊",
    type: "challenge",
    footer: "If there's a mirror nearby, look at yourself and give a genuine smile. If not, just close your eyes and smile at the person you are becoming.",
  },
  {
    id: "challenge_kindness",
    question: "Challenge: The Kindness Seed 🌱",
    type: "challenge",
    footer: "Think of one kind thing you can say to yourself or someone else today. Kindness starts with you.",
  },
];

export default function StudentOnboardingQuiz({ onComplete, onBack, onSignIn }: StudentOnboardingQuizProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [name, setName] = useState("");
  const [textInput, setTextInput] = useState("");
  const [isFinished, setIsFinished] = useState(false);

  const handleNext = (overrideAnswers?: Record<string, string>) => {
    const currentAnswers = overrideAnswers || answers;
    let nextStep = currentStep + 1;
    
    // Skip questions if condition is not met
    while (nextStep <= QUESTIONS.length && QUESTIONS[nextStep - 1]?.condition && !QUESTIONS[nextStep - 1].condition(currentAnswers)) {
      nextStep++;
    }

    if (nextStep <= QUESTIONS.length) {
      setCurrentStep(nextStep);
      // Reset text input for next step if it's a text type
      const nextQuestion = QUESTIONS[nextStep - 1];
      if (nextQuestion?.type === "text") {
        setTextInput(currentAnswers[nextQuestion.id] || "");
      }
    } else {
      setIsFinished(true);
    }
  };

  const handleBack = () => {
    let prevStep = currentStep - 1;
    
    // Skip questions if condition is not met
    while (prevStep > 0 && QUESTIONS[prevStep - 1]?.condition && !QUESTIONS[prevStep - 1].condition(answers)) {
      prevStep--;
    }

    if (prevStep >= 0) {
      setCurrentStep(prevStep);
      // Set text input for previous step if it's a text type
      const prevQuestion = QUESTIONS[prevStep - 1];
      if (prevQuestion?.type === "text") {
        setTextInput(answers[prevQuestion.id] || "");
      }
    } else {
      onBack();
    }
  };

  const handleOptionSelect = (questionId: string, value: string) => {
    const newAnswers = { ...answers, [questionId]: value };
    setAnswers(newAnswers);
    setTimeout(() => handleNext(newAnswers), 300);
  };

  const handleTextSubmit = () => {
    const questionId = QUESTIONS[currentStep - 1].id;
    const newAnswers = { ...answers, [questionId]: textInput };
    setAnswers(newAnswers);
    handleNext(newAnswers);
  };

  const handleChallengeComplete = () => {
    const questionId = QUESTIONS[currentStep - 1].id;
    const newAnswers = { ...answers, [questionId]: "completed" };
    setAnswers(newAnswers);
    handleNext(newAnswers);
  };

  const progress = ((currentStep + 1) / (QUESTIONS.length + 1)) * 100;

  if (isFinished) {
    return (
      <div className="min-h-screen bg-radiant-bg flex flex-col items-center justify-center px-6 py-12 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-20 h-20 bg-radiant-pink rounded-full flex items-center justify-center text-white mb-8 shadow-xl"
        >
          <CheckCircle2 size={40} />
        </motion.div>
        <h2 className="text-4xl font-serif mb-4">You're all set, {name || "Radiant"}!</h2>
        <p className="text-gray-600 mb-12 max-w-xs mx-auto">
          We've personalized your experience based on your answers. Ready to start your journey?
        </p>
        <button
          onClick={() => onComplete({ name, answers })}
          className="w-full max-w-xs bg-radiant-pink text-white py-5 rounded-full font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-shadow active:scale-95"
        >
          Let's Start
          <ArrowRight size={18} />
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-radiant-bg px-6 py-16 flex flex-col">
      <div className="max-w-xl mx-auto w-full flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-12">
          <button
            onClick={handleBack}
            className={cn("p-3 text-gray-400 hover:text-radiant-pink transition-colors bg-white rounded-full shadow-sm border border-black/5")}
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex-1 mx-8 h-2 bg-gray-200 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className="h-full bg-radiant-pink"
            />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 w-12 text-right">
            {currentStep + 1} / {QUESTIONS.length + 1}
          </span>
        </div>

        <div className="mb-12 px-4">
          <h1 className="text-xs font-bold uppercase tracking-[0.3em] text-radiant-pink mb-3">Student Onboarding Quiz</h1>
          <p className="text-[11px] text-gray-400 uppercase tracking-widest leading-relaxed max-w-sm">
            Purpose: Identify stress patterns, emotional triggers, and coping methods to personalize your growth journey.
          </p>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex-1 flex flex-col justify-center px-2"
          >
            {currentStep === 0 ? (
              <div className="space-y-10">
                <div className="w-20 h-20 bg-radiant-pink/10 rounded-[32px] flex items-center justify-center text-radiant-pink mb-6">
                  <Sparkles size={40} />
                </div>
                <h2 className="text-5xl font-serif leading-tight tracking-tight">First, what should <br /> we call you?</h2>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name or nickname..."
                  className="w-full bg-white rounded-[32px] py-7 px-10 shadow-sm border border-black/5 focus:outline-none focus:ring-4 focus:ring-radiant-pink/10 text-xl transition-all"
                  autoFocus
                  onKeyDown={(e) => e.key === "Enter" && name.trim() && handleNext()}
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleNext}
                  disabled={!name.trim()}
                  className="w-full bg-radiant-pink text-white py-6 rounded-full font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-all active:scale-95 disabled:opacity-50"
                >
                  Continue
                  <ArrowRight size={18} />
                </motion.button>
              </div>
            ) : (
              <div className="space-y-10">
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-radiant-pink bg-radiant-pink/5 px-4 py-1.5 rounded-full inline-block">
                  {QUESTIONS[currentStep - 1].id.replace(/_/g, " ")}
                </span>
                <h2 className="text-4xl font-serif leading-tight tracking-tight">
                  {QUESTIONS[currentStep - 1].question}
                </h2>
                
                {QUESTIONS[currentStep - 1].type === "text" ? (
                  <div className="space-y-6">
                    <input
                      type="text"
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      placeholder={QUESTIONS[currentStep - 1].placeholder}
                      className="w-full bg-white rounded-[32px] py-7 px-10 shadow-sm border border-black/5 focus:outline-none focus:ring-4 focus:ring-radiant-pink/10 text-xl transition-all"
                      autoFocus
                      onKeyDown={(e) => e.key === "Enter" && textInput.trim() && handleTextSubmit()}
                    />
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleTextSubmit}
                      disabled={!textInput.trim()}
                      className="w-full bg-radiant-pink text-white py-6 rounded-full font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-all active:scale-95 disabled:opacity-50"
                    >
                      Continue
                      <ArrowRight size={18} />
                    </motion.button>
                  </div>
                ) : QUESTIONS[currentStep - 1].type === "scroll_select" ? (
                  <div className="grid gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                    {QUESTIONS[currentStep - 1].options?.map((option) => (
                      <motion.button
                        key={option.id}
                        whileHover={{ x: 10 }}
                        onClick={() => handleOptionSelect(QUESTIONS[currentStep - 1].id, option.value)}
                        className={cn(
                          "w-full bg-white p-6 rounded-[24px] text-left shadow-sm border border-black/5 flex items-center justify-between group hover:border-radiant-pink/30 transition-all active:scale-98",
                          answers[QUESTIONS[currentStep - 1].id] === option.value && "border-radiant-pink ring-4 ring-radiant-pink/5"
                        )}
                      >
                        <span className="text-lg font-medium text-gray-700 pr-4">{option.text}</span>
                        <div className={cn(
                          "w-6 h-6 rounded-full border-2 border-gray-100 flex items-center justify-center transition-all shrink-0",
                          answers[QUESTIONS[currentStep - 1].id] === option.value && "border-radiant-pink bg-radiant-pink text-white"
                        )}>
                          {answers[QUESTIONS[currentStep - 1].id] === option.value && <div className="w-2 h-2 bg-white rounded-full" />}
                        </div>
                      </motion.button>
                    ))}
                  </div>
                ) : QUESTIONS[currentStep - 1].type === "challenge" ? (
                  <div className="space-y-10 text-center py-8">
                    <div className="w-24 h-24 bg-radiant-pink/10 rounded-full flex items-center justify-center mx-auto mb-6 text-radiant-pink">
                      <Sparkles size={48} />
                    </div>
                    <p className="text-xl text-gray-600 italic leading-relaxed">
                      {QUESTIONS[currentStep - 1].footer}
                    </p>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleChallengeComplete}
                      className="w-full bg-radiant-pink text-white py-6 rounded-full font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-all active:scale-95"
                    >
                      Challenge Completed
                      <CheckCircle2 size={18} />
                    </motion.button>
                  </div>
                ) : QUESTIONS[currentStep - 1].type === "info" ? (
                  <div className="space-y-10 text-center py-8">
                    <div className="w-24 h-24 bg-radiant-pink/10 rounded-full flex items-center justify-center mx-auto mb-6 text-radiant-pink">
                      <Sparkles size={48} />
                    </div>
                    <p className="text-xl text-gray-600 italic leading-relaxed">
                      {QUESTIONS[currentStep - 1].footer}
                    </p>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleNext()}
                      className="w-full bg-radiant-pink text-white py-6 rounded-full font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-all active:scale-95"
                    >
                      Continue
                      <ArrowRight size={18} />
                    </motion.button>
                  </div>
                ) : (
                  <div className="grid gap-5">
                    {QUESTIONS[currentStep - 1].options?.map((option) => (
                      <div key={option.id} className="relative group/item">
                        <motion.button
                          whileHover={{ x: 10 }}
                          onClick={() => handleOptionSelect(QUESTIONS[currentStep - 1].id, option.value)}
                          className={cn(
                            "w-full bg-white p-8 rounded-[32px] text-left shadow-sm border border-black/5 flex items-center justify-between group hover:border-radiant-pink/30 transition-all active:scale-98",
                            answers[QUESTIONS[currentStep - 1].id] === option.value && "border-radiant-pink ring-4 ring-radiant-pink/5"
                          )}
                        >
                          <span className="text-lg font-medium text-gray-700 pr-12">{option.text}</span>
                          <div className={cn(
                            "w-8 h-8 rounded-full border-2 border-gray-100 flex items-center justify-center transition-all shrink-0",
                            answers[QUESTIONS[currentStep - 1].id] === option.value && "border-radiant-pink bg-radiant-pink text-white"
                          )}>
                            {answers[QUESTIONS[currentStep - 1].id] === option.value && <div className="w-2.5 h-2.5 bg-white rounded-full" />}
                          </div>
                        </motion.button>
                        
                        {option.info && (
                          <div className="absolute right-20 top-1/2 -translate-y-1/2 flex items-center">
                            <div className="relative group/info">
                              <button className="p-2 text-gray-300 hover:text-radiant-pink transition-colors">
                                <Info size={20} />
                              </button>
                              
                              {/* Tooltip */}
                              <div className="absolute bottom-full right-0 mb-4 w-64 p-4 bg-gray-900 text-white text-xs rounded-2xl opacity-0 invisible group-hover/info:opacity-100 group-hover/info:visible transition-all z-50 shadow-xl pointer-events-none">
                                <div className="relative">
                                  {option.info}
                                  <div className="absolute top-full right-4 w-3 h-3 bg-gray-900 rotate-45 -translate-y-1.5" />
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                    
                    {QUESTIONS[currentStep - 1].footer && (
                      <p className="text-center text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-4">
                        {QUESTIONS[currentStep - 1].footer}
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
