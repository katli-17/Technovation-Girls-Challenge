import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import LandingPage from "./pages/LandingPage";
import RoleSelector from "./auth/RoleSelector";
import StudentDashboard from "./dashboards/StudentDashboard";
import SchoolDashboard from "./dashboards/SchoolDashboard";
import NGODashboard from "./dashboards/NGODashboard";
import AdminDashboard from "./dashboards/AdminDashboard";

// 🔥 ADD THESE
import StudentOnboarding from "./onboarding/StudentOnboarding";
import SchoolOnboarding from "./onboarding/SchoolOnboarding";
import NGOOnboarding from "./onboarding/NGOOnboarding";
import AuthMethodSelector from "./auth/AuthMethodSelector";

import { auth, db, signInWithGoogle, signGuestIn } from "./lib/firebase";
import { onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedRole, setSelectedRole] = useState(null);

  const [hasStarted, setHasStarted] = useState(false);
  const [showRoleSelector, setShowRoleSelector] = useState(false);
  const [showAuthSelector, setShowAuthSelector] = useState(false);
  const [onboardingAnswers, setOnboardingAnswers] = useState(null);

  // Step 0: Request Sign In UI
  const handleRequestSignIn = () => {
    setOnboardingAnswers(null); // Explicitly clear any pending onboarding
    setHasStarted(true); // Unmount landing page
    setShowAuthSelector(true);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const isAdmin = firebaseUser.email?.toLowerCase() === 'admin@radiantness.com';
          const userDoc = await getDoc(doc(db, "users", firebaseUser.uid));

          if (userDoc.exists()) {
            const data = userDoc.data();
            
            // Force Admin role if email matches
            if (isAdmin && data.userRole !== 'admin') {
              await setDoc(doc(db, "users", firebaseUser.uid), { userRole: 'admin' }, { merge: true });
              data.userRole = 'admin';
            }

            setUser({
              ...firebaseUser,
              ...data,
              role: isAdmin ? 'admin' : (data.userRole || null)
            });
          } else {
            if (isAdmin) {
              await setDoc(doc(db, "users", firebaseUser.uid), { 
                userRole: 'admin', 
                email: firebaseUser.email,
                createdAt: serverTimestamp() 
              }, { merge: true });
              setUser({ ...firebaseUser, role: 'admin' });
            } else {
              setUser(firebaseUser);
            }
          }
        } catch (error) {
          console.warn("Auth doc fetch error:", error);
          const isAdmin = firebaseUser.email?.toLowerCase() === 'admin@radiantness.com';
          setUser({ ...firebaseUser, role: isAdmin ? 'admin' : null });
        }
      } else {
        const localUserStr = localStorage.getItem("radiant_local_session");
        if (localUserStr) {
          const localUser = JSON.parse(localUserStr);
          setUser({ ...localUser, role: localUser.userRole });
        } else {
          setUser(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleGetStarted = () => {
    setHasStarted(true);
  };

  const handleGetStudentSupport = () => {
    setHasStarted(true);
    setSelectedRole("student");
  };

  // Step 1: Collector Onboarding answers
  const handleFinishOnboarding = (answers: any) => {
    setOnboardingAnswers(answers);
    setShowAuthSelector(true);
  };

  // Step 2: Handle chosen provider AND finalize setup
  const handleAuthAndFinish = async (method: "google" | "phone" | "email" | "email-login" | "email-register", data?: any) => {
    try {
      let currentUser = auth.currentUser;
      
      // If not logged in, handle authentication based on method
      if (!currentUser) {
        if (method === "google") {
          currentUser = await signInWithGoogle();
          setShowAuthSelector(false);
        } else if (method === "email-login") {
          const userCredential = await signInWithEmailAndPassword(auth, data.email, data.password);
          currentUser = userCredential.user;
          setShowAuthSelector(false);
        } else if (method === "email-register") {
          const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
          currentUser = userCredential.user;
          setShowAuthSelector(false);
        } else if (method === "email" || method === "phone") {
          try {
            currentUser = await signGuestIn();
          } catch (e: any) {
            // FALLBACK: If anonymous auth is disabled, simulate a local identity
            if (e.code === 'auth/admin-restricted-operation') {
              console.warn("Guest sign-in restricted. Using local session fallback.");
              currentUser = {
                uid: `local_${Date.now()}`,
                displayName: method === "email" ? data?.email : data?.phone,
                email: method === "email" ? data?.email : null,
                isLocalSession: true
              } as any;
              localStorage.setItem("radiant_local_session", JSON.stringify(currentUser));
            } else {
              throw e;
            }
          }
        }
      }

      const emailVal = data?.email || currentUser?.email || null;
      const phoneVal = data?.phone || null;

      if (currentUser && selectedRole) {
        const uid = currentUser.uid;
        const answers = onboardingAnswers;
        const isStudent = selectedRole === "student";
        
        // Extract display name based on role
        let displayName = currentUser.displayName || "Radiant User";
        if (selectedRole === "school" && answers?.school_basic?.schoolName) {
          displayName = answers.school_basic.schoolName;
        } else if (selectedRole === "ngo" && answers?.ngo_basic?.orgName) {
          displayName = answers.ngo_basic.orgName;
        } else if (selectedRole === "student" && answers?.name) {
          displayName = answers.name;
        }

        console.log("App: Saving user profile for UID:", uid, "Role:", selectedRole, "Data:", {
          userRole: selectedRole,
          displayName: displayName,
          onboardingData: answers
        });

        // 1. Save public profile
        await setDoc(
          doc(db, "users", uid),
          {
            userRole: selectedRole,
            uid: uid,
            displayName: displayName,
            photoURL: currentUser.photoURL,
            createdAt: serverTimestamp(),
            streak: 0,
            confidenceScore: 0,
            // Only store onboardingData in public profile if NOT a student
            ...(isStudent ? {} : { 
              onboardingData: answers, 
              email: emailVal,
              phone: phoneVal,
              isVerified: false // Both Schools and NGOs start as unverified
            })
          },
          { merge: true }
        );

        // 2. Save private details (Admin ONLY access)
        if (isStudent) {
          await setDoc(
            doc(db, "student_private_details", uid),
            {
              uid: uid,
              email: emailVal,
              phone: phoneVal,
              onboardingData: answers,
              updatedAt: serverTimestamp()
            }
          );
        }

        // 3. Update local user state to trigger dashboard transition
        const userDoc = await getDoc(doc(db, "users", uid));
        if (userDoc.exists()) {
          setUser({
            ...currentUser,
            ...userDoc.data(),
            role: selectedRole
          });
          setShowAuthSelector(false); // Clean up
        }
      }
    } catch (error: any) {
      console.error(error);
      throw error;
    }
  };

  // 🔄 Loading
  if (loading) return <div>Loading...</div>;

  const normalizeRole = (role: string) => {
    if (role === "ngo_business" || role === "ngo_requester") return "ngo";
    return role;
  };

  const role = user?.role ? normalizeRole(user.role) : null;

  const renderDashboard = () => {
    if (!role) return <div>No Role Assigned</div>;
    switch (role) {
      case "student":
        return <StudentDashboard user={user} userName={user.onboardingData?.name || user.displayName || "Radiant"} onboardingData={user.onboardingData} />;
      case "school":
        return <SchoolDashboard user={user} />;
      case "ngo":
        return <NGODashboard user={user} />;
      case "admin":
        return <AdminDashboard />;
      default:
        return <div>Invalid Role: {role}</div>;
    }
  };

  return (
    <AnimatePresence mode="wait">
      {(() => {
        // 1. If we haven't started yet, show Landing
        if (!hasStarted && !user) {
          return (
            <motion.div key="landing">
              <LandingPage 
                onGetStarted={() => setHasStarted(true)} 
                onGetStudentSupport={() => { setHasStarted(true); setSelectedRole("student"); }}
                onLogin={handleRequestSignIn}
              />
            </motion.div>
          );
        }

        // 2. If logged in, prioritize Dashboards
        if (user) {
          if (role === "admin") return <motion.div key="admin-dashboard"><AdminDashboard /></motion.div>;
          if (role === "school") return <motion.div key="school-dashboard"><SchoolDashboard user={user} /></motion.div>;
          if (role === "ngo") return <motion.div key="ngo-dashboard"><NGODashboard user={user} /></motion.div>;
          if (role === "student") return <motion.div key="student-dashboard"><StudentDashboard user={user} userName={user.onboardingData?.name || user.displayName || "Radiant"} onboardingData={user.onboardingData} /></motion.div>;
          
          // If logged in but somehow role was stripped, allow them to re-select
          if (!selectedRole) {
            return (
              <motion.div key="role-selection">
                <RoleSelector onSelectRole={(r) => setSelectedRole(r.role)} />
              </motion.div>
            );
          }
        }

        // 3. If NOT logged in but started
        if (!user) {
          // Priority 1: If they are in the auth selection screen (Login/Register)
          if (showAuthSelector) {
            return (
              <motion.div key="auth-selection">
                <AuthMethodSelector 
                  onSelectProvider={handleAuthAndFinish} 
                  onBack={() => {
                    setShowAuthSelector(false);
                    // If they haven't picked a role yet, go back to landing
                    if (!selectedRole) setHasStarted(false);
                  }} 
                />
              </motion.div>
            );
          }

          // Priority 2: If they chose a role, show onboarding
          if (selectedRole) {
            return (
              <motion.div key="onboarding">
                {selectedRole === "student" && <StudentOnboarding onComplete={handleFinishOnboarding} onBack={() => setSelectedRole(null)} onSignIn={handleRequestSignIn} />}
                {selectedRole === "school" && <SchoolOnboarding onComplete={handleFinishOnboarding} onBack={() => setSelectedRole(null)} onSignIn={handleRequestSignIn} />}
                {selectedRole === "ngo" && <NGOOnboarding onComplete={handleFinishOnboarding} onBack={() => setSelectedRole(null)} onSignIn={handleRequestSignIn} />}
              </motion.div>
            );
          }

          // Default state after "Get Started": Pick a Role
          return (
            <motion.div key="role-selection">
              <RoleSelector onSelectRole={(r) => setSelectedRole(r.role)} />
            </motion.div>
          );
        }

        return <LandingPage onGetStarted={() => setHasStarted(true)} onLogin={handleRequestSignIn} />;
      })()}
    </AnimatePresence>
  );
}