// POST LOGIN / SIGNUP LOGIC:
// 1. User clicks "Get Started" or "Log In" -> App.tsx handles state (hasStarted=true or showAuthSelector=true)
// 2. User creates an account or logs in using their Email.
// 3. If a new user -> They see RoleSelector (Student / School / NGO).
// 4. They complete onboarding based on their role.
// 5. App redirects them to their respective dashboards:
//    - School Dashboard: manage inventory, request supplies
//    - NGO Portal: view school requests, track donation impact
//    - Student Dashboard: mood tracker, activities, forums, discreet requests
// 6. Returning user -> Logs in -> App fetches their role from Firestore -> Directly redirects to their dashboard.

import { motion } from "motion/react";
import { 
  Sparkles, Heart, Shield, Users, ArrowRight, CheckCircle, Package, 
  Building2, School, HeartHandshake, MessageCircle, Clock, Cloud, Zap, Brain, Sun 
} from "lucide-react";

interface LandingPageProps {
  onGetStarted: () => void;
  onGetStudentSupport: () => void;
  onLogin?: () => void;
}

export default function LandingPage({ onGetStarted, onGetStudentSupport, onLogin }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans selection:bg-radiant-accent/20">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-radiant-pink rounded-lg flex items-center justify-center shadow-lg shadow-radiant-pink/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-gray-900">RadiantNess</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
            <a href="#roles" className="hover:text-radiant-accent transition-colors">For You</a>
            <a href="#ecosystem" className="hover:text-radiant-accent transition-colors">Ecosystem</a>
            <a href="#student" className="hover:text-radiant-accent transition-colors">Student Growth</a>
            <a href="#learn" className="hover:text-radiant-accent transition-colors">Learn</a>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={onLogin || onGetStarted} // Triggers login flow
              className="hidden md:block px-5 py-2 text-gray-900 border border-gray-300 rounded-full text-sm font-medium hover:bg-gray-50 transition-all active:scale-95"
            >
              Log In
            </button>
            <button 
              onClick={onGetStarted}
              className="px-5 py-2 bg-gray-900 text-white rounded-full text-sm font-medium hover:bg-gray-800 transition-all active:scale-95"
            >
              Get Started
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 relative overflow-hidden">
        <motion.div 
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.3, 0.2],
            x: ["-50%", "-48%", "-50%"],
            y: ["0%", "2%", "0%"]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-radiant-accent/20 blur-[120px] rounded-full -z-10" 
        />
        
        <div className="max-w-4xl mx-auto text-center relative">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.h1 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
              className="text-5xl md:text-7xl font-bold tracking-tight text-gray-900 mb-6 leading-[1.1]"
            >
              Your safe space to grow — <br />
              <span className="text-radiant-pink italic">and get what you need to succeed.</span>
            </motion.h1>
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.5, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="text-2xl md:text-3xl font-semibold text-gray-700 mb-6"
            >
              For students, schools, and NGOs. One platform. Real impact.
            </motion.h2>
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.5, delay: 0.9, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10"
            >
              <button 
                onClick={onGetStarted}
                className="w-full sm:w-auto px-8 py-4 bg-radiant-pink text-white rounded-2xl font-semibold text-lg shadow-xl shadow-radiant-pink/20 hover:bg-radiant-pink/90 transition-all flex items-center justify-center gap-2 group"
              >
                Get Started <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={() => document.getElementById('roles')?.scrollIntoView({ behavior: 'smooth' })}
                className="w-full sm:w-auto px-8 py-4 bg-white text-gray-600 border border-gray-200 rounded-2xl font-semibold text-lg hover:bg-gray-50 transition-all"
              >
                Learn more
              </button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Three User Cards Section */}
      <section id="roles" className="py-16 bg-white relative z-10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold">Designed for every role</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Schools Card */}
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col items-start hover:shadow-xl hover:border-radiant-pink/30 transition-all group"
            >
              <div className="w-14 h-14 bg-radiant-pink/10 rounded-2xl flex items-center justify-center text-radiant-pink mb-6 group-hover:scale-110 transition-transform">
                <School size={28} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Schools</h3>
              <p className="text-gray-600 mb-6 flex-1">
                Request essential sanitary supplies, manage your inventory, and track the wellness needs of your students in one seamless dashboard.
              </p>
              <button onClick={() => document.getElementById('ecosystem')?.scrollIntoView({ behavior: 'smooth' })} className="text-radiant-pink font-semibold hover:text-radiant-pink/80 flex items-center gap-1 group/link">
                Learn more <ArrowRight size={16} className="group-hover/link:translate-x-1 transition-transform" />
              </button>
            </motion.div>

            {/* NGOs Card */}
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col items-start hover:shadow-xl hover:border-radiant-pink/30 transition-all group"
            >
              <div className="w-14 h-14 bg-radiant-pink/10 rounded-2xl flex items-center justify-center text-radiant-pink mb-6 group-hover:scale-110 transition-transform">
                <Building2 size={28} />
              </div>
              <h3 className="text-2xl font-bold mb-4">NGOs & Donors</h3>
              <p className="text-gray-600 mb-6 flex-1">
                Donate exactly what schools request, fulfill specific needs rapidly, and track the real-world impact of your contributions.
              </p>
              <button onClick={() => document.getElementById('ecosystem')?.scrollIntoView({ behavior: 'smooth' })} className="text-radiant-pink font-semibold hover:text-radiant-pink/80 flex items-center gap-1 group/link">
                Learn more <ArrowRight size={16} className="group-hover/link:translate-x-1 transition-transform" />
              </button>
            </motion.div>

            {/* Students Card */}
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col items-start hover:shadow-xl hover:border-radiant-pink/30 transition-all group"
            >
              <div className="w-14 h-14 bg-radiant-pink/10 rounded-2xl flex items-center justify-center text-radiant-pink mb-6 group-hover:scale-110 transition-transform">
                <Heart size={28} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Students</h3>
              <p className="text-gray-600 mb-6 flex-1">
                Track your moods, build confidence with daily activities, join a safe community, and discreetly request the supplies you need.
              </p>
              <button onClick={() => document.getElementById('student')?.scrollIntoView({ behavior: 'smooth' })} className="text-radiant-pink font-semibold hover:text-radiant-pink/80 flex items-center gap-1 group/link">
                Learn more <ArrowRight size={16} className="group-hover/link:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Impact / Problem Section */}
      <section className="py-24 bg-gray-900 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-radiant-pink/10 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2 }}
              className="relative"
            >
              <div className="aspect-square rounded-[3rem] bg-radiant-pink/5 flex items-center justify-center p-12">
                <div className="grid grid-cols-2 gap-6 w-full">
                  <div className="aspect-square bg-white/5 border border-white/10 rounded-3xl flex flex-col items-center justify-center p-6 text-center hover:bg-white/10 transition-all">
                    <Package className="w-10 h-10 text-radiant-pink mb-4" />
                    <span className="text-sm font-bold text-white">Essential Supplies</span>
                  </div>
                  <div className="aspect-square bg-white/5 border border-white/10 rounded-3xl flex flex-col items-center justify-center p-6 text-center mt-12 hover:bg-white/10 transition-all">
                    <School className="w-10 h-10 text-radiant-pink mb-4" />
                    <span className="text-sm font-bold text-white">School Success</span>
                  </div>
                  <div className="aspect-square bg-white/5 border border-white/10 rounded-3xl flex flex-col items-center justify-center p-6 text-center -mt-6 hover:bg-white/10 transition-all">
                    <Heart className="w-10 h-10 text-radiant-pink mb-4" />
                    <span className="text-sm font-bold text-white">Dignity & Care</span>
                  </div>
                  <div className="aspect-square bg-white/5 border border-white/10 rounded-3xl flex flex-col items-center justify-center p-6 text-center mt-6 hover:bg-white/10 transition-all">
                    <CheckCircle className="w-10 h-10 text-radiant-pink mb-4" />
                    <span className="text-sm font-bold text-white">Verified Impact</span>
                  </div>
                </div>
              </div>
            </motion.div>
            <div>
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-3xl md:text-5xl font-bold mb-8 leading-tight"
              >
                Dignity for every girl, <br />
                <span className="text-radiant-pink">success for every student.</span>
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="text-gray-400 text-lg mb-8 leading-relaxed"
              >
                We believe that no girl should miss school because she lacks access to basic sanitary products. Millions of students globally miss days of education due to period poverty. RadiantNess fixes this by connecting students in need with schools and NGOs to ensure they have the supplies required to attend class with confidence.
              </motion.p>
              
              <div className="bg-white/10 border border-white/20 p-6 rounded-2xl mb-10 text-center shadow-inner">
                <p className="text-xl md:text-2xl font-serif text-radiant-pink italic">
                  "Schools request. NGOs fulfill. Students succeed."
                </p>
              </div>

              <button 
                onClick={onGetStarted}
                className="px-10 py-4 bg-radiant-pink text-white rounded-2xl font-bold hover:bg-radiant-pink/90 transition-all shadow-xl shadow-radiant-pink/20"
              >
                Join the Mission
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stakeholders Section (NGOs, Schools) - Prominent */}
      <section id="ecosystem" className="py-24 bg-radiant-accent/5 relative">
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-5xl font-bold mb-6 text-gray-900"
            >
              The RadiantNess Ecosystem
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-gray-600 max-w-2xl mx-auto text-lg"
            >
              Our platform empowers educators and donors to collaborate efficiently, ensuring resources reach the girls who need them most.
            </motion.p>
          </div>
          
          <div className="flex flex-col gap-12 max-w-5xl mx-auto">
            {/* Schools */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="relative p-8 md:p-12 rounded-[2.5rem] bg-white border border-gray-100 shadow-xl hover:shadow-2xl transition-all flex flex-col md:flex-row items-center gap-8 md:gap-12"
            >
              <div className="flex-1 text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-4 mb-4">
                  <div className="w-16 h-16 shrink-0 bg-radiant-pink/10 text-radiant-pink rounded-2xl flex items-center justify-center">
                    <School className="w-8 h-8" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900">For Schools</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                  Ensure your students have what they need to succeed. Request sanitary products and other essentials directly through your dedicated school dashboard, manage internal inventory, and track the well-being of your students.
                </p>
                <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-8">
                  {["Request supplies easily", "Inventory management", "Student well-being tracking"].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-gray-700 bg-gray-50 px-4 py-2 rounded-full border border-gray-100">
                      <CheckCircle className="w-4 h-4 text-radiant-pink" />
                      {item}
                    </div>
                  ))}
                </div>
                <button onClick={onGetStarted} className="text-radiant-pink font-bold hover:text-radiant-pink/80 flex items-center gap-2 mx-auto md:mx-0">
                  Register your school <ArrowRight size={20} />
                </button>
              </div>
              <div className="w-full md:w-5/12 bg-gray-50 rounded-2xl p-6 border border-gray-100 shadow-inner">
                {/* Simulated Dashboard Preview */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                    <span className="font-bold text-gray-800">Inventory</span>
                    <span className="text-xs font-bold text-radiant-pink bg-radiant-pink/10 px-2 py-1 rounded-full">Low Stock</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2"><Package size={16} className="text-gray-500" /> <span className="text-sm">Sanitary Pads</span></div>
                    <span className="font-mono text-sm font-bold text-red-500">12 units</span>
                  </div>
                  <button className="w-full py-2 bg-gray-900 text-white rounded-lg text-xs font-bold uppercase tracking-wider">Request Restock</button>
                </div>
              </div>
            </motion.div>

            {/* NGOs & Businesses */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="relative p-8 md:p-12 rounded-[2.5rem] bg-white border border-gray-100 shadow-xl hover:shadow-2xl transition-all flex flex-col md:flex-row-reverse items-center gap-8 md:gap-12"
            >
              <div className="flex-1 text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-4 mb-4">
                  <div className="w-16 h-16 shrink-0 bg-radiant-pink/10 text-radiant-pink rounded-2xl flex items-center justify-center">
                    <Building2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900">For NGOs & Donors</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                  Partner with us to provide essential supplies. Your contributions directly support girls in need through our verified network of schools. Fulfill live requests and track your exact impact.
                </p>
                <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-8">
                  {["Direct supply donations", "Corporate sponsorship", "Verified impact tracking"].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-gray-700 bg-gray-50 px-4 py-2 rounded-full border border-gray-100">
                      <CheckCircle className="w-4 h-4 text-radiant-pink" />
                      {item}
                    </div>
                  ))}
                </div>
                <button onClick={onGetStarted} className="text-radiant-pink font-bold hover:text-radiant-pink/80 flex items-center gap-2 mx-auto md:mx-0">
                  Become a partner <ArrowRight size={20} />
                </button>
              </div>
              <div className="w-full md:w-5/12 bg-gray-50 rounded-2xl p-6 border border-gray-100 shadow-inner">
                 {/* Simulated Impact Preview */}
                 <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b border-gray-200">
                    <span className="font-bold text-gray-800">Your Impact</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-sm">
                    <p className="text-xs text-gray-500 mb-1">Students Supported</p>
                    <p className="text-2xl font-bold text-radiant-pink">1,240</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-sm">
                    <p className="text-xs text-gray-500 mb-1">Live Request</p>
                    <p className="text-sm font-medium">Lincoln High needs 500 pads</p>
                    <button className="mt-2 text-[10px] uppercase font-bold text-white bg-radiant-pink px-3 py-1 rounded-full">Fulfill Request</button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Student Section - Kept but moved lower */}
      <section id="student" className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <motion.h2 
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-5xl font-bold mb-6 text-gray-900"
            >
              For the Students
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-gray-600 max-w-2xl mx-auto text-lg mb-4"
            >
              We've created a private space for you to track your emotions, build resilience, and connect with peers safely.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="inline-block bg-radiant-pink/10 text-radiant-pink px-6 py-3 rounded-full font-bold shadow-sm"
            >
              Need supplies? Your school can request for you!
            </motion.div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {/* Mood Tracker */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="p-8 bg-gray-50 rounded-[2rem] border border-transparent hover:border-radiant-accent/20 hover:bg-white hover:shadow-xl transition-all"
            >
              <div className="text-4xl mb-6">😌</div>
              <h3 className="text-xl font-bold mb-3">Daily Mood Check-ins</h3>
              <p className="text-gray-600">Track your feelings daily to discover patterns and understand yourself better.</p>
            </motion.div>

            {/* Activities */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="p-8 bg-gray-50 rounded-[2rem] border border-transparent hover:border-radiant-accent/20 hover:bg-white hover:shadow-xl transition-all"
            >
              <div className="text-4xl mb-6">🌱</div>
              <h3 className="text-xl font-bold mb-3">Growth Activities</h3>
              <p className="text-gray-600">Bite-sized, counselor-designed exercises to build confidence and manage stress.</p>
            </motion.div>

            {/* Forums */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="p-8 bg-gray-50 rounded-[2rem] border border-transparent hover:border-radiant-accent/20 hover:bg-white hover:shadow-xl transition-all"
            >
              <div className="text-4xl mb-6">💬</div>
              <h3 className="text-xl font-bold mb-3">Safe Community Forums</h3>
              <p className="text-gray-600">Connect anonymously with other students going through similar experiences.</p>
            </motion.div>
          </div>
          
          <div className="text-center">
            <button onClick={onGetStarted} className="px-8 py-4 bg-gray-900 text-white rounded-2xl font-bold hover:bg-gray-800 transition-all shadow-lg">
              Explore Student Features
            </button>
          </div>
        </div>
      </section>

      {/* Learn Section */}
      <section id="learn" className="py-24 bg-gray-50 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Learn what school doesn't teach
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Real talk about mental health, relationships, identity, and navigating life as a teen — written by people who actually get it.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { category: "Mental Health", title: "Understanding Anxiety — What's Actually Happening in Your Brain", read: "5 min read" },
              { category: "Life Skills", title: "How to Have Hard Conversations Without Shutting Down", read: "4 min read" },
              { category: "Social Issues", title: "Navigating Online Drama — When to Speak Up and When to Log Off", read: "6 min read" },
              { category: "Identity", title: "It's Okay to Not Have It All Figured Out Yet", read: "3 min read" }
            ].map((article, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex flex-col p-6 bg-white rounded-3xl hover:shadow-xl hover:border-radiant-accent/20 border border-gray-100 transition-all cursor-pointer group"
              >
                <span className="text-xs font-bold text-radiant-accent uppercase mb-4">{article.category}</span>
                <h3 className="text-lg font-bold mb-auto leading-snug group-hover:text-radiant-accent transition-colors">
                  {article.title}
                </h3>
                <div className="flex items-center gap-2 text-sm text-gray-500 mt-6">
                  <Clock className="w-4 h-4" /> {article.read}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <motion.footer 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="py-20 border-t border-gray-100 bg-white"
      >
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-16">
            <div className="flex flex-col gap-6">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-radiant-pink rounded-lg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-2xl font-bold tracking-tight">RadiantNess</span>
              </div>
              <p className="text-gray-500 max-w-xs">
                Empowering the next generation with tools for emotional growth and health.
              </p>
              <div className="flex items-center gap-4">
                <button onClick={onGetStarted} className="text-sm font-bold text-gray-900 border border-gray-200 px-4 py-2 rounded-full hover:bg-gray-50 transition-all">Log In</button>
                <button onClick={onGetStarted} className="text-sm font-bold text-white bg-radiant-pink px-4 py-2 rounded-full hover:bg-radiant-pink/90 transition-all">Get Started</button>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-12">
              <div className="flex flex-col gap-4">
                <span className="font-bold text-gray-900 uppercase text-xs tracking-widest">App</span>
                <a href="#" className="text-gray-500 hover:text-radiant-accent transition-colors">About</a>
                <a href="#" className="text-gray-500 hover:text-radiant-accent transition-colors">Safety</a>
              </div>
              <div className="flex flex-col gap-4">
                <span className="font-bold text-gray-900 uppercase text-xs tracking-widest">Legal</span>
                <a href="#" className="text-gray-500 hover:text-radiant-accent transition-colors">Privacy</a>
                <a href="#" className="text-gray-500 hover:text-radiant-accent transition-colors">Terms</a>
              </div>
              <div className="flex flex-col gap-4">
                <span className="font-bold text-gray-900 uppercase text-xs tracking-widest">Support</span>
                <a href="#" className="text-gray-500 hover:text-radiant-accent transition-colors">Help</a>
                <a href="#" className="text-gray-500 hover:text-radiant-accent transition-colors">Contact</a>
              </div>
            </div>
          </div>
          <div className="pt-12 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-sm text-gray-500">© 2026 RadiantNess. All rights reserved.</p>
            <button 
              onClick={() => {
                if (window.confirm("Reset all app data and sign out? This will clear your local cache and session.")) {
                  import("../lib/firebase").then(m => m.resetUserData());
                }
              }}
              className="text-[10px] font-bold uppercase tracking-widest text-gray-300 hover:text-red-400 transition-colors"
            >
              Reset App Data
            </button>
            <div className="flex gap-6">
              <div className="w-5 h-5 bg-gray-100 rounded-full" />
              <div className="w-5 h-5 bg-gray-100 rounded-full" />
              <div className="w-5 h-5 bg-gray-100 rounded-full" />
            </div>
          </div>
        </div>
      </motion.footer>
    </div>
  );
}
