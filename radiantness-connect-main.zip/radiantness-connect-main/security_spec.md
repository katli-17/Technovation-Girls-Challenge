# Security Specification - RadiantNess

## Data Invariants
1. **User Identity**: Users can only read/write their own profiles.
2. **School Integrity**: Only schools can post announcements or request supplies.
3. **NGO Transparency**: Only NGOs can browse schools and log donations.
4. **Data Ownership**: Users can only delete their own documents (vulnerability being patched).
5. **Terminal States**: Orders/Donations cannot be modified once shipped/delivered (except by admin).

## The "Dirty Dozen" Payloads (WAF/Rule Breakers)

1. **Identity Spoofing**: `delete` document `users/victim_uid` as `attacker_uid`.
   - Expected: `PERMISSION_DENIED`
2. **Privilege Escalation**: `update` own user doc to set `role: 'admin'`.
   - Expected: `PERMISSION_DENIED`
3. **Shadow Field Injection**: `update` request with extra field `isVerified: true`.
   - Expected: `PERMISSION_DENIED`
4. **Resource Exhaustion**: `create` announcement with 5MB title.
   - Expected: `PERMISSION_DENIED` (via `.size()` constraints)
5. **ID Poisoning**: `create` document with ID containing `../`.
   - Expected: `PERMISSION_DENIED` (via `isValidId` helper)
6. **State Hijacking**: `update` request status from `pending` to `shipped` as a school.
   - Expected: `PERMISSION_DENIED` (only NGOs can ship)
7. **Cross-Tenant Leak**: NGO reading `student_private_details` of a user they don't support.
   - Expected: `PERMISSION_DENIED`
8. **Impersonation**: Posting chat message with `author: 'System Admin'` as a user.
   - Expected: `PERMISSION_DENIED` (requires `author` to match auth name/meta)
9. **Orphaned Writes**: Creating a mission for a user that doesn't exist.
   - Expected: `PERMISSION_DENIED` (via `exists()` check)
10. **Time Warp**: `create` doc with `createdAt` in the future.
    - Expected: `PERMISSION_DENIED` (must match `request.time`)
11. **PII Leak**: Reading `users` collection without a `where` clause on own UID.
    - Expected: `PERMISSION_DENIED` (Pillar 8: Query Enforcer)
12. **Recursive Cost Attack**: `list` query that triggers 100 `get()` calls in rules.
    - Expected: `PERMISSION_DENIED` (Pillar 8: Cost Optimization)
