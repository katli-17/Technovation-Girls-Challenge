import React from "react";
import { Sparkles, Heart, MessageCircle, Package, User, CheckCircle2, Megaphone, RefreshCw, Shield, BookOpen, Star, Compass, Smile, Zap, Coffee, Cloud, Sunrise, Globe, Users, Target, Clock } from "lucide-react";

export interface Page {
  title: string;
  content: React.ReactNode;
  icon?: React.ReactNode;
}

export interface ArticleContent {
  title: string;
  pages: Page[];
}

export interface Article {
  id: string;
  title: string;
  category: string;
  img: string;
  content: ArticleContent;
}

export const CATEGORIES = [
  "Mindset", "Health", "Social", "Growth", "Confidence", 
  "School", "Future", "Identity", "Physical", "Self-Love",
  "Boundaries", "Resilience", "Digital", "Leadership", "Emotions",
  "Creativity", "Hobby", "Wellness", "Communication", "Motivation"
];

export const ALL_ARTICLES: Article[] = [
  {
    id: "confidence_1",
    category: "Mindset",
    title: "The Silent Voice",
    img: "https://picsum.photos/seed/conf1/300/400",
    content: {
      title: "She Almost Stayed Silent Again...",
      pages: [
        {
          title: "The Racing Heart",
          icon: <Sparkles className="text-radiant-pink" />,
          content: (
            <>
              <p>The answer was right there, on the tip of her tongue. As the teacher looked around the room, she felt that familiar rush of heat and the thumping in her chest. She knew she had the right solution this time.</p>
              <p>But the old, familiar voice whispered: <span className="italic text-radiant-pink">“What if you’re wrong? What if they all turn and look at you? What if they laugh?”</span> The fear of judgment felt like a heavy weight, pulling her hand back down to her desk.</p>
            </>
          )
        },
        {
          title: "The Pivot",
          icon: <Target className="text-radiant-pink" />,
          content: (
            <>
              <p>Then, she remembered something she'd read: fear is just your brain trying to protect you from a danger that isn't really there. She took a slow, deep breath and made a choice.</p>
              <p>Instead of listening to the "what if I'm wrong," she focused on the "what if I'm right?" She raised her hand, her voice a little shaky but clear. She was right. The world didn't end; it actually opened up a little bit wider.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Confidence isn't the absence of fear; it's the decision that something else—your voice, your ideas, your growth—is more important than that fear.”</p>
        }
      ]
    }
  },
  {
    id: "period_1",
    category: "Physical",
    title: "Body Changes",
    img: "https://picsum.photos/seed/per1/300/400",
    content: {
      title: "Understanding Your Period",
      pages: [
        {
          title: "The Unfolding",
          icon: <Heart className="text-radiant-pink" />,
          content: (
            <>
              <p>She noticed it one morning and felt a sudden wave of panic. Her heart dropped, and a million questions raced through her mind. “Is this normal? Did I do something wrong? Why does no one talk about this?”</p>
              <p>The silence around the topic made the mystery feel like a burden. She felt alone in a body that seemed to be changing its own rules without her permission.</p>
            </>
          )
        },
        {
          title: "The Natural Rhythm",
          icon: <Shield className="text-radiant-pink" />,
          content: (
            <>
              <p>After talking to a trusted mentor, she learned the truth: her period is a powerful, natural cycle of renewal. It's her body's way of staying healthy and preparing for the future.</p>
              <p>The cramps and the mood shifts aren't "broken" parts of her; they are signs of a system that is working exactly as it should. Knowledge didn't just remove the fear—it gave her back her power.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Sparkles className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is your home, and your period is just one of the many beautiful ways it takes care of itself. Listen to it with kindness, not fear.”</p>
        }
      ]
    }
  },
  {
    id: "stress_1",
    category: "School",
    title: "Handling Pressure",
    img: "https://picsum.photos/seed/str1/300/400",
    content: {
      title: "It All Felt Like Too Much...",
      pages: [
        {
          title: "The Weight of the World",
          icon: <Megaphone className="text-radiant-pink" />,
          content: (
            <>
              <p>Books piled high on her desk. The blue light of her screen reflected in her tired eyes. Deadlines were closing in like walls, and every time she looked at her to-do list, her mind simply shut down.</p>
              <p>It wasn't that she didn't want to work; it was that she was so afraid of doing it poorly that she couldn't start at all. The pressure to be perfect was paralyzing her productivity.</p>
            </>
          )
        },
        {
          title: "The Power of One",
          icon: <RefreshCw className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop looking at the whole mountain and just look at the next step. She picked one small task—just one—and promised herself she'd only do that for ten minutes.</p>
              <p>Ten minutes turned into twenty. One task turned into two. The walls started to move back. She realized that she didn't have to be perfect; she just had to be present. Progress was enough.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <CheckCircle2 className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You don't have to see the whole staircase to take the first step. Focus on the progress of today, and let tomorrow take care of itself.”</p>
        }
      ]
    }
  },
  {
    id: "friends_1",
    category: "Social",
    title: "Healthy Circles",
    img: "https://picsum.photos/seed/fri1/300/400",
    content: {
      title: "She Didn't Feel Like Herself...",
      pages: [
        {
          title: "The Quiet Erasure",
          icon: <User className="text-radiant-pink" />,
          content: (
            <>
              <p>Lately, she noticed she was laughing at jokes that weren't funny and agreeing with things she didn't believe in. She was molding herself into a shape that fit their world, but her own edges were disappearing.</p>
              <p>Every time she left them, she felt a heavy, hollow exhaustion. She stayed because the thought of being alone felt scarier than the feeling of being lonely in a crowded room.</p>
            </>
          )
        },
        {
          title: "The Brave Exit",
          icon: <Compass className="text-radiant-pink" />,
          content: (
            <>
              <p>She took a deep breath and a step back. She started spending more time in her own company, rediscovering the things that actually made her smile. It was lonely at first, but it was a "good" kind of lonely.</p>
              <p>Slowly, she began to find people who didn't ask her to change. They liked her messy, her quiet, and her loud. She realized that a healthy friendship doesn't drain your batteries; it helps you recharge them.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Users className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your true friends will celebrate your light, not ask you to dim it. If a room doesn't feel safe for your soul, you are allowed to leave.”</p>
        }
      ]
    }
  },
  {
    id: "care_1",
    category: "Growth",
    title: "Emotional Rest",
    img: "https://picsum.photos/seed/car1/300/400",
    content: {
      title: "Always Busy... Still Tired",
      pages: [
        {
          title: "The Invisible Drain",
          icon: <RefreshCw className="text-radiant-pink" />,
          content: (
            <>
              <p>She checked every box on her list. She was productive, helpful, and "on" all day long. But as she sat on her bed that evening, she didn't just feel tired; she felt hollow. It was as if she'd been pouring water into everyone else's cup and forgot to check if her own was dry.</p>
              <p>She realized that emotional burnout doesn't always look like a collapse; sometimes it looks like a quiet, persistent numbness. She was giving her energy to everything—except herself.</p>
            </>
          )
        },
        {
          title: "The Quiet Recharge",
          icon: <Coffee className="text-radiant-pink" />,
          content: (
            <>
              <p>So, she started carving out small pockets of "nothing" time. Ten minutes of just listening to a song she loved. Five minutes of writing down her messiest thoughts. A slow walk where she didn't check her phone once.</p>
              <p>These weren't just breaks; they were a homecoming. She didn't have to change her whole life to feel better; she just had to make enough space for her soul to breathe again. Her peace was worth the pause.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Smile className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Rest is not a reward you earn after you're exhausted; it's a fundamental right that keeps you human. You are allowed to be your own priority.”</p>
        }
      ]
    }
  },
  {
    id: "body_1",
    category: "Identity",
    title: "The Comparison Trap",
    img: "https://picsum.photos/seed/bod1/300/400",
    content: {
      title: "She Kept Comparing...",
      pages: [
        {
          title: "The Infinite Scroll",
          icon: <Zap className="text-radiant-pink" />,
          content: (
            <>
              <p>Her thumb moved rhythmically across the screen, passing dozens of "perfect" lives. Perfect skin, perfect rooms, perfect vacations. With every scroll, she felt a little smaller, a little less shiny. She was comparing her behind-the-scenes to their highlight reels.</p>
              <p>She forgot that the images she saw were filtered, curated, and posed. She was measuring her worth against a mirage that didn't even exist in reality.</p>
            </>
          )
        },
        {
          title: "The Shift in Vision",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>One day, she decided to change her perspective. She stopped asking, "Why don't I look like that?" and started noticing everything her body was doing for her right now. Her legs that carried her, her hands that created, the heart that never stopped beating.</p>
              <p>She realized that beauty isn't a single destination you arrive at; it's the unique way you move through the world. Every "imperfection" was just a chapter of her story. She started to look at herself with fascination instead of criticism.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are a masterpiece in progress, not a product to be graded. Comparison is the thief of joy; gratitude is its guardian.”</p>
        }
      ]
    }
  },
  {
    id: "boundaries_1",
    category: "Boundaries",
    title: "Saying No",
    img: "https://picsum.photos/seed/bou1/300/400",
    content: {
      title: "She Said Yes to Everyone Else...",
      pages: [
        {
          title: "The People Pleaser",
          icon: <Shield className="text-radiant-pink" />,
          content: (
            <>
              <p>She was the one everyone could count on. Always ready to help, always saying "yes" to every favor, every extra task, and every social invite. She thought this made her a good person, but inside, she was crumbling from the sheer weight of it all.</p>
              <p>Every time she said "yes" to someone else out of guilt, she was silently saying "no" to her own needs. Her calendar was full of other people's priorities, and she had nothing left for herself.</p>
            </>
          )
        },
        {
          title: "The Freedom of No",
          icon: <CheckCircle2 className="text-radiant-pink" />,
          content: (
            <>
              <p>She finally tried it. A simple, "I can't do that right now, but thank you for asking." It felt terrifying at first, like she was breaking a secret law. But the world didn't fall apart. In fact, people respected her more.</p>
              <p>She realized that 'No' is not a rejection; it's a protection. It's the fence around her garden that keeps the most important things safe. Boundaries weren't walls to keep people out; they were gates to let the right things in.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Zap className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are not a limited resource for others to consume. Setting boundaries is the highest form of self-respect.”</p>
        }
      ]
    }
  },
  {
    id: "resilience_1",
    category: "Resilience",
    title: "Getting Back Up",
    img: "https://picsum.photos/seed/res1/300/400",
    content: {
      title: "The Fall",
      pages: [
        {
          title: "The Broken Dream",
          icon: <RefreshCw className="text-radiant-pink" />,
          content: (
            <>
              <p>The mistake felt final. She had worked so hard, and in one moment of bad judgment or poor timing, it all seemed to disappear. She sat in the wreckage of her effort, feeling like the word "failure" was now written across her forehead in permanent ink.</p>
              <p>She thought that success was a straight line, and because she had stumbled, she must have lost her way entirely. The shame was louder than the lesson.</p>
            </>
          )
        },
        {
          title: "The Dusting Off",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>But then she looked closer at the world. She saw that the most beautiful trees are those that have survived the harshest winters. She realized that failing is not a character flaw; it's a requirement for mastery.</p>
              <p>She brushed the dust off her knees and took a shaky step forward. This time, she wasn't starting from scratch; she was starting from experience. Her resilience wasn't about never falling—it was about the speed and grace with which she stood up again.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Star className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Failure is just a detour, not a dead end. Your capacity to bounce back is the true measure of your strength.”</p>
        }
      ]
    }
  },
  {
    id: "digital_1",
    category: "Digital",
    title: "The Social Filter",
    img: "https://picsum.photos/seed/dig1/300/400",
    content: {
      title: "Unplugging to Connect",
      pages: [
        {
          title: "The Digital Noise",
          icon: <Zap className="text-radiant-pink" />,
          content: (
            <>
              <p>The notifications were constant pings on the edges of her attention. Even when she was in a room full of people, she was elsewhere—lost in the blue light of a screen, scrolling through the lives of strangers while neglecting her own.</p>
              <p>She felt a strange anxiety every time she was away from her phone for more than a minute. The digital world was demanding all of her, leaving her feeling hollowed out and disconnected from reality.</p>
            </>
          )
        },
        {
          title: "The Quiet Reality",
          icon: <Coffee className="text-radiant-pink" />,
          content: (
            <>
              <p>One evening, she powered it down. Just for an hour. The silence felt heavy and uncomfortable at first, like a missing limb. But then, she noticed the way the light hit the walls. She heard the birds outside. She felt the texture of her own thoughts again.</p>
              <p>She realized that connection isn't measured in likes or comments, but in the quality of her own presence. She started spending more time in the world that didn't need a Wi-Fi password. She found herself again.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Globe className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The most important parts of your life happen in the spaces between the updates. Unplug often to remember who you are when no one is watching.”</p>
        }
      ]
    }
  },
  {
    id: "leadership_1",
    category: "Leadership",
    title: "Hidden Influence",
    img: "https://picsum.photos/seed/lead1/300/400",
    content: {
      title: "She Didn't Think She Was a Leader...",
      pages: [
        {
          title: "The Misconception",
          icon: <Target className="text-radiant-pink" />,
          content: (
            <>
              <p>She always thought leaders were the ones standing on chairs, shouting orders through megaphones with absolute certainty. Since she was quiet and preferred the background, she assumed she was just a follower, someone without the power to shape anything important.</p>
              <p>She waited for someone to "give" her permission to lead, thinking leadership was a title you had to be awarded rather than a quality you chose to embody.</p>
            </>
          )
        },
        {
          title: "The Quiet Power",
          icon: <Smile className="text-radiant-pink" />,
          content: (
            <>
              <p>Then she noticed the way others looked to her when things got chaotic. Not because she shouted, but because she stayed calm. Not because she gave orders, but because she was the first to pick up a broom or offer a kind word to someone who was struggling.</p>
              <p>She realized that leadership isn't about volume; it's about consistency. By simply being the person she wanted others to be, she was influencing the room more than any shout ever could. She was leading from the heart.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Star className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Leadership is the ripple effect of your character. You don't need a title to make a difference; you just need to be brave enough to act with integrity.”</p>
        }
      ]
    }
  },
  {
    id: "emotions_1",
    category: "Emotions",
    title: "The Storm Inside",
    img: "https://picsum.photos/seed/emo1/300/400",
    content: {
      title: "Riding the Waves",
      pages: [
        {
          title: "The Emotional Surge",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>It came out of nowhere—a sudden, violent surge of feelings that left her breathless. Anger clashing with sadness, wrapped in a thick fog of confusion. She felt like she was standing in the middle of a hurricane, with her own thoughts spinning out of control.</p>
              <p>She tried to push it down, to be "strong" and "rational," but the more she resisted, the stronger the storm became. She felt like she was drowning in a sea of her own making, unable to find the shore.</p>
            </>
          )
        },
        {
          title: "The Gentle Anchor",
          icon: <Shield className="text-radiant-pink" />,
          content: (
            <>
              <p>Then, she stopped fighting. She allowed herself to simply feel the cold water. She closed her eyes and began to name the waves as they passed: "This is frustration. This is loneliness. This is exhaustion." Putting a name to the chaos made it feel smaller.</p>
              <p>She realized that emotions aren't enemies to be defeated; they are messengers trying to tell her something important about her world. By sitting with the storm instead of running from it, she found a strange, quiet peace in the center of the wind.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are not your emotions; you are the sky, and they are just the weather. Even the heaviest storm eventually runs out of rain.”</p>
        }
      ]
    }
  },
  {
    id: "creativity_1",
    category: "Creativity",
    title: "The Blank Page",
    img: "https://picsum.photos/seed/cre1/300/400",
    content: {
      title: "The Fear of Starting",
      pages: [
        {
          title: "The Silent Standoff",
          icon: <Zap className="text-radiant-pink" />,
          content: (
            <>
              <p>She had a vision in her head—something vibrant, meaningful, and perfectly formed. But as she sat before the crisp, white page, her hand felt frozen. The paper looked back at her with a terrifying silence, as if it were daring her to ruin its perfection.</p>
              <p>The "inner critic" was already active, telling her that her first stroke would be a mistake, that she lacked the talent to match her imagination. She was waiting for a "perfect" idea that would never come.</p>
            </>
          )
        },
        {
          title: "The Joy of the Mess",
          icon: <RefreshCw className="text-radiant-pink" />,
          content: (
            <>
              <p>Finally, she closed her eyes and made a deliberate, messy scribble right in the middle of the page. It was ugly, and it was perfect. The silence was broken. Once the "perfection" was gone, her curiosity could take the lead.</p>
              <p>She realized that creativity isn't about getting it right on the first try; it's about the courage to make a mess and the playfulness to see what grows from it. The art wasn't in the result; it was in the rhythmic movement of her hand across the paper.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Sparkles className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Everything you create today is a bridge to the artist you are becoming tomorrow. Don't let the fear of a bad beginning stop a beautiful story.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_1",
    category: "Wellness",
    title: "The Daily Pause",
    img: "https://picsum.photos/seed/wel1/300/400",
    content: {
      title: "Five Minutes of Peace",
      pages: [
        {
          title: "The Unending Race",
          icon: <Clock className="text-radiant-pink" />,
          content: (
            <>
              <p>The world felt like it was moving at a thousand miles an hour, and she was barely keeping up. There was always another notification, another item on the list, another expectation to meet. Her mind was a constant hum of "what's next?"</p>
              <p>She felt like she was running on a treadmill that never stopped, losing her sense of self in the blur of constant motion and noise. She realized she hadn't taken a truly deep breath all day.</p>
            </>
          )
        },
        {
          title: "The Sacred Breath",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She finally stopped. She sat by a window, closed her eyes, and let her phone remain silent across the room. She focused entirely on the air moving in and out of her lungs. At first, her mind fought back, but slowly, the inner chatter began to fade.</p>
              <p>In those five minutes, the world didn't actually stop, but her *need* for it to move fast did. She found a quiet gravity in her own center. She realized that she wasn't just a "doing" machine; she was a "being," and being was enough.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The most productive thing you can do for your soul is to occasionally do nothing at all. Your worth is not measured by your pace.”</p>
        }
      ]
    }
  },
  {
    id: "future_1",
    category: "Future",
    title: "Big Dreams, Small Steps",
    img: "https://picsum.photos/seed/fut1/300/400",
    content: {
      title: "The Horizon",
      pages: [
        {
          title: "The Unknown Road",
          icon: <Compass className="text-radiant-pink" />,
          content: (
            <>
              <p>Everywhere she went, people were asking the same looming question: "What do you want to be when you grow up?" To her, the future didn't feel like an exciting destination; it felt like a giant, dark map with no landmarks. She felt behind because she didn't have a ten-year plan by the age of sixteen.</p>
              <p>The uncertainty felt like a heavy fog. She was so worried about picking the "wrong" path that she was afraid to move in any direction at all.</p>
            </>
          )
        },
        {
          title: "The Present Path",
          icon: <BookOpen className="text-radiant-pink" />,
          content: (
            <>
              <p>Then she realized that she didn't need to know the end of the story to enjoy the current chapter. She stopped trying to predict a decade from now and started following the things that spark her curiosity *today*. A project about nature, a book on coding, a conversation about justice.</p>
              <p>One small interest led to another. The fog didn't vanish, but it started to clear just enough to see the next few feet. She realized that your future isn't a single thing you "become"—it's a series of choices you make about who you want to be in the world.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Target className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your future is not a fixed point you have to hit; it's a garden you are planting right now. Don't rush the growth; just keep tending to the seeds of your interests.”</p>
        }
      ]
    }
  },
  {
    id: "school_2",
    category: "School",
    title: "The Grade Obsession",
    img: "https://picsum.photos/seed/sch2/300/400",
    content: {
      title: "More Than a Number",
      pages: [
        {
          title: "The Trap of Perfection",
          icon: <Target className="text-radiant-pink" />,
          content: (
            <>
              <p>She stared at the 88% on her screen. To anyone else, it was a victory. To her, it felt like a crushing failure. She let a single numeric digit define how she felt about her intelligence, her future, and her entire value as a person.</p>
              <p>She was treating school like a high-stakes game where one wrong move could end everything. The joy of discovery was being replaced by the fear of a red pen. She was a "student," but she had forgotten how to learn.</p>
            </>
          )
        },
        {
          title: "Deepening the Root",
          icon: <Sparkles className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop focusing on the score and start focusing on the spark. Instead of cramming for the test, she looked for the "why" behind the lesson. She allowed herself to be messy in her first drafts and to ask "stupid" questions until she truly understood.</p>
              <p>She realized that learning is like a garden—it thrives on curiosity and care, not just on the results of a harvest. Her brain felt alive again. She was no longer just a collection of grades; she was a vibrant, evolving mind with infinite potential.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Smile className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“An exam can measure what you know today, but it can never measure the limit of what you can achieve tomorrow. You are a genius in the making.”</p>
        }
      ]
    }
  },
  {
    id: "social_2",
    category: "Social",
    title: "Small Talk, Big Connections",
    img: "https://picsum.photos/seed/soc2/300/400",
    content: {
      title: "The Social Butterfly Effect",
      pages: [
        {
          title: "The Glass Wall",
          icon: <User className="text-radiant-pink" />,
          content: (
            <>
              <p>She often felt like she was standing on the outside of a party, looking in through a thick pane of glass. She could see people laughing and connecting, but she didn't know the password to get into the room. She felt invisible, not because she wanted to be, but because she was afraid of being seen and rejected.</p>
              <p>She thought that deep connection required instant, soul-baring vulnerability, and the thought of that was overwhelming. So, she stayed quiet, and the wall remained.</p>
            </>
          )
        },
        {
          title: "The First Thread",
          icon: <MessageCircle className="text-radiant-pink" />,
          content: (
            <>
              <p>She tried something new. Just one question. A simple, "That's a cool pin, where did you get it?" or "How are you handling the math homework?" It felt tiny—almost insignificant. But the glass didn't shatter; it just dissolved.</p>
              <p>She realized that intimacy is built from a thousand small threads of attention. By showing genuine interest in someone else's small world, she was creating a bridge to hers. Every "hello" was a brick in a house she was finally starting to build.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You don't need to be the loudest person in the room to be the most connected. True belonging begins with the courage to be the first to reach out.”</p>
        }
      ]
    }
  },
  {
    id: "mindset_2",
    category: "Mindset",
    title: "The Power of Yet",
    img: "https://picsum.photos/seed/mind2/300/400",
    content: {
      title: "I Can't Do This... Yet",
      pages: [
        {
          title: "The Internal Dead-End",
          icon: <Target className="text-radiant-pink" />,
          content: (
            <>
              <p>She sat before the complex equation, her brow furrowed in frustration. "I can't do this," she whispered to the empty room. "I'm just not a math person. My brain doesn't work that way." It felt like a final judgment, a static ceiling on her own potential.</p>
              <p>By saying "I can't," she was closing the book before the story even began. She was treating her intelligence like a fixed bucket that had already been filled to its limit.</p>
            </>
          )
        },
        {
          title: "The Three Letters of Hope",
          icon: <Sparkles className="text-radiant-pink" />,
          content: (
            <>
              <p>Then she tried a simple linguistic shift. "I can't do this *yet*." That one tiny word changed everything. Suddenly, the problem wasn't a wall; it was a ladder. It wasn't a sign of her stupidity; it was an invitation to practice.</p>
              <p>She realized that her brain is a living, breathing muscle that literally gets stronger every time it struggles. "Yet" meant that the story was still being written. The difficulty wasn't a reason to stop; it was the very thing that was making her smarter.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The word 'yet' is the bridge between who you are and who you are becoming. Respect the process, and celebrate the struggle—it's where the growth happens.”</p>
        }
      ]
    }
  },
  {
    id: "mindset_3",
    category: "Mindset",
    title: "Fixed vs Growth",
    img: "https://picsum.photos/seed/mind3/300/400",
    content: {
      title: "The Two Voices",
      pages: [
        { title: "The Fixed Voice", icon: <Cloud />, content: <p>One voice said: 'You are born with what you have.' It made her afraid to try new things.</p> },
        { title: "The Growth Voice", icon: <Sunrise />, content: <p>The other said: 'You can learn anything.' She started choosing the second voice every morning.</p> },
        { title: "Reminder", icon: <Star />, content: <p className="font-serif italic text-lg text-radiant-pink">“You are a work in progress, and the 'progress' part is up to you.”</p> }
      ]
    }
  },
  {
    id: "health_1",
    category: "Health",
    title: "Natural Energy",
    img: "https://picsum.photos/seed/heal1/300/400",
    content: {
      title: "Fueling Your Glow",
      pages: [
        {
          title: "The Burn-Out Cycle",
          icon: <Zap className="text-radiant-pink" />,
          content: (
            <>
              <p>She was running on high-speed adrenaline and sugary snacks. She'd feel a brilliant flash of energy for twenty minutes, and then her mood would plummet into a gray, heavy fatigue. She was exhausted but couldn't sleep, hungry but never satisfied.</p>
              <p>She realized she was treating her body like a machine to be driven, rather than a garden to be nurtured. She was asking for performance without providing the proper fuel.</p>
            </>
          )
        },
        {
          title: "The Vibrant Reset",
          icon: <Smile className="text-radiant-pink" />,
          content: (
            <>
              <p>She started slowly. More water. A bit of green on her plate. A regular bedtime. It wasn't about a "diet"; it was about data. She noticed how her brain felt sharper when she moved her body, and how her temper stayed cooler when she was well-rested.</p>
              <p>She realized that the way she treated her body was the foundation for everything else she wanted to achieve. Her skin started to glow, but her *mind* was the real beneficiary. She was fueling the girl she intended to become.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is the vessel for all of your dreams. Honor it with vibrant fuel and restorative rest. You are worth the effort it takes to feel alive.”</p>
        }
      ]
    }
  },
  {
    id: "social_3",
    category: "Social",
    title: "Group Dynamics",
    img: "https://picsum.photos/seed/soc3/300/400",
    content: {
      title: "Finding Your Voice",
      pages: [
        { title: "The Echo", icon: <Users />, content: <p>In the group, she just agreed with everyone. She was there, but her real self was hidden.</p> },
        { title: "The Spark", icon: <MessageCircle />, content: <p>She finally shared her own opinion. Some disagreed, but others leaned in. She felt visible for the first time.</p> },
        { title: "Reminder", icon: <Star />, content: <p className="font-serif italic text-lg text-radiant-pink">“The right people want to hear the real you, not an echo of themselves.”</p> }
      ]
    }
  },
  {
    id: "growth_2",
    category: "Growth",
    title: "The Comfort Zone",
    img: "https://picsum.photos/seed/grow2/300/400",
    content: {
      title: "Stepping Out",
      pages: [
        {
          title: "The Safe Harbor",
          icon: <Target className="text-radiant-pink" />,
          content: (
            <>
              <p>Her life felt small and manageable. She only did things she was already good at, only talked to people she already knew, and never strayed from the habitual paths she'd worn into her daily routine. It felt safe, but it also felt... quiet. Too quiet.</p>
              <p>She realized that while she was avoiding the risk of failure, she was also avoiding the possibility of wonder. Her "comfort zone" had become a beautifully decorated cage that she was beginning to outgrow.</p>
            </>
          )
        },
        {
          title: "The Great Leap",
          icon: <Sparkles className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to do one thing—just one—that made her heart beat a little faster. She signed up for that workshop, she struck up a conversation with the newcomer, she tried the hobby she thought she'd be "bad" at. The fear was there, but it was accompanied by a strange, electric sense of life.</p>
              <p>She discovered that she didn't break; she expanded. The boundaries of her world pushed outward, and the "unknown" shifted from being a threat to being an adventure. She wasn't just safe anymore; she was alive.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Compass className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Magic doesn't happen in the places you already know. Growth requires you to be a stranger for a little while until the new world becomes home.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_2",
    category: "Confidence",
    title: "Body Language",
    img: "https://picsum.photos/seed/con2/300/400",
    content: {
      title: "Stand Tall",
      pages: [
        { title: "The Slouch", icon: <User />, content: <p>She tried to be small. Head down, shoulders forward. She thought it made her invisible.</p> },
        { title: "The Power", icon: <Shield />, content: <p>She stood tall. Chin up. Shoulders back. She didn't feel confident yet, but her body started to believe it first.</p> },
        { title: "Reminder", icon: <Sparkles />, content: <p className="font-serif italic text-lg text-radiant-pink">“Your posture tells your brain how to feel. Stand like you belong there.”</p> }
      ]
    }
  },
  {
    id: "school_3",
    category: "School",
    title: "Note-Taking Secrets",
    img: "https://picsum.photos/seed/sch3/300/400",
    content: {
      title: "Mapping Your Mind",
      pages: [
        { title: "The Mess", icon: <BookOpen />, content: <p>She tried to write everything the teacher said. Her notes were just walls of text she couldn't read.</p> },
        { title: "The Map", icon: <Sparkles />, content: <p>She tried mind-mapping instead. Colors, branches, and keywords. Suddenly, the lesson made sense.</p> },
        { title: "Reminder", icon: <Star />, content: <p className="font-serif italic text-lg text-radiant-pink">“Don't record what you hear—translate it into what you understand.”</p> }
      ]
    }
  },
  {
    id: "future_2",
    category: "Future",
    title: "Career Paths",
    img: "https://picsum.photos/seed/fut2/300/400",
    content: {
      title: "Discovering Your Why",
      pages: [
        { title: "The Choice", icon: <Compass />, content: <p>Everyone asked 'What do you want to be?' until she was sick of the question.</p> },
        { title: "The Passion", icon: <Heart />, content: <p>She started asking 'What problems do I want to solve?' The answers were much more exciting.</p> },
        { title: "Reminder", icon: <Target />, content: <p className="font-serif italic text-lg text-radiant-pink">“Success isn't a destination; it's a journey fueled by your curiosity.”</p> }
      ]
    }
  },
  {
    id: "identity_2",
    category: "Identity",
    title: "The Real You",
    img: "https://picsum.photos/seed/ide2/300/400",
    content: {
      title: "Mirror Mirror",
      pages: [
        { title: "The Mask", icon: <User />, content: <p>She had a version of herself for every group of friends. She felt like a puzzle with missing pieces.</p> },
        { title: "The Truth", icon: <Zap />, content: <p>She decided to be the same person everywhere. It was scary, but it was also incredibly light.</p> },
        { title: "Reminder", icon: <Heart />, content: <p className="font-serif italic text-lg text-radiant-pink">“Authenticity is a magnet for the people who actually belong in your life.”</p> }
      ]
    }
  },
  {
    id: "selflove_1",
    category: "Self-Love",
    title: "Daily Affirmations",
    img: "https://picsum.photos/seed/lov1/300/400",
    content: {
      title: "Words of Power",
      pages: [
        {
          title: "The Internal Critic",
          icon: <MessageCircle className="text-radiant-pink" />,
          content: (
            <>
              <p>The harshest voice she ever heard wasn't a bully at school or a difficult relative—it was the one inside her own head. It was a constant stream of "you're not enough," "you're too much," and "you'll never be able to handle this." She realized she would never let anyone else talk to her friends the way she talked to herself.</p>
              <p>She was living in a mental environment that was hostile to her own growth. She was waiting for external validation to silence the internal noise, but it never seemed to be enough.</p>
            </>
          )
        },
        {
          title: "The Gentle Reframing",
          icon: <Shield className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start a new practice. Every morning, she looked in the mirror and said three things that were true and kind. "I am capable. I am learning. I am worthy of rest." It felt ridiculous at first, like a lie she was trying to tell herself.</p>
              <p>But over time, the "lie" became a baseline. The critical voice didn't vanish, but it lost its authority. She realized that self-love isn't a feeling you wait for; it's a practice you commit to. She was finally becoming her own best advocate.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Smile className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The way you speak to yourself determines the quality of your internal home. Fill it with kindness, for you have to live there forever.”</p>
        }
      ]
    }
  },
  {
    id: "boundaries_2",
    category: "Boundaries",
    title: "Digital Boundaries",
    img: "https://picsum.photos/seed/bou2/300/400",
    content: {
      title: "The Off Button",
      pages: [
        { title: "The Ping", icon: <Zap />, content: <p>Her phone was an extension of her hand. She felt like she had to be available 24/7.</p> },
        { title: "The Quiet", icon: <Cloud />, content: <p>She set 'No Phone' hours. The anxiety of missing out was replaced by the joy of being present.</p> },
        { title: "Reminder", icon: <RefreshCw />, content: <p className="font-serif italic text-lg text-radiant-pink">“You don't owe anyone a response at the expense of your own peace.”</p> }
      ]
    }
  },
  {
    id: "hobby_1",
    category: "Hobby",
    title: "The Joy of Making",
    img: "https://picsum.photos/seed/hob1/300/400",
    content: {
      title: "Finding Your Flow",
      pages: [
        {
          title: "The Consumption Trap",
          icon: <Package className="text-radiant-pink" />,
          content: (
            <>
              <p>She realized she was spending most of her life on the "receiving" end of the world. She scrolled through other people's art, watched other people's lives, and listened to other people's music. It felt like she was a spectator in her own existence, and it left a strange, hollow ache in her chest.</p>
              <p>Everything felt processed and passive. She was consuming so much that she had forgotten she had the power to contribute something unique to the noise.</p>
            </>
          )
        },
        {
          title: "The Creative Spark",
          icon: <RefreshCw className="text-radiant-pink" />,
          content: (
            <>
              <p>She picked up a pair of knitting needles and a ball of soft, blue yarn. At first, her fingers felt clumsy and the stitches were uneven. But as the row grew taller, she felt a shift. The world outside the yarn began to fade. The rhythm of "loop, pull, slide" became a heartbeat.</p>
              <p>She wasn't just "killing time"—she was bringing something into being that hadn't existed before. She realized that a hobby isn't about the quality of the product; it's about the quality of the presence. She was no longer just a consumer; she was a creator.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You were designed to create as much as you consume. Find the thing that makes you forget to check your phone and remember who you are.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_2",
    category: "Wellness",
    title: "Nature's Secret",
    img: "https://picsum.photos/seed/wel2/300/400",
    content: {
      title: "The Green Reset",
      pages: [
        { title: "The Screen", icon: <Cloud />, content: <p>She spent all day under fluorescent lights. Her eyes were tired and her spirit felt gray.</p> },
        { title: "The Grass", icon: <Globe />, content: <p>She walked barefoot in the grass for ten minutes. The earth felt solid, and her battery felt charged.</p> },
        { title: "Reminder", icon: <Sunrise />, content: <p className="font-serif italic text-lg text-radiant-pink">“Nature doesn't hurry, yet everything is accomplished. Take a leaf out of its book.”</p> }
      ]
    }
  },
  {
    id: "communication_1",
    category: "Communication",
    title: "Listening Deeply",
    img: "https://picsum.photos/seed/com1/300/400",
    content: {
      title: "Beyond the Words",
      pages: [
        {
          title: "The Echo Chamber",
          icon: <MessageCircle className="text-radiant-pink" />,
          content: (
            <>
              <p>She noticed a pattern in her conversations: while the other person was talking, she was already mentally formulating her rebuttal, her story, or her advice. She was hearing the words, but she wasn't actually *listening*. She was just waiting for her turn to fill the air with her own voice.</p>
              <p>Her relationships felt shallow because she was only ever interacting with her own reflections. She realized she was missing the subtle maps of other people's internal worlds.</p>
            </>
          )
        },
        {
          title: "The Silent Bridge",
          icon: <Heart className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try a new way of being. She practiced silent, active presence. She looked into her friend's eyes, noticed the slight tremble in their voice, and allowed the silence to linger after they finished speaking. She stopped trying to "fix" and started trying to "feel."</p>
              <p>She discovered that when people feel truly heard, they reveal parts of themselves they never knew they had. She learned that a quiet, attentive ear is often more powerful than the most eloquent advice. She was finally connecting, heart to heart.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Star className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The greatest gift you can give another human being is the quality of your attention. Listen with the intent to understand, not the intent to reply.”</p>
        }
      ]
    }
  },
  {
    id: "motivation_1",
    category: "Motivation",
    title: "The Tiny Habit",
    img: "https://picsum.photos/seed/mot1/300/400",
    content: {
      title: "One Percent Better",
      pages: [
        {
          title: "The Paralyzing Peak",
          icon: <Target className="text-radiant-pink" />,
          content: (
            <>
              <p>She had a dream so big it felt like a mountain towering over her bedroom. Every time she thought about "starting," she felt a wave of nausea. The distance between where she was and where she wanted to be seemed impossible to cross. She felt like a failure before she even began.</p>
              <p>She was waiting for a massive burst of motivation that never came. She was looking at the summit and ignoring the path right in front of her feet.</p>
            </>
          )
        },
        {
          title: "The Power of One Minute",
          icon: <Zap className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop trying to climb the mountain in a day. She committed to just one minute. One minute of stretching, one minute of reading, one minute of cleaning. It felt almost too small to matter, but it was a bridge she could actually cross.</p>
              <p>One minute turned into two. Two turned into ten. She realized that consistency is the engine of change, and momentum is fueled by the smallest of starts. She wasn't chasing a giant leap anymore; she was building a stairway, one tiny step at a time.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <RefreshCw className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You don't need to be extraordinary to start; you just need to start to become extraordinary. Respect the power of the small finish.”</p>
        }
      ]
    }
  },
  {
    id: "physical_3",
    category: "Physical",
    title: "The Sleep Ritual",
    img: "https://picsum.photos/seed/phy3/300/400",
    content: {
      title: "Rest for Success",
      pages: [
        { title: "The Night", icon: <Cloud />, content: <p>She stayed up late scrolling, then woke up feeling like a zombie. Her day was over before it began.</p> },
        { title: "The Sleep", icon: <Sunrise />, content: <p>She declared a digital curfew. Dimmed the lights. The sleep was deep, and the next day was brilliant.</p> },
        { title: "Reminder", icon: <Coffee />, content: <p className="font-serif italic text-lg text-radiant-pink">“Rest is productive. Your dreams need you to sleep so they can grow.”</p> }
      ]
    }
  },
  {
    id: "mindset_4", category: "Mindset", title: "Embracing Mistakes", img: "https://picsum.photos/seed/mind4/300/400",
    content: { title: "Oops is a Lesson", pages: [
      { title: "The Blunder", icon: <Target />, content: <p>She made a mistake in front of everyone. She wanted to disappear into the floor.</p> },
      { title: "The Lesson", icon: <Sparkles />, content: <p>She realized that every mistake is just data. It tells you what doesn't work so you can find what does.</p> },
      { title: "Reminder", icon: <Heart />, content: <p className="font-serif italic text-lg text-radiant-pink">“Mistakes are proof that you are trying. Wear them like badges of honor.”</p> }
    ]}
  },
  {
    id: "health_2", category: "Health", title: "Hydration Station", img: "https://picsum.photos/seed/heal2/300/400",
    content: { title: "Liquid Gold", pages: [
      { title: "The Fog", icon: <Cloud />, content: <p>Her head ached and her focus was blurry. She felt like a plant that hadn't seen rain in weeks.</p> },
      { title: "The Sip", icon: <Globe />, content: <p>She started carrying a water bottle. Every sip felt like clarity returning to her mind.</p> },
      { title: "Reminder", icon: <Sunrise />, content: <p className="font-serif italic text-lg text-radiant-pink">“Water is the simplest medicine. Drink up and glow from the inside out.”</p> }
    ]}
  },
  {
    id: "social_4", category: "Social", title: "The Comparison Cure", img: "https://picsum.photos/seed/soc4/300/400",
    content: { title: "Celebrating Others", pages: [
      { title: "The Sting", icon: <Star />, content: <p>Her friend won an award, and she felt a bite of jealousy. She felt bad for feeling bad.</p> },
      { title: "The Cheer", icon: <Smile />, content: <p>She decided to be the loudest person cheering. Celebrating their win didn't take away from her own value.</p> },
      { title: "Reminder", icon: <Users />, content: <p className="font-serif italic text-lg text-radiant-pink">“Other people's light doesn't dim your own. Shine together.”</p> }
    ]}
  },
  {
    id: "growth_3", category: "Growth", title: "Patience with Progress", img: "https://picsum.photos/seed/grow3/300/400",
    content: { title: "The Seed", pages: [
      { title: "The Wait", icon: <Clock />, content: <p>She was working hard but didn't see results yet. She felt like giving up because it was taking too long.</p> },
      { title: "The Sprout", icon: <Sunrise />, content: <p>She kept going. One day, a tiny green shoot appeared. Progress happens underground first.</p> },
      { title: "Reminder", icon: <RefreshCw />, content: <p className="font-serif italic text-lg text-radiant-pink">“Trust the process. Growth is happening even when you can't see it yet.”</p> }
    ]}
  },
  {
    id: "confidence_3", category: "Confidence", title: "Inner Strength", img: "https://picsum.photos/seed/con3/300/400",
    content: { title: "The Superhero Within", pages: [
      { title: "The Fear", icon: <Shield />, content: <p>She felt small and weak. She thought everyone else had a secret manual for being brave.</p> },
      { title: "The Cape", icon: <Zap />, content: <p>She did one brave thing. Then another. She realized that courage is a choice, not a feeling.</p> },
      { title: "Reminder", icon: <Star />, content: <p className="font-serif italic text-lg text-radiant-pink">“You are braver than you believe and stronger than you seem.”</p> }
    ]}
  },
  {
    id: "school_4", category: "School", title: "Study Sanctuary", img: "https://picsum.photos/seed/sch4/300/400",
    content: { title: "Focus Zone", pages: [
      { title: "The Chaos", icon: <Megaphone />, content: <p>Noise, notifications, and clutter. She couldn't focus on her book for more than a minute.</p> },
      { title: "The Zen", icon: <Coffee />, content: <p>She cleared her desk and put her phone in another room. The silence was the best study partner she ever had.</p> },
      { title: "Reminder", icon: <BookOpen />, content: <p className="font-serif italic text-lg text-radiant-pink">“Your environment shapes your mind. Create a space where you can soar.”</p> }
    ]}
  },
  {
    id: "future_3", category: "Future", title: "Unfolding Tomorrow", img: "https://picsum.photos/seed/fut3/300/400",
    content: { title: "The Unknown Road", pages: [
      { title: "The Fog", icon: <Cloud />, content: <p>She wanted to know exactly where she was going. The uncertainty was keeping her awake at night.</p> },
      { title: "The Light", icon: <Sunrise />, content: <p>She realized that life is a series of next steps, not a final destination. She started enjoying the walk.</p> },
      { title: "Reminder", icon: <Compass />, content: <p className="font-serif italic text-lg text-radiant-pink">“The future is unwritten. You are the author of the next chapter.”</p> }
    ]}
  },
  {
    id: "identity_3", category: "Identity", title: "Beyond Labels", img: "https://picsum.photos/seed/ide3/300/400",
    content: { title: "The Real You", pages: [
      { title: "The Tag", icon: <User />, content: <p>People had labels for her. 'The smart one', 'the quiet one'. She felt stuck in those boxes.</p> },
      { title: "The Break", icon: <Zap />, content: <p>She decided to do something that 'wasn't like her'. She realized she was infinite, not a label.</p> },
      { title: "Reminder", icon: <Heart />, content: <p className="font-serif italic text-lg text-radiant-pink">“You are not what others say you are. You are whoever you choose to be today.”</p> }
    ]}
  },
  {
    id: "selflove_2", category: "Self-Love", title: "Kindness to Self", img: "https://picsum.photos/seed/lov2/300/400",
    content: { title: "The Best Friend", pages: [
      { title: "The Critic", icon: <MessageCircle />, content: <p>She said things to herself that she would never say to a friend. She was her own worst enemy.</p> },
      { title: "The Hug", icon: <Heart />, content: <p>She started treating herself like a guest in her own mind. With tea, patience, and kind words.</p> },
      { title: "Reminder", icon: <Smile />, content: <p className="font-serif italic text-lg text-radiant-pink">“You are deserving of your own love and affection. Don't wait for someone else to give it.”</p> }
    ]}
  },
  {
    id: "boundaries_3", category: "Boundaries", title: "Physical Space", img: "https://picsum.photos/seed/bou3/300/400",
    content: { title: "The Personal Bubble", pages: [
      { title: "The Crowd", icon: <Users />, content: <p>She felt like people were always intruding. She was being polite while her personal space was disappearing.</p> },
      { title: "The Line", icon: <Shield />, content: <p>She learned to say 'I need some space right now'. People respected it, and she felt safe again.</p> },
      { title: "Reminder", icon: <CheckCircle2 />, content: <p className="font-serif italic text-lg text-radiant-pink">“Your space is sacred. It's okay to put up a 'do not disturb' sign.”</p> }
    ]}
  },
  {
    id: "mindset_5",
    category: "Mindset",
    title: "Possibility Thinking",
    img: "https://picsum.photos/seed/min5/300/400",
    content: {
      title: "What If?",
      pages: [
        {
          title: "The Forecast of Doom",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She lived in a constant state of "worst-case scenario." Before a big test, she saw the failing grade. Before a party, she saw herself standing alone in a corner. Her mind was a master at predicting the rain, even when the sky was perfectly blue. She felt exhausted by a future that hadn't even happened yet.</p>
              <p>The anxiety of "what if it goes wrong" was a heavy blanket that kept her small and safe, but also incredibly lonely.</p>
            </>
          )
        },
        {
          title: "The Sunny Alternative",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>One evening, she decided to try a dangerous experiment. Every time a "what if it fails" thought popped up, she forced herself to imagine a "what if it flies" counter-thought. What if she passed with flying colors? What if she met a new best friend at that party? What if the risks she took actually paid off?</p>
              <p>She realized that her imagination was a tool, and she had been using it as a weapon against herself. By simply opening the door to possibility, the room felt brighter. She wasn't just surviving the day; she was looking forward to it.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your mind is fertile soil. If you plant seeds of worry, you'll harvest a life of fear. Plant seeds of hope, and watch the impossible start to bloom.”</p>
        }
      ]
    }
  },
  {
    id: "mindset_6",
    category: "Mindset",
    title: "Mindful Moments",
    img: "https://picsum.photos/seed/min6/300/400",
    content: {
      title: "The Power of Now",
      pages: [
        {
          title: "The Ghost of Yesterday",
          icon: <Clock className="text-radiant-pink" />,
          content: (
            <>
              <p>She was a time traveler, but not the fun kind. Her mind was always half-stuck in a conversation she'd had three days ago, or three months into the future, worrying about a presentation that wasn't even written. She was physically in the room, but her soul was miles away, wandering through regrets and anxieties.</p>
              <p>Life felt like a blur, a series of shadows passing by while she stayed locked in the "should-haves" and "might-be's."</p>
            </>
          )
        },
        {
          title: "The Anchor",
          icon: <Zap className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop running. She sat down and focused entirely on the feeling of her feet on the floor. She noticed the way the sunlight hit the dust motes in the air, the distant sound of a bird, the cool weight of the air in her lungs. She realized that the "now" was actually a very peaceful place to be.</p>
              <p>In the present, there was no failure and no fear. There was just this breath, and then the next. She discovered that mindfulness wasn't about clearing her mind; it was about finally coming home to herself.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Yesterday is a memory and tomorrow is a dream. The only time you can actually change anything, love anyone, or be someone is right here, in this heartbeat.”</p>
        }
      ]
    }
  },
  {
    id: "mindset_7",
    category: "Mindset",
    title: "The Gift of Curiosity",
    img: "https://picsum.photos/seed/min7/300/400",
    content: {
      title: "Staying Open",
      pages: [
        {
          title: "The Closed Book",
          icon: <BookOpen className="text-radiant-pink" />,
          content: (
            <>
              <p>She had reached a point where she felt she "knew" how the world worked. People were predictable, school was a chore, and she was just... her. Everything felt static and a bit gray. She had stopped asking questions because she was afraid that not knowing the answer made her look weak.</p>
              <p>By closing herself off to the "why," she had accidentally shut the window on the "wow."</p>
            </>
          )
        },
        {
          title: "The Beginner's Mind",
          icon: <Sparkles className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to embrace the "I don't know." She started asking questions again—not just about math, but about how her neighbor's garden grew, why her friend loved that strange music, and how her own feelings shifted throughout the day. She realized that every person she met knew something she didn't.</p>
              <p>The world suddenly felt like an infinite playground of mysteries waiting to be unraveled. She wasn't just a student anymore; she was an explorer. And the more she learned, the more she realized how beautiful it was to be a lifelong beginner.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Curiosity is the antidote to boredom and the father of invention. Never lose your sense of wonder; it's the bridge to a larger life.”</p>
        }
      ]
    }
  },
  {
    id: "health_3",
    category: "Health",
    title: "The Hydration Ritual",
    img: "https://picsum.photos/seed/hea3/300/400",
    content: {
      title: "Liquid Vitality",
      pages: [
        {
          title: "The Internal Drought",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was running on fumes. Her head throbbed with a dull ache by noon, her skin felt tight and dull, and her brain felt like it was trying to work through a thick fog. She was reaching for caffeine and sugar to keep going, but it only made the crash harder.</p>
              <p>She realized she was taking better care of her phone's battery than she was of her own biological fluid levels. She was wilting from the inside out.</p>
            </>
          )
        },
        {
          title: "The Refreshing Flow",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She bought a bottle she actually liked and made a game of it. Every hour, a few sips. Before every meal, a full glass. She noticed the difference almost immediately. The "brain fog" lifted, her energy stayed steady, and she even found herself smiling more. It was such a simple thing, but it felt like biological magic.</p>
              <p>She discovered that water wasn't just a "task" on a list; it was a love letter to her cells. She was finally giving her body the basic resource it needed to hum with life. She felt clear, clean, and completely alive.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are basically a very high-maintenance houseplant with complicated emotions. Don't forget to water yourself today. You deserve to flourish.”</p>
        }
      ]
    }
  },
  {
    id: "health_4",
    category: "Health",
    title: "The Sanctuary of Sleep",
    img: "https://picsum.photos/seed/hea4/300/400",
    content: {
      title: "Deep Rest",
      pages: [
        {
          title: "The Electric Twilight",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Her nights weren't really dark. They were lit by the blue glow of her screen, scrolling through endless feeds until her eyes burned and her mind was saturated with noise. She was "resting," but she felt more tired when she woke up than when she went to bed. Her dreams were frantic, mirrors of the digital chaos she consumed.</p>
              <p>She was robbing herself of the one time her soul truly needed to recalibrate. She was physically asleep, but her brain was still racing.</p>
            </>
          )
        },
        {
          title: "The Velvet Silence",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to create a boundary. Thirty minutes before bed, the phone went into a drawer. She dimmed the lights, put on her favorite soft socks, and read a paper book. The transition felt slow at first, like waiting for a tide to turn. But then, it happened. A deep, heavy peace settled over her.</p>
              <p>She woke up feeling like a new version of herself. The world looked sharper, her patience was longer, and she felt a quiet strength she hadn't known in months. She realized that sleep wasn't just a biological necessity; it was a sanctuary she had to protect.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Rest is not a reward for work; it's the foundation of it. Protect your peace at night so you can shine your brightest during the day.”</p>
        }
      ]
    }
  },
  {
    id: "health_5",
    category: "Health",
    title: "The Joy of Movement",
    img: "https://picsum.photos/seed/hea5/300/400",
    content: {
      title: "Get Active",
      pages: [
        {
          title: "The Heavy Stillness",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like she was becoming part of her chair. Days would pass where the only "exercise" she got was walking to the fridge and back. Her body felt stiff, her mood was as gray as the pavement outside, and she felt a strange, restless energy that she couldn't quite burn off.</p>
              <p>She was waiting for the "perfect" time to start a gym routine, and in the waiting, she was slowly losing touch with the physical magic of her own body.</p>
            </>
          )
        },
        {
          title: "The Rhythmic Release",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She put on some music and just started to dance in her room. No one was watching. No one was judging. She just moved. Then, she took a walk to the park, feeling the wind against her skin and the solid ground beneath her feet. It wasn't about "getting fit"—it was about feeling alive.</p>
              <p>With every step and every stretch, the mental knots began to loosen. She realized that moving her body was the fastest way to change her mind. She wasn't just exercising; she was celebrating the fact that she was capable and strong. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is your home for the rest of your life. Treat it with kindness by moving it often. Even a five-minute walk is a victory.”</p>
        }
      ]
    }
  },
  {
    id: "social_5",
    category: "Social",
    title: "The Art of Collaboration",
    img: "https://picsum.photos/seed/soc5/300/400",
    content: {
      title: "Teamwork",
      pages: [
        {
          title: "The Island",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was a perfectionist who didn't trust anyone else's work. In group projects, she would quietly take over every task, staying up late to "fix" what others had done. She felt superior but incredibly lonely and burnt out. She was an island, and she was drowning in her own self-reliance.</p>
              <p>She thought that by doing it all, she was being a leader. She didn't realize she was actually preventing her team from growing.</p>
            </>
          )
        },
        {
          title: "The Symphony",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to let go. She assigned parts and actually waited for them to be finished. At first, it was terrifying. But then, a teammate suggested an idea she never would have thought of. Another person brought a sense of humor that kept the stress low. They weren't just working; they were building something together.</p>
              <p>She realized that the end result was better not just because of the work, but because of the shared energy. She wasn't an island anymore; she was part of a vibrant, capable collective. She discovered the joy of being supported.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Success is twice as sweet when shared. True leadership isn't about doing everything yourself; it's about making space for others to shine alongside you.”</p>
        }
      ]
    }
  },
  {
    id: "social_6",
    category: "Social",
    title: "Navigating Hard Conversations",
    img: "https://picsum.photos/seed/soc6/300/400",
    content: {
      title: "Hard Words",
      pages: [
        {
          title: "The Wall of Silence",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had a disagreement with a close friend, and instead of talking about it, she retreated into a cold, hard silence. Every time they were in the same room, she could feel the tension like a physical weight. She was "protecting herself," but she was actually starving the friendship of truth.</p>
              <p>The fear of conflict was keeping her locked in a cage of resentment. She was waiting for the other person to "just know" what was wrong.</p>
            </>
          )
        },
        {
          title: "The Vulnerable Bridge",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She took a deep breath and spoke. "I felt hurt when..." She didn't point fingers; she just shared her experience. To her surprise, the friend didn't get angry—they were relieved to finally be talking. The air felt lighter almost immediately. The conversation wasn't easy, but it was honest.</p>
              <p>She realized that true intimacy isn't the absence of conflict; it's the courage to walk through it together. By speaking her truth with kindness, she had turned a wall into a bridge. She felt a new kind of strength—the strength of vulnerability.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Don't let silence become a distance you can't cross. Kind honesty is the only way to build a relationship that can truly weather the storms.”</p>
        }
      ]
    }
  },
  {
    id: "social_7",
    category: "Social",
    title: "The Courage to say Hello",
    img: "https://picsum.photos/seed/soc7/300/400",
    content: {
      title: "Meeting New People",
      pages: [
        {
          title: "The Silent Barrier",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She moved through the hallways like a ghost. She saw groups of people laughing and talking, and she felt a sharp, familiar pang of exclusion. She wanted to join in, but the gap between her and them felt like an ocean. "They already have friends," she told herself. "They don't want to talk to me."</p>
              <p>The fear of being ignored or, worse, made fun of, kept her eyes glued to the floor. She was waiting for someone to notice her, but everyone was busy with their own lives.</p>
            </>
          )
        },
        {
          title: "The Simple Spark",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to be the one to light the spark. She saw someone sitting alone in the library, looking just as nervous as she felt. She walked over, her heart hammering against her ribs, and said, "Hi, is this seat taken?" A small smile, a quick reply, and suddenly the ocean was just a puddle.</p>
              <p>They ended up talking for an hour. She realized that almost everyone is waiting for someone else to make the first move. By being the one to reach out, she hadn't just found a conversation; she had found the possibility of a new world. She felt brave.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Every best friend was once a stranger who was probably just as nervous as you are. Be the person who builds the bridge.”</p>
        }
      ]
    }
  },
  {
    id: "growth_4",
    category: "Growth",
    title: "Honoring the Slow Season",
    img: "https://picsum.photos/seed/gro4/300/400",
    content: {
      title: "Patience with Yourself",
      pages: [
        {
          title: "The Race to Nowhere",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like she was falling behind. Everyone around her seemed to be hitting milestones—starting businesses, mastering instruments, getting top grades. She was working hard, but it felt like she was standing still. She was comparing her "middle" to everyone else's "highlight reel," and the result was a constant sense of failure.</p>
              <p>She was trying to force the fruit to ripen overnight, and the pressure was making her bitter. She had forgotten that the most beautiful things in the world take time.</p>
            </>
          )
        },
        {
          title: "The Quiet Blooming",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She looked at a tree in her yard. It didn't rush to grow; it just followed the seasons. She decided to do the same. She stopped tracking her progress by checkboxes and started tracking it by feelings. Was she kinder? Was she more curious? Was she more resilient? To her surprise, when she stopped obsessing over the goal, she started enjoying the journey.</p>
              <p>She realized that the "slow seasons" are where the roots grow deep. She wasn't falling behind; she was foundation-building. She finally gave herself permission to be exactly where she was. She felt a deep, grounding peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You aren't a project to be finished; you are a garden to be tended. Be patient with your soul. Some of your greatest growth is happening underground right now.”</p>
        }
      ]
    }
  },
  {
    id: "growth_5",
    category: "Growth",
    title: "The Strength in Asking",
    img: "https://picsum.photos/seed/gro5/300/400",
    content: {
      title: "Finding a Mentor",
      pages: [
        {
          title: "The Burden of Knowing",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She thought being an adult meant having all the answers. When she hit a wall in her projects or her personal life, she would hide it, afraid that admitting she was stuck would expose her as a "fraud." She was white-knuckling her way through every challenge, alone and increasingly exhausted.</p>
              <p>She saw others succeeding and assumed they were just "gifted," never realizing they were actually just good at asking for directions.</p>
            </>
          )
        },
        {
          title: "The Open Door",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She finally sent the email. "I admire your work, and I'm struggling with... could you spare ten minutes?" To her shock, the person replied with enthusiasm. They didn't see her as a failure; they saw her as a peer who was brave enough to learn. The advice they gave saved her weeks of frustration.</p>
              <p>She realized that mentorship isn't a one-way street; it's a bridge between experience and curiosity. By asking for help, she hadn't given up her power; she had multiplied it. She felt a new sense of community. She wasn't alone anymore.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“No one builds a beautiful life entirely on their own. Asking for help is the ultimate act of self-respect. Let others be the wind in your sails.”</p>
        }
      ]
    }
  },
  {
    id: "growth_6",
    category: "Growth",
    title: "The Lifelong Student",
    img: "https://picsum.photos/seed/gro6/300/400",
    content: {
      title: "Continuous Learning",
      pages: [
        {
          title: "The Plateau of Same",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had reached a point where her life felt like a loop. She knew what to expect, she knew her routine, and she was... comfortable. But the comfort felt like dust. She missed the thrill of being confused, the spark of a new idea, the feeling of her brain stretching to accommodate something big.</p>
              <p>She was becoming an expert at her own narrow world, but she was losing her edge. She was safe, but she wasn't actually growing.</p>
            </>
          )
        },
        {
          title: "The Horizon Shift",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She signed up for a class that had nothing to do with her career or her studies. It was something totally random—astronomy. As she learned about the scale of the universe and the birth of stars, her own problems started to feel more manageable. Her world got bigger, and so did her sense of self.</p>
              <p>She realized that learning isn't a phase of life; it's the music of life. By staying a student, she was staying young, flexible, and vibrantly alive. She discovered that the best thing about knowing a lot was realizing how much more there was to love. She felt inspired.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Education is a journey without a destination. The moment you stop being a student, you stop being an explorer. Stay curious; stay hungry for the 'more'.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_4",
    category: "Confidence",
    title: "Owning Your Voice",
    img: "https://picsum.photos/seed/con4/300/400",
    content: {
      title: "Public Speaking",
      pages: [
        {
          title: "The Trembling Stage",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Her name was called, and it felt like a death sentence. As she walked to the front of the classroom, her knees felt like water and her vision began to tunnel. She had a speech prepared, but every word felt like lead in her mouth. She was sure that everyone could hear her heart drumming against her ribs, and she was certain they were all just waiting for her to fail.</p>
              <p>The fear of judgment was a roar in her ears, silencing the very message she had worked so hard to craft.</p>
            </>
          )
        },
        {
          title: "The Brave Breath",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She paused. She remembered what her mother had told her: "They aren't there to judge you; they're there to hear you." She took one deep, grounding breath and looked up. She found one friendly face in the middle row and started speaking directly to them. Slowly, the tunnel vision cleared. Her voice, shaky at first, grew steady and resonant.</p>
              <p>She finished her last sentence and the room was silent for a heartbeat before the applause started. She hadn't been perfect, but she had been real. She realized that courage isn't the absence of fear, but the decision that something else is more important. She felt powerful.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The world needs your unique voice, even if it shakes. Don't let your fear silence the truth you were meant to share.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_5",
    category: "Confidence",
    title: "Defeating the Imposter",
    img: "https://picsum.photos/seed/con5/300/400",
    content: {
      title: "Understanding Your Worth",
      pages: [
        {
          title: "The Fraud in the Mirror",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She stood in the middle of the achievement ceremony, holding her trophy, and all she could think was, "They made a mistake." She was sure that any moment now, someone would realize she wasn't actually that smart, or that hard-working, or that capable. She felt like a thief who had stolen someone else's success, waiting for the sirens to start.</p>
              <p>The louder the world cheered for her, the louder her internal critic whispered that it was all just a fluke.</p>
            </>
          )
        },
        {
          title: "The Evidence of Effort",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She went home and looked at her old notebooks—the messy first drafts, the crossed-out math problems, the late-night coffee stains. She saw the evidence of her own struggle, her own persistence, and her own growth. These weren't the tools of a fraud; they were the scars of a student. She hadn't "gotten lucky"; she had gotten better.</p>
              <p>She realized that imposter syndrome is just a shadow that follows great effort. She decided to stop apologizing for her space in the room and start occupying it with pride. She wasn't a fake; she was a work in progress who had earned her place. She felt grounded.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You aren't here by accident. You are here because of every choice you made and every challenge you met. Own your wins as much as you own your mistakes.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_6",
    category: "Confidence",
    title: "The Power of Choice",
    img: "https://picsum.photos/seed/con6/300/400",
    content: {
      title: "Decision Confidence",
      pages: [
        {
          title: "The Crossroads of Doubt",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was paralyzed at a crossroads. Every decision felt like it would determine the entire rest of her life. Should she take the art class or the science elective? Should she go to the party or stay home? She was so afraid of making the "wrong" choice that she ended up making no choice at all, letting time slip through her fingers.</p>
              <p>The weight of the "perfect" decision was crushing her ability to actually live. She was watching life happen to her instead of making life happen for her.</p>
            </>
          )
        },
        {
          title: "The Internal Compass",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to trust her gut—not her fear. She flipped a coin, but not to let it decide for her. She realized that as the coin was in the air, she was secretly hoping for one result over the other. That was her truth. She made the choice and didn't look back. She realized that even if it wasn't the "perfect" path, it was *her* path.</p>
              <p>She discovered that the strength of a decision comes from the commitment to it, not the perfection of it. She could always adjust her course later, but she had to be moving first. She felt a surge of autonomy. She was finally the driver of her own life. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Trust your inner compass. Most choices aren't dead ends; they're just detours on the way to discovering who you are. Make a move and own the journey.”</p>
        }
      ]
    }
  },
  {
    id: "school_7",
    category: "School",
    title: "The Exam Mountain",
    img: "https://picsum.photos/seed/sch7/300/400",
    content: {
      title: "Preparation Peace",
      pages: [
        {
          title: "The Tower of Stress",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Her desk was buried under mountains of textbooks, highlighted notes, and half-empty coffee cups. Every time she looked at the pile, her stomach did a nervous flip. The upcoming exams felt like a tidal wave that was about to crash over her, and she felt like she was trying to swim with her shoes on. She was studying hard, but nothing seemed to stick.</p>
              <p>The sheer volume of information was paralyzing. She was paralyzed by the big picture, unable to see the small steps she needed to take.</p>
            </>
          )
        },
        {
          title: "The Strategy of Small",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop looking at the mountain and start looking at the path. She broke her subjects into tiny, manageable "bites"—twenty minutes of review, five practice problems, one chapter summary. She used a timer to stay focused, and she gave herself permission to rest. Slowly, the overwhelming noise in her head began to subside.</p>
              <p>She realized that preparation isn't about knowing everything at once; it's about being consistent with the little bits every day. On the day of the exam, she didn't feel like a genius, but she felt *ready*. The wave didn't crash; she learned to surf it. She felt capable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Success in school is built in the quiet, small moments of preparation. Don't fear the mountain; just focus on the next step right in front of you.”</p>
        }
      ]
    }
  },
  {
    id: "school_8",
    category: "School",
    title: "Sharing Your Light",
    img: "https://picsum.photos/seed/sch8/300/400",
    content: {
      title: "Class Participation",
      pages: [
        {
          title: "The Quiet Corner",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was the girl in the back row who always knew the answer but never raised her hand. She was afraid that her voice would sound weird, or that her answer wasn't "perfect" enough, or that people would think she was trying too hard. She was a library of knowledge that no one ever got to read, and it felt increasingly lonely in her silent corner.</p>
              <p>By keeping her thoughts to herself, she was accidentally robbing her classmates of a perspective that only she had.</p>
            </>
          )
        },
        {
          title: "The Hand in the Air",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to take a risk. During a particularly interesting discussion, she felt a thought bubble up that she just couldn't ignore. She raised her hand. Her voice cracked slightly, but she said what she needed to say. To her surprise, the teacher smiled and her classmates nodded in agreement. Her comment had opened up a whole new direction for the talk.</p>
              <p>She realized that participate isn't about being the "best"; it's about being part of the "whole." Her voice mattered, not because it was perfect, but because it was hers. She started to feel like she belonged in the room. She felt seen.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your thoughts have value. Don't hide them away for fear of being imperfect. Every time you speak, you add a new color to the world's conversation.”</p>
        }
      ]
    }
  },
  {
    id: "school_9",
    category: "School",
    title: "Beyond the Chalkboard",
    img: "https://picsum.photos/seed/sch9/300/400",
    content: {
      title: "Teacher Connections",
      pages: [
        {
          title: "The Wall of Authority",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She saw her teachers as distant, unapproachable figures who only cared about grades and deadlines. When she was struggling with a complex concept, she would stay quiet, assuming that asking for help would be seen as a sign of weakness or laziness. She was drowning in confusion while the lifeboats were floating right in front of her.</p>
              <p>She felt like a number in a spreadsheet, rather than a student in a classroom.</p>
            </>
          )
        },
        {
          title: "The Human Connection",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stay after class for five minutes. "I'm having trouble with the second part of the lecture... could you explain it differently?" The teacher stopped what they were doing and their eyes lit up. They didn't just explain it; they shared a story about how they had struggled with the same thing when they were a student.</p>
              <p>She realized that teachers are people who love to see their students grow. By reaching out, she hadn't just gotten an answer; she had built a relationship. School felt less like a factory and more like a community. She felt supported.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Never be afraid to seek guidance. The people who teach you are there because they believe in your potential. Let them help you find your path.”</p>
        }
      ]
    }
  },
  {
    id: "future_6",
    category: "Future",
    title: "The Brave Pause",
    img: "https://picsum.photos/seed/fut6/300/400",
    content: {
      title: "Gap Year Dreams",
      pages: [
        {
          title: "The Conveyor Belt",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Everything felt like a pre-determined race. High school, then college, then career, then retirement. She looked at her friends who were already obsessing over university applications, and she felt... nothing. No spark, no excitement, just a deep, growing sense of dread that she was jumping into a life she hadn't actually chosen.</p>
              <p>The pressure to "keep up" was a weight that was making it impossible for her to hear her own heart.</p>
            </>
          )
        },
        {
          title: "The Unmapped Year",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to step off the conveyor belt. She told her parents she wanted to take a year to work, volunteer, and just *be*. It was the scariest decision she'd ever made, especially as she watched her peers move into dorms. But in that year of breathing room, she discovered passions she never knew she had. She learned how to budget, how to talk to strangers, and most importantly, how to trust herself.</p>
              <p>She realized that life isn't a race to the finish line; it's a series of experiences. By taking the pause, she wasn't falling behind; she was finally getting ahead of her own fears. She entered college a year later, not as a tired runner, but as a deliberate pioneer. She felt ready.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your timeline is yours alone. Don't be afraid to take a breath and explore the unmapped paths. Sometimes the best way to find your future is to stop racing toward it.”</p>
        }
      ]
    }
  },
  {
    id: "future_7",
    category: "Future",
    title: "Building a New Home",
    img: "https://picsum.photos/seed/fut7/300/400",
    content: {
      title: "University Transitions",
      pages: [
        {
          title: "The Empty Nest",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She stood in the middle of her tiny, bare dorm room, the sound of her parents' car fading in the distance. The silence was deafening. For the first time in her life, she was completely on her own. No one to tell her when to wake up, what to eat, or how to handle the sudden, sharp ache of homesickness. She felt like a small boat lost in a very large ocean.</p>
              <p>The fear of not fitting in, of failing her classes, and of being forever alone was a storm cloud she couldn't escape.</p>
            </>
          )
        },
        {
          title: "The Open Door Policy",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to prop her door open and put a plate of cookies on the desk. One by one, people started peeking in. A girl from down the hall, a guy from her lab, someone who just liked the smell of vanilla. They sat on the floor and talked until 2 AM about their own fears and their own families. She realized that everyone was just as terrified as she was.</p>
              <p>She discovered that home isn't just a place; it's the people you choose to brave the world with. By being the first to be vulnerable, she had created a sanctuary for herself and others. She wasn't an island; she was the architect of her own community. She felt at home.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Every new beginning is a chance to build the version of home you've always wanted. Don't be afraid of the empty room; it's just a canvas waiting for your story.”</p>
        }
      ]
    }
  },
  {
    id: "future_8",
    category: "Future",
    title: "The First Threshold",
    img: "https://picsum.photos/seed/fut8/300/400",
    content: {
      title: "Taking Flight",
      pages: [
        {
          title: "The Shaky Start",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She sat at her new desk on her first day of work, feeling like a complete imposter. Everyone around her seemed so professional, so busy, and so sure of themselves. She was terrified of making a mistake, of asking a "stupid" question, or of being found out as the beginner she truly was. She felt like she was playing dress-up in a world that didn't belong to her.</p>
              <p>The weight of responsibility was a heavy cloak that made her want to hide under her desk.</p>
            </>
          )
        },
        {
          title: "The Humble Ascent",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to embrace the "beginner" label. She brought a notebook everywhere, she asked questions, and she volunteered for the tasks no one else wanted. She made a few mistakes, but into her surprise, her colleagues were patient and even appreciative of her effort. She realized that everyone starts at the bottom, and the only "stupid" question is the one you don't ask.</p>
              <p>She discovered that competence isn't something you're born with; it's something you build, one day at a time. By the end of the month, she wasn't just working; she was contributing. She had turned her fear into a fuel for learning. She finally felt like she belonged. She felt capable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Every career is a story of a thousand small starts. Don't be afraid to be the beginner; that's where the most exciting growth happens. Trust your ability to learn.”</p>
        }
      ]
    }
  },
  {
    id: "identity_6",
    category: "Identity",
    title: "The Mirror of Self",
    img: "https://picsum.photos/seed/ide6/300/400",
    content: {
      title: "Style Evolution",
      pages: [
        {
          title: "The Uniform of Others",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to dress exactly like the girls in the magazines and the popular influencers on her feed. She wore the same colors, the same cuts, and the same logos, hoping that by looking the part, she would finally feel like she belonged. But every time she looked in the mirror, she saw a stranger. Her clothes felt like a costume that was slightly too tight for her spirit.</p>
              <p>She was perfectly "on trend," but she felt completely invisible in her own skin.</p>
            </>
          )
        },
        {
          title: "The authentic Hue",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>One day, she walked into a thrift store and found a vintage jacket that everyone else would have called "weird." She loved it. She started mixing patterns, wearing oversized sweaters, and choosing colors that actually made her feel happy. Slowly, the "trendy" girl faded and the real her began to emerge. People noticed the shift—not because of the clothes, but because of the brightness in her eyes.</p>
              <p>She realized that style isn't about following a map; it's about drawing your own. Her wardrobe became a collection of memories and moods, a physical expression of her internal world. She wasn't just dressed; she was expressed. She felt like herself.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Clothes are just the packaging for a soul. Don't be afraid to rip up the instructions and dress for the person you see when you're alone. Your true style is your most beautiful signature.”</p>
        }
      ]
    }
  },
  {
    id: "identity_7",
    category: "Identity",
    title: "The Circle of Belonging",
    img: "https://picsum.photos/seed/ide7/300/400",
    content: {
      title: "Finding Your Tribe",
      pages: [
        {
          title: "The Missing Piece",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like a puzzle piece that had been put into the wrong box. At school, she hung out with people she didn't really relate to, laughing at jokes she didn't find funny and talking about things she didn't care about. She was surrounded by people, but she felt profoundly lonely. She was molding herself to fit a shape that wasn't hers, and the pressure was leaving her exhausted.</p>
              <p>The fear of being "weird" was a wall that was keeping her from finding the people who would actually love her for it.</p>
            </>
          )
        },
        {
          title: "The Shared Spark",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop pretending. She joined the school's robotics club, even though it wasn't "cool." There, she met people who geeked out over the same code, who shared her love for old sci-fi movies, and who didn't care if she was quiet. They weren't just a group; they were a community. For the first time, she didn't have to explain herself; she was just... understood.</p>
              <p>She discovered that belonging isn't something you earn by changing; it's something you find by being. By embracing her true interests, she hadn't just found a hobby; she had found her tribe. She realized that being "weird" together is the most beautiful way to be. She felt accepted.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Don't spend your life trying to fit into a circle that wasn't meant for you. Be the shape you are, and you will eventually find the rest of the puzzle. Authenticity is the magnet for your true community.”</p>
        }
      ]
    }
  },
  {
    id: "identity_8",
    category: "Identity",
    title: "The Spectrum of You",
    img: "https://picsum.photos/seed/ide8/300/400",
    content: {
      title: "True Colors",
      pages: [
        {
          title: "The Narrow Box",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like the world had given her a very specific script to follow—how she should act, what she should like, and who she should be as a "girl." But the script felt like it was written in a language she didn't speak. She felt limited by the binaries and the expectations, like she was being forced to choose a color from a two-shade palette when she was seeing in rainbows.</p>
              <p>The pressure to conform to a standard she didn't recognize was a weight that was muffling her true voice.</p>
            </>
          )
        },
        {
          title: "The Radiant Expression",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop asking permission to be herself. She started exploring different ways of expressing her gender, her style, and her identity. Some days she felt bold and masculine; other days she felt soft and feminine; and many days, she was something entirely new that didn't have a label yet. She realized that identity isn't a destination; it's a journey of discovery.</p>
              <p>She discovered that the categories she had feared were actually just suggestions, and she was free to ignore them. By living in the spectrum, she wasn't just "finding" herself; she was *creating* herself. She felt a profound sense of freedom and pride in her own unique expression. She felt like a masterpiece.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are not a checkmark on a list of societal expectations. You are a vast, multifaceted, and ever-changing universe. Honor every part of who you are, without apology.”</p>
        }
      ]
    }
  },
  {
    id: "selflove_5",
    category: "Self-Love",
    title: "The Quiet Victory",
    img: "https://picsum.photos/seed/lov5/300/400",
    content: {
      title: "Celebrating Yourself",
      pages: [
        {
          title: "The Shrugging Off",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had a habit of downplaying everything she achieved. When she got an 'A' on a hard paper, she said it was "luck." When she finally mastered a difficult song on the piano, she said the "keys were just feeling good." She was a master of the graceful shrug, brushing off her own effort as if it were a speck of dust. She was waiting for a giant parade to tell her she was good enough, but in the waiting, she was starving her own pride.</p>
              <p>By waiting for external validation, she was giving the keys to her happiness to everyone but herself.</p>
            </>
          )
        },
        {
          title: "The Private Cheer",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start holding her own small ceremonies. When she did something hard, she stopped and said out loud, "I'm really proud of how you handled that." She bought herself a favorite flower, or took an extra ten minutes to read, not as a distraction, but as a deliberate reward. She realized that the most important "good job" wasn't the one she got from a teacher or a parent—it was the one she gave herself.</p>
              <p>She discovered that self-worth isn't a destination; it's a practice of recognition. By celebrating the small wins, she was building a reservoir of confidence that no one could take away. She wasn't just "getting by"; she was flourishing. She felt worthy.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Don't wait for the world to notice your light. Be your own primary audience, your own loudest fan, and your own most patient supporter. Your victories are enough, exactly as they are.”</p>
        }
      ]
    }
  },
  {
    id: "selflove_6",
    category: "Self-Love",
    title: "The Gift of Forgiveness",
    img: "https://picsum.photos/seed/lov6/300/400",
    content: {
      title: "Releasing the Past",
      pages: [
        {
          title: "The Heavy Baggage",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was a collector of her own mistakes. She could remember exactly what she had said "wrong" at a party three years ago, the grade she didn't get in middle school, and every times she had ever let someone down. She carried these memories like heavy stones in a backpack, and she was starting to hunch under the weight. She was holding herself hostage to a version of herself that didn't even exist anymore.</p>
              <p>The shame of the past was a thief that was stealing her ability to enjoy the present.</p>
            </>
          )
        },
        {
          title: "The Grace of Letting Go",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She realized she was being a far harsher judge than anyone else in her life. She decided to write down her biggest regrets and then, one by one, tell that younger version of herself: "It's okay. You were learning." She realized that growth requires room, and her heart was too full of old shame to accommodate new joy. She decided to forgive the girl she used to be so she could support the woman she was becoming.</p>
              <p>She discovered that forgiveness isn't about saying what you did was "good"; it's about saying it's "over." By releasing the past, she finally found the strength to stand tall. She felt light. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are allowed to grow out of your mistakes. You are allowed to be a new person today. Don't let the shadows of yesterday dim the radiant clarity of your 'now'.”</p>
        }
      ]
    }
  },
  {
    id: "selflove_7",
    category: "Self-Love",
    title: "Looking with Love",
    img: "https://picsum.photos/seed/lov7/300/400",
    content: {
      title: "The Mirror Practice",
      pages: [
        {
          title: "The Critical Gaze",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to avoid mirrors. When she couldn't avoid them, she used them as tools for self-dissection—noticing every blemish, every curve that wasn't "right," and every feature she wished she could change. She was a stranger to the person looking back at her, a harsh auditor of her own physical existence. She was missing the person for the "parts."</p>
              <p>The habit of self-criticism had become a filter through which she saw the entire world.</p>
            </>
          )
        },
        {
          title: "The Compassionate Reflection",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try something radical. She looked into her own eyes in the mirror for one full minute without saying anything negative. At first, it was agonizingly uncomfortable. But then, she saw the strength in her own gaze, the kindness in the corners of her eyes, and the history written in her expression. She spoke to her reflection: "I see you. I'm on your team."</p>
              <p>She realized that her body wasn't an ornament; it was an instrument of her existence. By choosing to look with love, she wasn't "fixing" herself—she was finally accepting herself. She discovered that the most beautiful thing about her wasn't a feature; it was her spirit. She felt radiant.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The eyes looking back at you in the mirror belong to your oldest friend and most constant companion. Be kind to her. She's been through everything with you.”</p>
        }
      ]
    }
  },
  {
    id: "boundaries_6",
    category: "Boundaries",
    title: "The Courage of 'No'",
    img: "https://picsum.photos/seed/bou6/300/400",
    content: {
      title: "Time Management",
      pages: [
        {
          title: "The Endless Autumn",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was the girl who said "yes" to everything. Need help with a poster? Yes. Want to join a third club? Yes. Can you babysit on Friday night? Yes. Her calendar was a chaotic mosaic of other people's needs, and she was disappearing in the middle of it. She was perpetually busy, but she felt like she was accomplishing nothing of her own. She was a fading spark in a crowded room.</p>
              <p>The fear of disappointing others was a leash that was keeping her from running her own race.</p>
            </>
          )
        },
        {
          title: "The Sacred Space",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to reclamation her time. When the next request came, she paused, took a breath, and said, "I'd love to help, but I've already committed my time to something else." That "something else" was her own rest, her own studies, and her own peace. To her surprise, the world didn't end. People respected her decision, and she finally had the energy to do her own work with excellence.</p>
              <p>She realized that "no" isn't a rejection of others; it's a protection of self. By drawing a line around her time, she had created a sanctuary where she could finally hear her own thoughts. She discovered that her "yes" only had value because she was finally capable of saying "no." She felt respected. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your time is your most precious and non-renewable resource. Guard it with the same fierceness you'd guard your dreams. A 'no' to others is often the most profound 'yes' you can give to yourself.”</p>
        }
      ]
    }
  },
  {
    id: "boundaries_7",
    category: "Boundaries",
    title: "The Fence of Privacy",
    img: "https://picsum.photos/seed/bou7/300/400",
    content: {
      title: "Personal Space",
      pages: [
        {
          title: "The Open Border",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like she lived in a house without doors. Her siblings would walk into her room without knocking, her friends would borrow her things without asking, and people felt entitled to her deepest secrets as if they were public property. She was being "polite" and "easy-going," but inside, she was vibrating with a silent, frustrated scream. Her personal space was a shared commons that she hadn't agreed to.</p>
              <p>The habit of being "nice" was a trap that was allowing others to graze in her garden until nothing was left.</p>
            </>
          )
        },
        {
          title: "The Gentle Gate",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She started to build gates. She asked for a "knock first" rule. She said, "I'm not comfortable sharing that right now." She started putting her favorite things away. It felt aggressive at first, like she was being "mean," but then she noticed the shift. When people respecting her boundaries, she actually enjoyed their company more. She wasn't resentful anymore because she finally felt safe.</p>
              <p>She realized that boundaries aren't walls to keep people out; they're gates to let the *right* kind of interaction in. By defining her space, she had taught others how to love her properly. She wasn't an open book; she was a private sanctuary, and she liked it that way. She felt safe.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your privacy is a human right, not a luxury. Don't feel guilty for wanting a space that is entirely your own. Clear fences make for beautiful, respectful gardens.”</p>
        }
      ]
    }
  },
  {
    id: "boundaries_8",
    category: "Boundaries",
    title: "Lightening the Load",
    img: "https://picsum.photos/seed/bou8/300/400",
    content: {
      title: "Emotional Boundaries",
      pages: [
        {
          title: "The Unpaid Therapist",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was the one everyone turned to when their world was falling apart. She listened for hours to her friends' heartbreaks, her family's stress, and her classmates' anxieties. She was a reservoir for other people's tears, but she had no way to drain the water. She felt heavy, gray, and increasingly numb. She was carrying a thousand stories that weren't hers, and they were burying her alive.</p>
              <p>She thought that being "empathetic" meant being an "emotional sponge." She didn't realize she was absorbing poison along with the pain.</p>
            </>
          )
        },
        {
          title: "The Emotional Anchor",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to learn the difference between "holding space" and "taking on." She practiced saying, "I care about you, but I don't have the emotional bandwidth to listen to this right now." She started taking long, silent walks to shake off the energy of others. To her surprise, her friends didn't leave—they just learned to ask if she was ready before they dumped their burdens.</p>
              <p>She realized that she couldn't pour from an empty cup. By checking her own levels first, she actually became a better friend because she was listening from a place of choice, not obligation. She wasn't a sponge anymore; she was an anchor, solid and separate. She felt light. She felt herself again.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are not a dumping ground for the world's problems. It is okay to be a listener, but it is also okay to close the door when you're full. Protect your heart; it's the only one you've got.”</p>
        }
      ]
    }
  },
  {
    id: "resilience_5",
    category: "Resilience",
    title: "The Inner Shelter",
    img: "https://picsum.photos/seed/res5/300/400",
    content: {
      title: "Coping Skills",
      pages: [
        {
          title: "The Unexpected Storm",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Life was moving along smoothly until it wasn't. A sudden family emergency, a broken friendship, and a failed project all hit at once. She felt like she was standing in the middle of a hurricane without a coat. Her usual routines were shattered, and her sense of security was gone. She felt small, fragile, and utterly exposed to the elements.</p>
              <p>The overwhelming nature of the crisis was a roar that was drowning out her ability to think clearly.</p>
            </>
          )
        },
        {
          title: "The Toolkit of Peace",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She remembered her "emergency kit"—not a physical one, but a mental one. She started with five deep breaths. She reached out to a trusted mentor. She wrote down three things she could control. Slowly, the hurricane didn't stop, but she found the eye of it. She discovered that her peace wasn't dependent on the weather outside, but on the shelter she built inside.</p>
              <p>She realized that resilience isn't about avoiding the storm; it's about knowing you have the tools to weather it. By practicing her coping skills, she wasn't just "surviving"; she was learning the terrain of her own strength. She felt grounded. She felt capable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The world will sometimes be chaotic, but you carry a sanctuary within you. Trust your tools, trust your breath, and trust that you have the strength to hold steady.”</p>
        }
      ]
    }
  },
  {
    id: "resilience_6",
    category: "Resilience",
    title: "The Search for Light",
    img: "https://picsum.photos/seed/res6/300/400",
    content: {
      title: "Positive Outlook",
      pages: [
        {
          title: "The Perpetual Twilight",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was going through a "gray season." Nothing was disastrously wrong, but nothing felt right either. Everything was muffled, dull, and heavy. She was losing her spark, and she was starting to believe that the world was just naturally a dark and difficult place. She was looking at life through a filter of "why bother?" and it was making her world very small.</p>
              <p>The habit of focusing on the gray was a shadow that was growing every day.</p>
            </>
          )
        },
        {
          title: "The Smallest Ray",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to go on a "glimmer hunt." Every day, she had to find three tiny things that were beautiful or kind. A particularly vibrant sunset, a stranger holding a door, the perfect temperature of her tea. At first, it felt forced and silly. But slowly, her brain started looking for the light automatically. The gray didn't disappear, but it became a background for the stars she was finding.</p>
              <p>She realized that optimism isn't about ignoring the dark; it's about being the one who holds the candle. By actively seeking the good, she was rewiring her own heart for hope. She discovered that even in the longest winter, the sun still exists. She felt hopeful. She felt bright.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Hope is a choice, not a feeling. Don't wait for the light to find you; go out and find the glimmers yourself. There is always something beautiful waiting to be noticed.”</p>
        }
      ]
    }
  },
  {
    id: "resilience_7",
    category: "Resilience",
    title: "The Second Wind",
    img: "https://picsum.photos/seed/res7/300/400",
    content: {
      title: "Grit and Grace",
      pages: [
        {
          title: "The Wall of Exhaustion",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had been working toward her dream for months, and she had finally hit a wall. She was tired, discouraged, and convinced that she simply didn't have what it took. Every setback felt like a personal indictment of her character. She was ready to pack up her tools and admit defeat. She was standing at the edge of her own potential, and the view was terrifying.</p>
              <p>The fear of failure was a cold wind that was blowing out her internal fire.</p>
            </>
          )
        },
        {
          title: "The Grace to Continue",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to rest, not quit. She took a weekend off, unplugged, and focused on things that had nothing to do with her goal. In the silence, her "second wind" arrived. It wasn't a sudden burst of energy, but a quiet, steady resolve. She realized that "grit" isn't about never failing; it's about what you do the morning after. She got back to work, but with more grace for herself.</p>
              <p>She discovered that persistence is the most powerful tool in her arsenal. By refusing to let one bad day be the final chapter, she was writing a story of triumph. She wasn't just moving forward; she was ascending. She felt strong. She felt unstoppable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Success is often just on the other side of the moment you most want to quit. Give yourself grace, take the rest you need, but never let go of the dream you were meant to live.”</p>
        }
      ]
    }
  },
  {
    id: "digital_5",
    category: "Digital",
    title: "The High Road Online",
    img: "https://picsum.photos/seed/dig5/300/400",
    content: {
      title: "Digital Citizenship",
      pages: [
        {
          title: "The Bait",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She saw a comment on her post that was deliberately cruel, meant to spark a reaction and hurt her feelings. Her fingers hovered over the keyboard, ready to fire back a witty, equally sharp response. She felt the heat of anger rising in her chest, the urge to "win" the argument blinding her to the fact that she was about to play a game she couldn't win.</p>
              <p>The toxicity of the internet was invited her to step into the mud, and she was dangerously close to saying "yes."</p>
            </>
          )
        },
        {
          title: "The Peace of Silence",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to put her phone down. She took a walk, breathed the real air, and realized that a stranger's opinion didn't define her worth. She went back and simply blocked the user, choosing silence over conflict. She realized that her peace was more valuable than proving a point to someone who wasn't actually listening. She had taken the high road, and it was much clearer up there.</p>
              <p>She discovered that digital maturity is knowing when to engage and when to walk away. By protecting her space, she had maintained her dignity. She didn't let the troll steal her joy. She felt powerful. She felt at peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your online character is a reflection of your real heart. Don't let the noise of the internet bait you into becoming someone you don't recognize. Silence is often the most powerful response.”</p>
        }
      ]
    }
  },
  {
    id: "digital_6",
    category: "Digital",
    title: "Looking Up",
    img: "https://picsum.photos/seed/dig6/300/400",
    content: {
      title: "Screen-Life Balance",
      pages: [
        {
          title: "The Blue Light Tunnel",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She realized she had spent five hours in a row scrolling through endless feeds, watching short clips of people she didn't know doing things she didn't care about. Her eyes were dry, her neck was stiff, and she felt a strange, hollow sense of exhaustion. She was "connected" to the whole world, but she had never felt more isolated from her own life. She was a zombie in a digital forest.</p>
              <p>The convenience of the screen had become a cage that was keeping her from the tangible beauty of the world.</p>
            </>
          )
        },
        {
          title: "The 3D Awakening",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She turned her phone off and put it in a drawer. She walked outside and was hit by the smell of rain and the sound of birds in the trees. She noticed the way the light hit the leaves, the texture of the bark, and the feeling of her feet on the ground. She felt her senses waking up, her brain clearing, and her heart starting to beat in sync with reality again. She was finally *here*.</p>
              <p>She discovered that the most important moments happen in the spaces between the pixels. By choosing to look up, she hadn't just saved her eyes; she had saved her day. She realized that the digital world is a tool, not a home. She felt alive. She felt connected.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The most beautiful parts of your life don't have a 'share' button. Don't forget to put the screen down and experience the world with all your senses. Reality is the ultimate high-definition.”</p>
        }
      ]
    }
  },
  {
    id: "digital_7",
    category: "Digital",
    title: "Privacy as Power",
    img: "https://picsum.photos/seed/dig7/300/400",
    content: {
      title: "Digital Safety",
      pages: [
        {
          title: "The Over-Share",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to post everything—her location, her moods, her breakfast, her deepest thoughts. She felt like if she didn't share it, it didn't really happen. But she started to feel a strange vulnerability, like she was living in a glass house where everyone could watch her even when she wasn't looking. She was giving away her mystery, one post at a time, and she felt increasingly hollow.</p>
              <p>The pressure to be "seen" was making her lose sight of the person she was when no one was watching.</p>
            </>
          )
        },
        {
          title: "The Sacred Secret",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to reclamation her privacy. She locked her accounts, deleted old posts, and started keeping her best moments just for herself. She realized that some memories are too precious to be reduced to a caption. She felt a new sense of power in having a private life that was entirely her own. She wasn't just "content"; she was a person with a hidden garden.</p>
              <p>She discovered that mystery is a form of strength. By choosing what to share and what to hold close, she was finally the one in control of her own narrative. She didn't need the world's 'likes' to know she was living a good life. She felt whole. She felt private.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Not everything is meant for the feed. Keep some of your light, your tears, and your dreams just for yourself. Privacy is the sanctuary where your true self can grow in peace.”</p>
        }
      ]
    }
  },
  {
    id: "leadership_5",
    category: "Leadership",
    title: "The Far Horizon",
    img: "https://picsum.photos/seed/lea5/300/400",
    content: {
      title: "Visionary Leadership",
      pages: [
        {
          title: "The Narrow View",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>The team was stuck. They were arguing over small details, missing deadlines, and losing their motivation. Everyone was so focused on the problems right in front of them—the broken equipment, the lack of supplies, the personality clashes—that they couldn't see the goal they were supposed to be working toward. They were a ship's crew fighting over the rations while the vessel drifted toward the rocks.</p>
              <p>The absence of a clear common purpose was a fog that was hiding the path forward.</p>
            </>
          )
        },
        {
          title: "The Guiding Star",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stand up and point to the horizon. "Remember why we started this?" she asked. She didn't just give orders; she shared a vision of what they could achieve together. She spoke about the impact they would have, the people they would help, and the pride they would feel. Slowly, the arguing stopped. The team started to look up from the floor and toward the future.</p>
              <p>She realized that leadership isn't just about managing tasks; it's about holding the "why" when others forget it. By being the one with the vision, she had given the team their energy back. They weren't just working; they were building a masterpiece. She felt like a navigator. She felt proud.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“A true leader doesn't just manage the present; they illuminate the future. Be the one who carries the vision, and you will inspire others to find their own strength to follow.”</p>
        }
      ]
    }
  },
  {
    id: "leadership_6",
    category: "Leadership",
    title: "Leading from Below",
    img: "https://picsum.photos/seed/lea6/300/400",
    content: {
      title: "Servant Leadership",
      pages: [
        {
          title: "The Crown of Ego",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to think that being a leader meant being the "boss." She wanted the loudest voice, the best office, and for everyone to do exactly what she said. She was a manager of people, not a leader of a team. She felt important, but she also felt a growing distance between herself and the people who were supposed to be working *with* her. She was a ruler on a lonely hill.</p>
              <p>The habit of putting her own status first was a barrier that was keeping the team from truly trusting her.</p>
            </>
          )
        },
        {
          title: "The Hands of Help",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try a different approach. She started asking, "What do you need from me today?" She spent her morning helping the newer members with their basic tasks, she brought the team snacks, and she was the last one to leave the room. She realized that by serving the team, she wasn't losing her authority—she was finally earning it. The team started to work harder, not because they were told to, but because they felt supported.</p>
              <p>She discovered that the greatest leaders are the ones who lift others up. By putting her ego aside, she had created a culture of mutual respect and excellence. She wasn't just a boss; she was the foundation they all stood on. She felt essential. She felt connected.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Authority is given, but leadership is earned. The most powerful way to lead is to be the one who serves the team's needs before your own. True greatness is found in helping others achieve theirs.”</p>
        }
      ]
    }
  },
  {
    id: "leadership_7",
    category: "Leadership",
    title: "The Silent Strength",
    img: "https://picsum.photos/seed/lea7/300/400",
    content: {
      title: "Leading by Example",
      pages: [
        {
          title: "The Noise of Words",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was great at making speeches about integrity, hard work, and dedication. But when things got difficult, she was the first to take a shortcut. She expected excellence from others that she wasn't willing to provide herself. She was a leader of words, but her actions were telling a very different story. The team was starting to notice the gap between what she said and what she did.</p>
              <p>The lack of consistency was a leak that was slowly draining the team's respect for her.</p>
            </>
          )
        },
        {
          title: "The Power of Action",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop talking and start doing. When a project got messy, she was the first one to dive in. When a mistake was made, she was the first to take responsibility. She showed up early, she stayed late, and she treated everyone with the same respect she demanded. She realized that her most powerful "speech" was the way she lived her life in the quiet, everyday moments.</p>
              <p>She discovered that people don't follow a person's words; they follow their character. By being the example she wanted to see, she had created a standard of excellence that the team followed naturally. She wasn't just commanding; she was inspiring. She felt authentic. She felt like a leader.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your actions speak so loudly that people can't hear what you're saying. Be the person you want your team to be, and your leadership will be unmistakable. Character is the ultimate authority.”</p>
        }
      ]
    }
  },
  {
    id: "emotions_5",
    category: "Emotions",
    title: "Surfing the Waves",
    img: "https://picsum.photos/seed/emo5/300/400",
    content: {
      title: "Self-Regulation",
      pages: [
        {
          title: "The Internal Wildfire",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Her anger felt like a sudden, uncontainable wildfire. One sarcastic comment, one perceived slight, and she was ready to burn everything down. She said things she didn't mean, she made decisions she later regretted, and she left a trail of hurt feelings in her wake. She felt like she was a passenger in her own body, watching the destruction but unable to stop the flames.</p>
              <p>The habit of reacting instantly was a trap that was leaving her exhausted and increasingly isolated.</p>
            </>
          )
        },
        {
          title: "The Art of the Breath",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to learn how to create a "gap" between the stimulus and her response. When she felt the heat rising, she started counting to ten—slowly. She focused on the feeling of her breath entering her lungs, the ground beneath her feet, and the physical sensation of the air around her. She realized that she couldn't stop the fire from starting, but she could choose not to add fuel to it.</p>
              <p>She discovered that self-regulation isn't about being "numb"; it's about being "aware." By mastering her reactions, she had gained a new kind of power—the power of choice. She wasn't a victim of her emotions anymore; she was the navigator of them. She felt calm. She felt in control.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You cannot control the storm, but you can learn how to set your sails. The breath is your anchor in the wildest sea. Trust your ability to find your calm center, no matter how hard the wind blows.”</p>
        }
      ]
    }
  },
  {
    id: "emotions_6",
    category: "Emotions",
    title: "The Bridge of Understanding",
    img: "https://picsum.photos/seed/emo6/300/400",
    content: {
      title: "Practicing Empathy",
      pages: [
        {
          title: "The Wall of Judgment",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was a master of the quick assumption. If someone was late, they were "lazy." If someone was quiet, they were "rude." If someone made a mistake, they were "incompetent." She lived in a world of labels and categories, a safe but sterile landscape where she never had to actually engage with the messy reality of other people's lives. She was right, but she was also alone.</p>
              <p>The habit of judging was a wall that was keeping her from the very connections she was secretly craving.</p>
            </>
          )
        },
        {
          title: "The Second Story",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start asking, "I wonder what else is true for them?" When a classmate snapped at her, she didn't snap back. Instead, she asked if they were okay. She found out they were working two jobs and hadn't slept in thirty hours. She realized that everyone is fighting a hidden battle that she knows nothing about. Her judgment dissolved into a profound sense of compassion.</p>
              <p>She discovered that empathy is a bridge, not a burden. By choosing to understand instead of judge, she had transformed her world from a courtroom into a community. She wasn't just "nice"; she was connected. She felt the warmth of shared humanity. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Every person you meet is a universe of stories you haven't read. Put down the judge's gavel and pick up the lens of curiosity. The more you understand, the less you will need to judge.”</p>
        }
      ]
    }
  },
  {
    id: "emotions_7",
    category: "Emotions",
    title: "The Golden Thread",
    img: "https://picsum.photos/seed/emo7/300/400",
    content: {
      title: "Gratitude Practice",
      pages: [
        {
          title: "The Landscape of Lack",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was living in a world of "not enough." Not smart enough, not pretty enough, not successful enough. She spent her days obsessing over the things she didn't have, the vacations she wasn't taking, and the milestones she hadn't reached. She was a collector of voids, and the emptiness was starting to swallow her whole. She was so focused on the horizon that she was missing the flowers at her feet.</p>
              <p>The habit of comparison was a fog that was hiding the abundance that was already present in her life.</p>
            </>
          )
        },
        {
          title: "The Treasure Hunt",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start a "gratitude journal," but with a twist. She didn't just list things; she described the *feeling* of them. The warmth of the sun on her face, the way her dog's tail thumped when she walked in the door, the perfect crunch of a fresh apple. Slowly, her world began to shift from gray to gold. She realized that she wasn't missing anything; she was just missing the *noticing* of it.</p>
              <p>She discovered that gratitude is the ultimate lens for abundance. By choosing to see the good, she had transformed her life from a race into a celebration. She wasn't just "content"; she was overflowing. She realized that "enough" is a state of mind, not a list of possessions. She felt rich. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Gratitude is the magic that turns what we have into more than enough. Don't wait for the big moments to be thankful; the real treasures are found in the small, everyday glimmers of light.”</p>
        }
      ]
    }
  },
  {
    id: "creativity_5",
    category: "Creativity",
    title: "Fishing for Stars",
    img: "https://picsum.photos/seed/cre5/300/400",
    content: {
      title: "Idea Generation",
      pages: [
        {
          title: "The Silent Well",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She sat in front of a blank canvas, her mind as empty as the white space. She tried to "force" an idea—a brilliant, world-changing concept that would prove she was a "real" artist. But the harder she pushed, the further the inspiration drifted. She felt like she was trying to catch a butterfly with a hammer. She was terrified that she had "run out" of creativity, and that the well had finally gone dry.</p>
              <p>The pressure to be "original" was a weight that was crushing her ability to actually create.</p>
            </>
          )
        },
        {
          title: "The Playful Cast",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop trying to be "good" and start trying to be "silly." She started doodling nonsense, writing half-formed sentences, and combining things that didn't belong together—like a toaster that makes dreams or a forest made of umbrellas. Slowly, the pressure lifted. In the middle of the mess, a tiny, glowing spark of an idea appeared. It wasn't "perfect," but it was *alive*.</p>
              <p>She realized that creativity is a playful conversation with the universe, not a test. By allowing herself to be a beginner again, she had found the key to the well. She discovered that ideas are like fish—you don't "make" them; you just create the conditions where they want to swim. She felt inspired. She felt light.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Don't let the fear of 'bad' ideas keep you from finding the 'good' ones. Creativity thrives on play, curiosity, and the courage to be messy. Cast your net wide and trust the stars will find you.”</p>
        }
      ]
    }
  },
  {
    id: "creativity_6",
    category: "Creativity",
    title: "The Beautiful Mess",
    img: "https://picsum.photos/seed/cre6/300/400",
    content: {
      title: "Overcoming Perfectionism",
      pages: [
        {
          title: "The Polished Cage",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had a project that was 90% finished, and it had been that way for three months. She was obsessed with the final 10%—the perfect font, the exact shade of teal, the "right" opening sentence. She was so afraid of releasing something "imperfect" that she was effectively stifling it. Her work was a beautiful, safe cage where nothing ever happened. She was a master of the "almost."</p>
              <p>The habit of perfectionism was a form of procrastination that was disguised as "excellence."</p>
            </>
          )
        },
        {
          title: "The Brave Launch",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to set a timer. "In one hour, this goes out, no matter what." She worked with a frantic, messy energy, letting go of the tiny details and focusing on the core message. When the timer dinged, she hit 'send' before she could change her mind. To her surprise, people didn't notice the "imperfect" font—they loved the heart and the ideas. Her "mess" was exactly what someone else needed.</p>
              <p>She realized that "done" is the only thing that can actually make an impact. By letting go of the perfect, she had finally found the *useful*. She discovered that her "flaws" were actually the points of connection that made her work human. She felt productive. She felt brave.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Perfection is a mirage that keeps you from the finish line. Embrace the beauty of the 'good enough' and have the courage to share your work with the world. Impact is better than impeccable.”</p>
        }
      ]
    }
  },
  {
    id: "creativity_7",
    category: "Creativity",
    title: "The Fearless Pivot",
    img: "https://picsum.photos/seed/cre7/300/400",
    content: {
      title: "Creative Resilience",
      pages: [
        {
          title: "The Dead End",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had invested everything into a single project, and it had just failed spectacularly. The feedback was harsh, the results were non-existent, and she felt like she had wasted months of her life. She was crushed. She was ready to quit, convinced that this failure was proof that she was a "fake" and that her creative dreams were just a childish delusion.</p>
              <p>The rejection was a heavy blanket that was muffling her ability to see any other possibility.</p>
            </>
          )
        },
        {
          title: "The New Direction",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to look at the wreckage not as a "failure," but as "data." She analyzed what didn't work, what she learned, and what she actually enjoyed about the process. She realized that the "dead end" was actually just a sharp turn toward something much better. she pivoted. She used the lessons from her "failure" to build something entirely new, something stronger and more authentic.</p>
              <p>She discovered that a pivot isn't a retreat; it's a redirection. By refusing to let failure be the final word, she had found her own resilience. She wasn't just "starting over"; she was starting *smarter*. She felt empowered. She felt unstoppable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Failure is just the universe suggesting a different path. Don't be afraid to pivot, to change your mind, and to use your 'mistakes' as the bricks for your next success. Your creativity is unbreakable.”</p>
        }
      ]
    }
  },
  {
    id: "hobby_3",
    category: "Hobby",
    title: "The Line of Truth",
    img: "https://picsum.photos/seed/hob3/300/400",
    content: {
      title: "The Art of Sketching",
      pages: [
        {
          title: "The Shaky Pencil",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She thought she couldn't even draw a straight line. Every time she picked up a pencil, she compared her messy sketches to the masterpieces she saw online. She felt like her hands weren't listening to her brain, and the results were always "ugly." She was a victim of her own high expectations, and the joy of creating was being strangled by the fear of being "bad."</p>
              <p>The habit of self-criticism was a wall that was keeping her from the simple pleasure of expression.</p>
            </>
          )
        },
        {
          title: "The Authentic Stroke",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop trying to draw "things" and start trying to draw "feelings." She let her hand move without a plan, doodling the tangles of her anxiety and the broad, sweeping lines of her excitement. Slowly, the images started to speak. They weren't "perfect," but they were *hers*. She realized that art isn't about replication; it's about revelation.</p>
              <p>She discovered that sketching is a way to see the world more clearly. By allowing herself to be messy, she had found a new kind of clarity. She wasn't just "drawing"; she was documenting her own internal landscape. She felt expressive. She felt at peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The most important master you have to satisfy is yourself. Don't worry about the straightness of the line; focus on the truth of the expression. Every sketch is a conversation with your soul.”</p>
        }
      ]
    }
  },
  {
    id: "hobby_4",
    category: "Hobby",
    title: "Nurturing Life",
    img: "https://picsum.photos/seed/hob4/300/400",
    content: {
      title: "The Soul of Gardening",
      pages: [
        {
          title: "The Concrete Desert",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She lived in a world of concrete and screens. She felt disconnected from the natural cycles of growth and decay, and her life felt increasingly sterile and predictable. She was missing the dirt between her toes and the patient rhythm of the seasons. She was a city girl who was secretly longing for the wild, but she didn't know where to start.</p>
              <p>The absence of nature was a quiet ache that was making her world feel thin and artificial.</p>
            </>
          )
        },
        {
          title: "The Miracle in a Pot",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She bought a single tomato plant and a bag of dirt. She watered it, she spoke to it, and she waited. After weeks of nothing, a tiny green shoot appeared. She felt a surge of pure, uncomplicated joy. As the plant grew, so did her sense of connection to the earth. She realized that she wasn't just "growing a tomato"; she was participating in the miracle of life.</p>
              <p>She discovered that gardening is a practice of patience and hope. By nurturing something else, she had finally learned how to nurture herself. She wasn't just a consumer; she was a co-creator with the universe. She felt grounded. She felt alive.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“To plant a garden is to believe in tomorrow. Don't be afraid to get your hands dirty; the lessons of the earth are the ones your soul needs most. Watch life grow, and you will grow with it.”</p>
        }
      ]
    }
  },
  {
    id: "hobby_5",
    category: "Hobby",
    title: "The Logic of Dreams",
    img: "https://picsum.photos/seed/hob5/300/400",
    content: {
      title: "Learning to Code",
      pages: [
        {
          title: "The Digital Maze",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She looked at the screen full of brackets, semicolons, and strange keywords, and it felt like a language from a different planet. She wanted to build an app, to create something useful, but she felt like she was trying to navigate a maze without a map. She was terrified of making a mistake, of "breaking" the internet, or of simply being too "non-technical" to ever understand.</p>
              <p>The habit of seeing technology as "magic" was a barrier that was keeping her from her own creative power.</p>
            </>
          )
        },
        {
          title: "The First 'Hello'",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start with the smallest possible step. She wrote 'Hello, World' and saw it appear on her screen. She felt a jolt of pure, electric excitement. It wasn't "magic"; it was logic. Slowly, she began to see the patterns, the way a small command could create a big change. She realized that code isn't just for "geniuses"; it's for anyone with the patience to solve a puzzle.</p>
              <p>She discovered that technology is a tool for expression, not just a product to consume. By learning the language of the future, she had gained a new kind of agency. She wasn't just a user; she was a creator. She felt empowered. She felt like a digital wizard.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Don't be intimidated by the tools of the future. The language of logic is just another way to tell your story. Every complex system is built one simple line at a time. Trust your ability to learn.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_4",
    category: "Wellness",
    title: "Savoring the Life",
    img: "https://picsum.photos/seed/wel4/300/400",
    content: {
      title: "Mindful Eating",
      pages: [
        {
          title: "The Fast-Forward Meal",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to eat like it was a chore to be completed as quickly as possible. She would scroll through her phone, watch TV, or even work while she ate, barely noticing the flavor, the texture, or the feeling of being full. She was consuming calories, but she wasn't being nourished. Her relationship with food was a transaction, not an experience.</p>
              <p>The habit of multi-tasking was a filter that was making her life feel rushed and hollow, even in the middle of a meal.</p>
            </>
          )
        },
        {
          title: "The Ritual of Rest",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try a "no-phone" lunch. She sat at the table, looked at her food, and took a slow, deliberate bite. She noticed the crunch of the vegetables, the spice of the sauce, and the simple comfort of the meal. She felt her body relaxing, her mind quietening, and her appreciation for the abundance in her life growing. She wasn't just "eating"; she was participating in a ritual of self-care.</p>
              <p>She discovered that mindfulness isn't about doing "less"; it's about being present for "all." By slowing down, she had found a sanctuary in the middle of her day. She realized that nourishment comes not just from what you eat, but from how you experience it. She felt satisfied. She felt cared for.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Every meal is an opportunity to practice presence. Don't rush through the nourishment the world provides. Savor the flavors, honor the effort, and let the act of eating be a love letter to your body.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_5",
    category: "Wellness",
    title: "Uncoiling the Spring",
    img: "https://picsum.photos/seed/wel5/300/400",
    content: {
      title: "The Power of Stretching",
      pages: [
        {
          title: "The Rigid Frame",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like a coiled spring, ready to snap at any moment. Her shoulders were perpetually hunched toward her ears, her neck was stiff, and every movement felt restricted and heavy. She was carrying the weight of her stress in her muscles, and the physical tension was only adding to her emotional fatigue. She felt trapped in her own skin.</p>
              <p>The habit of holding on was a physical manifestation of a heart that was afraid to let go.</p>
            </>
          )
        },
        {
          title: "The Gentle Release",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to take a five-minute stretch break. She reached for the sky, she touched her toes, and she felt the slow, sweet release of tension in her limbs. She breathed into the tight spots, allowing the breath to melt the knots. Slowly, her body started to feel like a home again, not a cage. She realized that by softening her body, she was also softening her perspective.</p>
              <p>She discovered that physical flexibility is a gateway to mental peace. By giving herself permission to move, she had found a way to let go of the day's burdens. She wasn't just "stretching"; she was unfolding herself back into the world. She felt loose. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is the faithful keeper of your story. When it feels tight and heavy, respond with kindness and movement. Stretch out the stress and make space for your soul to breathe.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_6",
    category: "Wellness",
    title: "The Joy of No-Thing",
    img: "https://picsum.photos/seed/wel6/300/400",
    content: {
      title: "Doing Nothing",
      pages: [
        {
          title: "The Productivity Trap",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was addicted to the "hustle." She felt like every waking hour had to be filled with reading, working, or "self-improvement." If she found herself with ten minutes of silence, she felt a surge of anxiety, as if she were wasting her life. She was a master of efficiency, but she was losing her ability to actually *be*. She was a high-performance machine that was starting to overheat.</p>
              <p>The fear of "nothing" was a noise that was keeping her from hearing her own soul.</p>
            </>
          )
        },
        {
          title: "The Sacred Pause",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to schedule "nothing" for thirty minutes. She sat on her porch and just watched the shadows move across the grass. She didn't listen to a podcast, she didn't check her list, she just *stayed*. To her surprise, the world didn't fall apart. In the silence, her creativity started to spark, her stress started to drain, and she felt a deep, grounded sense of peace she hadn't felt in years.</p>
              <p>She discovered that rest isn't a "reward" for work; it's a *requirement* for life. By choosing the pause, she had found her own rhythm again. She realized that she wasn't just a human "doing"; she was a human "being," and that was enough. She felt rested. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Rest is not a sign of weakness; it's a measure of wisdom. Don't be afraid of the silence or the 'empty' hours. Sometimes the most productive thing you can do is absolutely nothing. Let yourself be.”</p>
        }
      ]
    }
  },
  {
    id: "communication_3",
    category: "Communication",
    title: "Building Bridges",
    img: "https://picsum.photos/seed/com3/300/400",
    content: {
      title: "Conflict Resolution",
      pages: [
        {
          title: "The Shouting Match",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>They were both shouting, but no one was listening. Every "You always..." and "You never..." was a brick in a wall that was rapidly rising between them. She was so focused on being "right" and defending her own position that she had completely lost sight of the person she was arguing with. Her anger was a static that was making communication impossible.</p>
              <p>The habit of defensive reaction was a trap that was turning a disagreement into a war.</p>
            </>
          )
        },
        {
          title: "The Soft Inquiry",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to lower her voice. She took a breath and used an "I" statement: "I feel hurt when I feel like my opinion isn't being heard." She stopped talking and actually listened to the response. She saw the pain in her friend's eyes, the fear behind the anger. Slowly, the wall started to crumble. They weren't fighting each other anymore; they were fighting the problem together.</p>
              <p>She discovered that vulnerability is the most powerful tool in any conflict. By choosing connection over being "right," she had saved the relationship. She realized that a soft answer is the quickest way to end a loud argument. She felt understood. She felt at peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Conflict is an opportunity for a deeper connection if you have the courage to stay soft. Use 'I' statements, listen more than you speak, and remember that the person across from you is more important than the point you're trying to prove.”</p>
        }
      ]
    }
  },
  {
    id: "communication_4",
    category: "Communication",
    title: "The Brave Voice",
    img: "https://picsum.photos/seed/com4/300/400",
    content: {
      title: "Public Speaking",
      pages: [
        {
          title: "The Muffled Truth",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had something important to say, but she was terrified of saying it "wrong." She was sure her voice would shake, her face would turn red, and everyone would realize she wasn't as smart as they thought. She stayed quiet, her thoughts a vibrant, colorful world that no one else ever got to see. She was a silent observer of a life she was supposed to be leading.</p>
              <p>The fear of judgment was a lock that was keeping her gift from the world.</p>
            </>
          )
        },
        {
          title: "The Clear Call",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to speak from her heart, not her head. She shared her story, her fears, and her hopes with a small group. Her voice did shake, and her face was red, but no one cared. They were too busy listening to the truth of what she was saying. She realized that people don't want "perfect"; they want "real." Her message was more important than her nerves.</p>
              <p>She discovered that her voice is a unique instrument that only she can play. By choosing to speak, she hadn't just shared an idea; she had empowered herself. She finally felt like she was participating in her own life. She felt heard. She felt powerful.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your voice has a frequency that the world needs. Don't let your fear of being 'imperfect' silence the wisdom that only you can offer. Speak your truth, even if your voice shakes.”</p>
        }
      ]
    }
  },
  {
    id: "communication_5",
    category: "Communication",
    title: "The Art of Listening",
    img: "https://picsum.photos/seed/com5/300/400",
    content: {
      title: "Deep Listening",
      pages: [
        {
          title: "The Waiting Room",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to "listen" by just waiting for her turn to speak. She was constantly rehearsing her own responses, her own stories, and her own opinions, while the other person was still talking. She wasn't actually hearing the words—she was just catching the cues. She was a polite but profound stranger to her own friends' lives.</p>
              <p>The habit of prioritizing her own voice was a barrier that was keeping her from a deeper level of connection.</p>
            </>
          )
        },
        {
          title: "The Sacred Space",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try "active" listening. She leaned in, she made eye contact, and she started asking, "Tell me more about that." She stopped her internal rehearsals and just focused on the music of the other person's voice. She saw the light in their eyes, the subtle shift in their expression, and the depth of their experience. She realized that listening is the most profound gift you can give to another person.</p>
              <p>She discovered that the more she listened, the more she actually learned. By making space for someone else's story, she had enriched her own. She wasn't just "hearing"; she was connecting. She felt the warmth of a true, shared understanding. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“True listening is an act of love. Put down your own script and hold represent space for someone else's story. You will find that the more you hear, the more beautiful the world becomes.”</p>
        }
      ]
    }
  },
  {
    id: "motivation_3",
    category: "Motivation",
    title: "Feeding the Flame",
    img: "https://picsum.photos/seed/mot3/300/400",
    content: {
      title: "Finding Inspiration",
      pages: [
        {
          title: "The Dull Routine",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was just going through the motions. Wake up, study, eat, sleep—repeat. Her life felt like a movie she had already seen a hundred times, and she was watching it on mute. She had lost her "why," and the goals she once had felt like dry leaves blowing in a cold wind. She was waiting for a "feeling" to strike her, but the feeling was nowhere to be found.</p>
              <p>The habit of waiting for external excitement was a drain that was leaving her paralyzed and bored.</p>
            </>
          )
        },
        {
          title: "The Intentional Spark",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop waiting and start seeking. She watched a talk by someone who had overcome incredible odds, she read a biography of a hero, and she spent time in nature. Slowly, the pilot light of her own soul started to glow. She realized that inspiration isn't something that happens *to* you; it's something you cultivate. She found her "why" again, and it was even stronger than before.</p>
              <p>She discovered that motivation is a fire that needs to be fed every single day. By intentionally seeking out the good, the brave, and the beautiful, she had reclaimed her own energy. She wasn't just "doing things"; she was pursuing a purpose. She felt inspired. She felt alive.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Inspiration is everywhere, but you must have the eyes to see it. Don't wait for the fire to find you; go out and gather the wood. Feed your soul every day with the things that make your heart beat faster.”</p>
        }
      ]
    }
  },
  {
    id: "motivation_4",
    category: "Motivation",
    title: "The Iron Will",
    img: "https://picsum.photos/seed/mot4/300/400",
    content: {
      title: "Cultivating Discipline",
      pages: [
        {
          title: "The Mood Trap",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She only worked when she "felt like it." If she was in the mood, she was brilliant; if she wasn't, she was nowhere to be found. Her life was a rollercoaster of high energy and deep slumps, and her progress was perpetually stalled by the whims of her own emotions. She was a "flake" to her own dreams, always promising the world but delivering only when the wind blew the right way.</p>
              <p>The habit of relying on "feeling" was a shaky foundation that was keeping her from any real achievement.</p>
            </>
          )
        },
        {
          title: "The Pro's Path",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to treat her goals like a job. She showed up at the same time every day, regardless of how she felt. She pushed through the boredom, the frustration, and the voices that said, "Not today." To her surprise, the "feeling" of motivation often arrived *after* she started working. She realized that discipline isn't about ignoring your feelings; it's about not being a slave to them.</p>
              <p>She discovered that the "secret" to success is simply the ability to keep going when everyone else would have quit. By bridging the gap between intention and action, she had built a new kind of self-respect. She wasn't a victim of her mood; she was the architect of her results. She felt reliable. She felt unstoppable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Discipline is the bridge between goals and accomplishment. Don't wait for the right mood to strike; strikes the match yourself and get to work. The feelings will follow the action.”</p>
        }
      ]
    }
  },
  {
    id: "motivation_5",
    category: "Motivation",
    title: "The Power of One",
    img: "https://picsum.photos/seed/mot5/300/400",
    content: {
      title: "Overcoming Overwhelm",
      pages: [
        {
          title: "The Mountain of To-Do",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She looked at her list of goals and felt like she was standing at the base of Everest in flip-flops. There was so much to do, so much to change, and so much to learn that she was completely paralyzed. She spent more time worrying about the work than actually doing it. She was drowning in the "big picture" and losing her ability to see the first step.</p>
              <p>The habit of focusing on the end result was a thief that was stealing her ability to enjoy the journey.</p>
            </>
          )
        },
        {
          title: "The Single Step",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to shrink her world. "Forget the mountain; just focus on the next ten feet." She picked one small task and finished it. Then another. Then another. Slowly, the mountain didn't seem so big anymore. She realized that every massive achievement is just a long string of tiny, focused efforts. Her "overwhelm" was just a lack of focus.</p>
              <p>She discovered that the most powerful thing you can do is the very next thing. By choosing to move, she had broken the spell of paralysis. She wasn't "finishing"; she was just *starting*, over and over again. She felt capable. She felt in motion.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The secret of getting ahead is getting started. Don't worry about the whole staircase; just focus on the first step. You have the strength for this one moment, and one moment is all you ever need.”</p>
        }
      ]
    }
  },
  {
    id: "physical_5",
    category: "Physical",
    title: "Standing Tall",
    img: "https://picsum.photos/seed/phy5/300/400",
    content: {
      title: "The Power of Posture",
      pages: [
        {
          title: "The Weighted Slump",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She spent her days hunched over her desk, her spine curved like a question mark. Her back ached, her breathing was shallow, and she felt a constant sense of low-level fatigue that she couldn't quite explain. She didn't realize that her physical posture was both a reflection and a reinforcement of her own internal sense of overwhelm. She was making herself small in a world that needed her to be big.</p>
              <p>The habit of slouching was a quiet way of hiding from her own potential.</p>
            </>
          )
        },
        {
          title: "The Dignified Rise",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to "reset" her body. She sat up straight, rolled her shoulders back, and imagined a string pulling the top of her head toward the ceiling. She took a deep, full breath. To her surprise, she felt an immediate surge of energy and confidence. It wasn't just about her back; it was about her internal state. She realized that by standing tall, she was telling the world—and herself—that she deserved to be here.</p>
              <p>She discovered that her body is an instrument, not just a vehicle. By aligning her spine, she had aligned her spirit. She wasn't just "fixing her posture"; she was reclaiming her own dignity. She felt alert. She felt capable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your posture is the foundation of your presence. Stand tall, breathe deep, and own the space you occupy. You are a masterpiece in progress, so carry yourself with the dignity you deserve.”</p>
        }
      ]
    }
  },
  {
    id: "physical_6",
    category: "Physical",
    title: "Glowing from Within",
    img: "https://picsum.photos/seed/phy6/300/400",
    content: {
      title: "The Art of Skin Care",
      pages: [
        {
          title: "The Neglected Canvas",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to see skin care as purely "vanity," something for people with too much time and money. She neglected her own skin, leaving it dry, dull, and often irritated by the harsh environment. She didn't realize that her skin is her largest organ, a vital protector and a faithful mirror of her internal health. She was ignoring the very barrier that kept her safe from the world.</p>
              <p>The habit of neglect was a quiet way of saying that her own physical well-being wasn't a priority.</p>
            </>
          )
        },
        {
          title: "The Ritual of Glow",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start a simple routine: wash, moisture, protect. She spent five minutes every morning and night focused on the sensation of the cool water, the richness of the cream, and the act of caring for herself. To her surprise, her skin started to glow, but her *spirit* felt even brighter. She realized that skin care isn't about being "perfect"; it's about being "kind" to the body that houses your soul.</p>
              <p>She discovered that a ritual of care can transform a chore into a celebration. By honoring her skin, she had learned how to honor her own presence. She wasn't just "washing her face"; she was treating herself with the respect she deserved. She felt refreshed. She felt radiant.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your skin is the envelope of your being. Treat it with the same kindness and care you would give to any other vital part of your life. Glow from the inside out by honoring the body that protects you.”</p>
        }
      ]
    }
  },
  {
    id: "physical_7",
    category: "Physical",
    title: "The Gentle Touch",
    img: "https://picsum.photos/seed/phy7/300/400",
    content: {
      title: "Caring for Your Hands",
      pages: [
        {
          title: "The Weary Hands",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Her hands were dry and cracked, a physical testament to the long, cold winter and the constant work she did. She used them for everything—writing, cooking, cleaning, caring for others—but she rarely used them to care for *herself*. They felt rough, uncomfortable, and a little bit neglected. She didn't realize that her hands were the primary way she interacted with the world, and they were tired.</p>
              <p>The habit of ignoring her own physical comfort was a quiet way of prioritizing everything else over her own needs.</p>
            </>
          )
        },
        {
          title: "The Soft Reclamation",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start a simple ritual: a nightly hand massage with a rich, scented cream. She spent five minutes focused on the sensation of the lotion, the release of tension in her palms, and the simple act of being kind to herself. To her surprise, her hands didn't just feel softer—*she* felt softer. She realized that by caring for her hands, she was also caring for the spirit that moved them.</p>
              <p>She discovered that self-care isn't about the grand gestures, but the small, consistent acts of kindness. By honoring her hands, she had learned how to honor her own effort. She wasn't just "using lotion"; she was treating herself with the gratitude she deserved. She felt comfortable. She felt cared for.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your hands are the instruments of your heart. Treat them with the same kindness and respect they use to interact with the world. A small act of care can go a long way in healing the spirit.”</p>
        }
      ]
    }
  },
  {
    id: "mindset_8",
    category: "Mindset",
    title: "The Open Door",
    img: "https://picsum.photos/seed/min8/300/400",
    content: {
      title: "The Beginner's Mind",
      pages: [
        {
          title: "The Expert's Wall",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She thought she knew everything about the subject. She had read the books, taken the classes, and achieved the results. She walked into the room with her arms crossed and her mind even tighter. She stopped listening, stopped asking questions, and started defending her own opinions. She was a master of the "known," but she was becoming a prisoner of her own knowledge.</p>
              <p>The habit of being "the expert" was a wall that was keeping her from the very growth she once valued.</p>
            </>
          )
        },
        {
          title: "The Sacred 'I Don't Know'",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try a different approach. She sat in the front row and promised herself she wouldn't speak until she had heard something new. To her surprise, she heard *everything* differently. By letting go of the need to be "right," she had made space for the "possible." She realized that true mastery isn't about knowing all the answers; it's about having the courage to keep asking the questions.</p>
              <p>She discovered that the "beginner's mind" is the most powerful tool for innovation. By becoming a student again, she had reclaimed her own curiosity. She wasn't just "learning facts"; she was expanding her own horizon. She felt humble. She felt inspired.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“In the beginner's mind there are many possibilities, in the expert's mind there are few. Don't be afraid to say 'I don't know' and let the world teach you something new every single day.”</p>
        }
      ]
    }
  },
  {
    id: "mindset_9",
    category: "Mindset",
    title: "The Radiant Stillness",
    img: "https://picsum.photos/seed/min9/300/400",
    content: {
      title: "Quiet Confidence",
      pages: [
        {
          title: "The Noise of Insecurity",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She thought she had to be the loudest one in the room to be noticed. She dominated conversations, she interrupted others, and she constantly felt the need to prove her own brilliance. Her life was a performance, a frantic dance of "look at me," but she felt increasingly invisible. She was trying so hard to be "somebody" that she was losing track of who she actually was.</p>
              <p>The habit of external validation was a shaky foundation that was keeping her in a state of perpetual anxiety.</p>
            </>
          )
        },
        {
          title: "The Power of the Pause",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop shouting. She walked into a meeting and decided to listen first. She only spoke when she had something truly meaningful to say, and she did so with a calm, steady voice. To her surprise, people didn't just notice her—they *listened* to her. She realized that confidence isn't about being seen; it's about being comfortable in your own skin, regardless of who is looking.</p>
              <p>She discovered that quiet confidence is the most magnetic kind of power. By letting go of the need to compete, she had found her own center. She wasn't just "talking"; she was contributing. She felt respected. She felt at peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Confidence is not walking into a room thinking you're better than everyone; it's not having to compare yourself at all. Your power is found in your stillness, your truth, and your quiet presence.”</p>
        }
      ]
    }
  },
  {
    id: "mindset_10",
    category: "Mindset",
    title: "The Long Game",
    img: "https://picsum.photos/seed/min10/300/400",
    content: {
      title: "Patience and Persistence",
      pages: [
        {
          title: "The Sprint Trap",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She wanted results tomorrow. She started a new project, a new habit, or a new goal with a burst of intense energy, but when the immediate payoffs didn't arrive, she felt like a failure. She was a sprinter in a world that requires marathons, and she was constantly burning out before she even reached the first mile marker. She was addicted to the "quick win," and the slow grind of actual progress felt like a waste of time.</p>
              <p>The habit of wanting it "now" was a drain that was leaving her perpetually discouraged and stagnant.</p>
            </>
          )
        },
        {
          title: "The Marathon Mind",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to shift her focus from "intensity" to "consistency." She promised herself she would just do the work, one small piece at a time, regardless of the results. She realized that most people overestimate what they can do in a day, but they profoundly underestimate what they can do in a year. Slowly, the needle started to move. The big goals weren't "fixed" in a day; they were built, brick by brick, over time.</p>
              <p>She discovered that the "secret" to success is simply the ability to keep going when the initial excitement fades. By playing the long game, she had built a foundation that was unbreakable. She wasn't just "trying"; she was becoming. She felt patient. She felt steady.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Most people overestimate what they can do in a day and underestimate what they can do in a year. Trust the process, embrace the slow grind, and remember that the most beautiful things take time to grow.”</p>
        }
      ]
    }
  },
  {
    id: "physical_8",
    category: "Physical",
    title: "Windows to the World",
    img: "https://picsum.photos/seed/phy8/300/400",
    content: {
      title: "Practicing Eye Relief",
      pages: [
        {
          title: "The Digital Blur",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She'd been staring at her laptop screen for four hours straight. Her eyes felt dry, her vision was starting to blur, and she had a dull headache that was throbbing behind her temples. She was so focused on her "work" that she was neglecting the very organs that allowed her to do it. She was living in a flat, blue-light world, and her eyes were crying out for a different kind of stimulation.</p>
              <p>The habit of over-consumption was a strain that was making her world feel narrow and exhausting.</p>
            </>
          )
        },
        {
          title: "The 20-20-20 Reset",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to set a timer for the 20-20-20 rule. Every 20 minutes, she looked at something 20 feet away for at least 20 seconds. She focused on the leaves of a tree, the pattern of the clouds, or even just the far corner of the room. To her surprise, her vision cleared, her headache faded, and she felt a surge of fresh energy. She realized that her eyes needed the "far" as much as they needed the "near."</p>
              <p>She discovered that eye relief is a form of mental relief. By choosing to look away, she had found a new kind of clarity. She wasn't just "resting her eyes"; she was reconnecting with the depth and the color of the real world. She felt refreshed. She felt clear.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your eyes are your windows to the world, but they are not made to stare at a single point forever. Give them the gift of the far horizon, the soft light, and the frequent rest they deserve. Clarity begins with a blink.”</p>
        }
      ]
    }
  },
  {
    id: "physical_9",
    category: "Physical",
    title: "The Grounded Step",
    img: "https://picsum.photos/seed/phy9/300/400",
    content: {
      title: "Practicing Foot Care",
      pages: [
        {
          title: "The Weary Miles",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She'd been walking all day, her feet trapped in shoes that were more about fashion than function. They felt tired, heavy, and hot, a physical testament to the many miles she had traveled to achieve her goals. She was so focused on "getting there" that she had completely ignored the foundation that was carrying her. Her feet were the unsung heroes of her day, and they were exhausted.</p>
              <p>The habit of taking her own physical support for granted was a quiet way of devaluing her own journey.</p>
            </>
          )
        },
        {
          title: "The Happy Reset",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She took off her shoes and rolled her feet over a cold tennis ball. She felt the slow, sweet release of tension in her arches, the cooling sensation of the air, and the simple relief of being "unbound." To her surprise, her whole body felt lighter. She realized that by honoring her feet, she was also honoring the effort it took to reach her destination.</p>
              <p>She discovered that foot care is a form of gratitude. By giving her feet a moment of rest, she had learned how to appreciate the miles she had already covered. She wasn't just "massaging her feet"; she was grounding herself back into her own life. She felt relieved. She felt supported.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your feet carry you through every challenge and toward every dream. When they feel heavy and tired, respond with kindness and rest. Ground yourself in the present by honoring the foundation that keeps you moving.”</p>
        }
      ]
    }
  },
  {
    id: "physical_10",
    category: "Physical",
    title: "The Breath of Life",
    img: "https://picsum.photos/seed/phy10/300/400",
    content: {
      title: "The Power of Breathing",
      pages: [
        {
          title: "The Shallow Gasp",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was breathing, but she wasn't *respiring*. Her breaths were short, shallow, and mostly in her chest, a physical manifestation of her perpetual state of "fight or flight." She felt lightheaded, anxious, and constantly on edge, as if she were running a race that never ended. She didn't realize that her breath was the remote control for her entire nervous system, and she had it stuck on "panic."</p>
              <p>The habit of shallow breathing was a feedback loop that was keeping her system in a state of high alert.</p>
            </>
          )
        },
        {
          title: "The Deep Inhale",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try "belly breathing." She put her hand on her stomach and focused on making it rise and fall with every breath. She took long, slow inhales and even longer exhales. To her surprise, the world immediately felt quieter, her heart rate slowed, and a sense of profound calm washed over her. She realized that her breath was a portable sanctuary, always available whenever she needed it.</p>
              <p>She discovered that her breath is the bridge between her body and her mind. By mastering her inhale, she had learned how to manage her internal weather. She wasn't just "breathing"; she was choosing peace. She felt grounded. She felt in control.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The breath is the only part of your nervous system that you can consciously control. When the world feels too loud, come back to the simple miracle of your own inhale. It is your anchor, your sanctuary, and your superpower.”</p>
        }
      ]
    }
  },
  {
    id: "social_8",
    category: "Social",
    title: "Respectful Discord",
    img: "https://picsum.photos/seed/soc8/300/400",
    content: {
      title: "Healthy Disagreement",
      pages: [
        {
          title: "The Angry Clash",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>They had completely different opinions on a subject they both cared about, and it was rapidly turning into an ugly argument. Every point was a weapon, every counter-point was a shield, and they were both more interested in winning than in understanding. She felt her heart racing, her voice rising, and the distance between them growing wider by the second. She was about to say something she'd regret.</p>
              <p>The habit of seeing different opinions as threats was a wall that was turning a friendship into a battlefield.</p>
            </>
          )
        },
        {
          title: "The Dignified Disagree",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to pause. "I see it differently, and that's okay." She stopped trying to "convince" and started trying to "clarify." She realized that two people can look at the same thing and see two completely different truths, and that doesn't make either of them "wrong." To her surprise, her friend relaxed, the tension dissolved, and they actually learned something from each other's perspective.</p>
              <p>She discovered that respect is more important than agreement. By honored the relationship over her own position, she had strengthened the bond. She wasn't just "giving in"; she was growing up. She felt sophisticated. She felt at peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You don't have to agree with someone to respect them. The world is richer for our differences, not in spite of them. Choice to understand instead of convince, and you will find the hidden beauty in disagreement.”</p>
        }
      ]
    }
  },
  {
    id: "social_9",
    category: "Social",
    title: "The Gracious Guest",
    img: "https://picsum.photos/seed/soc9/300/400",
    content: {
      title: "Social Etiquette",
      pages: [
        {
          title: "The Unconscious Visitor",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was staying at a friend's house, and she was treating it like a hotel. She left her luggage open in the middle of the floor, her wet towels on the bed, and she never offered to help with the dishes. She wasn't being "mean"; she was just being unconscious. She didn't realize that her presence was creating work and stress for the people who had opened their home to her.</p>
              <p>The habit of self-centeredness was a quiet way of devaluing the generosity of others.</p>
            </>
          )
        },
        {
          title: "The Helpful Presence",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start participating in the life of the house. She made her bed, she cleared the table, and she always asked, "How can I help?" She brought a small gift or a card to say thank you. To her surprise, she felt more "at home" by being helpful than she ever did by being served. She realized that manners are the invisible lubricant that makes shared life beautiful.</p>
              <p>She discovered that being a good guest is an art. By honoring the space and the people in it, she had ensured she would always be welcome back. She wasn't just "behaving"; she was contributing to the harmony of the home. She felt thoughtful. She felt connected.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Manners are the way we show respect for the space and time of others. When you are a guest, leave the place a little better than you found it. A grateful heart is the best housewarming gift you can ever bring.”</p>
        }
      ]
    }
  },
  {
    id: "social_10",
    category: "Social",
    title: "Bridging the Distance",
    img: "https://picsum.photos/seed/soc10/300/400",
    content: {
      title: "Long-Distance Friendships",
      pages: [
        {
          title: "The Growing Silence",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Her best friend had moved halfway across the country, and the vibrant, daily interaction they once shared had faded into a series of sporadic, half-hearted texts. She felt a profound sense of loss, as if a part of her own identity had been packed away in a moving box. She was afraid that the distance was a slow-motion goodbye, and that they were eventually going to become strangers who used to know everything about each other.</p>
              <p>The habit of assuming the worst was a weight that was making her hesitate to even reach out.</p>
            </>
          )
        },
        {
          title: "The Digital Lifeline",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to propose a weekly "video date." They sat with their coffee, shared their messy days, and laughed at the same old jokes. To her surprise, the distance didn't weaken the bond—it actually forced them to be more intentional about their communication. She realized that true friendship isn't about being inseparable; it's about being separated and choosing to stay connected anyway.</p>
              <p>She discovered that love is stronger than geography. By making the effort, she had preserved a treasure that was far more valuable than any physical proximity. She wasn't just "keeping in touch"; she was honoring a history. She felt loved. She felt connected.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Distance is just a test to see how far love can travel. Don't let the miles discourage you from nurturing the relationships that define your heart. True connection requires effort, but it is always worth the journey.”</p>
        }
      ]
    }
  },
  {
    id: "school_10",
    category: "School",
    title: "The Sacred Pause",
    img: "https://picsum.photos/seed/sch10/300/400",
    content: {
      title: "Taking Study Breaks",
      pages: [
        {
          title: "The Relentless Grind",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She thought the secret to success was endurance. She would sit at her desk for six hours straight, pounding her brain with information, refusing to move until the chapter was finished. But her focus was leaking, her back was aching, and she was starting to hate the very subjects she used to love. She was a high-performance engine that was running on fumes, and the "work" she was doing was becoming increasingly shallow and ineffective.</p>
              <p>The fear of pausing was a noise that was keeping her from her own peak intelligence.</p>
            </>
          )
        },
        {
          title: "The Five-Minute Walk",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try the "Pomodoro" method: 50 minutes of work, 10 minutes of rest. During the break, she walked away from her desk, took a deep breath of fresh air, and looked at something green. To her surprise, her focus doubled. She came back to the work with a fresh perspective, a steady hand, and a much lighter heart. She realized that rest isn't a "reward" for work; it's a *requirement* for it.</p>
              <p>She discovered that strategic breaks are a sign of intellectual maturity, not laziness. By honoring her own capacity, she had actually increased it. She wasn't just "studying"; she was mastering the art of sustainable success. She felt alert. She felt capable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your brain is a living organ, not a machine. It needs the 'off' moments as much as it needs the 'on' buttons. Respect your own limits, take the break, and watch your intelligence bloom in the stillness.”</p>
        }
      ]
    }
  },
  {
    id: "growth_7",
    category: "Growth",
    title: "The Inner Child",
    img: "https://picsum.photos/seed/gro7/300/400",
    content: {
      title: "Learning to Play",
      pages: [
        {
          title: "The Stiff Adult",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like she had to be "together" all the time. Professional, polite, productive—a perfectly curated version of an adult who never made a mess and never asked "why." She was living in a world of rules and expectations, and her own sense of wonder was being quietly suffocated. She was high-achieving, but she was also incredibly bored. She had forgotten how to just *be*.</p>
              <p>The habit of maturity was a mask that was hiding the vibrant, messy child that still lived inside her.</p>
            </>
          )
        },
        {
          title: "The Crayola Cure",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She spent an hour on the floor with her nephew, building an impossible castle out of cardboard boxes and duct tape. She forgot about the time, she forgot about her lists, and she even forgot about her "image." To her surprise, her creativity exploded. In the middle of the play, she found the answers to problems she had been dwelling on for weeks. She realized that the "expert" mind is often the one that's most stuck.</p>
              <p>She discovered that play is the highest form of research. By honoring her inner child, she had found her own spark again. She wasn't just "playing"; she was reclaiming the audacity to imagine. She felt joyful. She felt alive.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The most creative people are the ones who never stopped play-testing the world. Don't be afraid to be silly, to make a mess, and to ask 'what if?'. Your inner child is the guardian of your true genius.”</p>
        }
      ]
    }
  },
  {
    id: "growth_8",
    category: "Growth",
    title: "Stepping Out",
    img: "https://picsum.photos/seed/gro8/300/400",
    content: {
      title: "Expanding Your Comfort Zone",
      pages: [
        {
          title: "The Safe Circle",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She did the same things every day. Same routes, same people, same conversations. It was comfortable, predictable, and safe, but she felt a quiet, persistent rust starting to settle on her soul. She was living in a beautiful, well-maintained cage of her own making. She wanted to expand, to experience something new, but the thought of leaving the circle made her stomach churn with anxiety.</p>
              <p>The habit of safety was a wall that was keeping her from the very adventure she was secretly craving.</p>
            </>
          )
        },
        {
          title: "The Edge of Courage",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to do one thing that scared her every week. She tried a new hobby, spoke to a stranger, or walked a different way home. To her surprise, her "comfort zone" didn't just move—it grew. She realized that fear isn't a sign to stop; it's a sign that you're about to learn something important. Her world was getting bigger, brighter, and much more interesting.</p>
              <p>She discovered that courage is a muscle that only grows when it's stretched. By choosing the "edge," she had reclaimed her own spirit of adventure. She wasn't just "surviving"; she was exploring. She felt brave. She felt limitless.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“A comfort zone is a beautiful place, but nothing ever grows there. Step outside the circle, embrace the uncertainty, and watch your own potential expand in directions you never imagined.”</p>
        }
      ]
    }
  },
  {
    id: "growth_9",
    category: "Growth",
    title: "The Digital Mentor",
    img: "https://picsum.photos/seed/gro9/300/400",
    content: {
      title: "Curating Your Feed",
      pages: [
        {
          title: "The Mindless Scroll",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was spending hours every day scrolling through mindless content. Jokes, drama, and endless comparison that left her feeling empty, anxious, and somehow "behind" in a race she hadn't signed up for. She was letting her internal landscape be shaped by the loudest and most shallow voices on the internet. Her mind felt cluttered, her focus was shattered, and her sense of purpose was being drowned out by the static.</p>
              <p>The habit of unconscious consumption was a drain that was leaving her paralyzed and disconnected.</p>
            </>
          )
        },
        {
          title: "The Intentional Spark",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to "unfollow" the noise and "follow" the fuel. She filled her feed with scientists, philosophers, artists, and people who were actually doing the work she admired. To her surprise, her phone transformed from a source of stress into a source of inspiration. She realized that you are the average of the information you consume most. Her mind felt alive, her curiosity was sparked, and her goals felt reachable again.</p>
              <p>She discovered that digital mentorship is a choice. By curating her feed, she had reclaimed her own attention. She wasn't just "scrolling"; she was learning. She felt inspired. She felt empowered.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your attention is your most valuable asset. Don't waste it on the static; invest it in the stories, the ideas, and the people that make your heart beat faster. Curate your world with intention.”</p>
        }
      ]
    }
  },
  {
    id: "growth_10",
    category: "Growth",
    title: "The Ripple Effect",
    img: "https://picsum.photos/seed/gro10/300/400",
    content: {
      title: "Building a Legacy",
      pages: [
        {
          title: "The Isolated Life",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She thought her actions didn't matter because she was "just one person." She focused solely on her own goals, her own comfort, and her own success, convinced that the world was too big and its problems too complex for her to ever make a difference. She felt small, insignificant, and disconnected from any sense of larger purpose. She was living for herself, but it didn't feel like enough.</p>
              <p>The habit of self-minimization was a fog that was hiding the profound power she already possessed.</p>
            </>
          )
        },
        {
          title: "The Single Act",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to help one person, with zero fanfare. She mentored a student, she volunteered at a shelter, or she simply listened to a friend in need. To her surprise, her small act started a ripple. She saw that person help another, then another, and then another. She realized that legacy isn't something you leave *behind*; it's something you build *now*, through the way you treat the people around you.</p>
              <p>She discovered that she was never "just one person"; she was a vital link in a long chain of kindness. By choosing to contribute, she had found her own meaning. She wasn't just "existing"; she was mattering. She felt purposeful. She felt connected.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You don't have to change the world all at once. You just have to change one person's world. Your small acts of kindness are the seeds of a legacy that will outlive you. Trust the ripple.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_7",
    category: "Confidence",
    title: "Body Language",
    img: "https://picsum.photos/seed/con7/300/400",
    content: {
      title: "The Power of Presence",
      pages: [
        {
          title: "The Hunch of Insecurity",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She walked with her shoulders up and her head down, a physical manifestation of her own internal sense of unworthiness. She was trying to make herself as small as possible, to blend into the background and avoid being seen. Her physical posture was telling the world that she was afraid, and it was reinforcing the very anxiety she was trying to hide. She was trapped in the "hunch."</p>
              <p>The habit of physical concealment was a barrier that was keeping her from her own power.</p>
            </>
          )
        },
        {
          title: "The Dignified Stand",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try a "power pose" before her big interview. She stood tall, put her hands on her hips, and took long, deep breaths for two minutes. To her surprise, her physiology shifted. Her cortisol levels dropped, her testosterone rose, and she felt a surge of authentic confidence. She realized that by changing her body, she was also changing her mind. She walked into the room ready.</p>
              <p>She discovered that your body doesn't just reflect your thoughts; it can also *create* them. By owning her space, she had reclaimed her own presence. She wasn't just "posing"; she was practicing. She felt capable. She felt radiant.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is the faithful interpreter of your heart. When you feel small, stand tall. Own the space you inhabit, and watch your confidence rise to meet your physical presence. You deserve to be seen.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_8",
    category: "Confidence",
    title: "The Armor of Choice",
    img: "https://picsum.photos/seed/con8/300/400",
    content: {
      title: "Dressing for Yourself",
      pages: [
        {
          title: "The Lazy Slump",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She stayed in her pajamas all day, even when she had work to do. She felt unproductive, "off," and a little bit low, as if she were perpetually stuck in a state of Sunday morning. She thought it didn't matter what she wore because "no one was watching," but she realized that *she* was watching. Her physical appearance was communicating a lack of importance to her own self.</p>
              <p>The habit of neglect was a subtle way of saying that her own time and effort didn't matters.</p>
            </>
          )
        },
        {
          title: "The Sharp Reset",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to put on her favorite outfit, just for herself. She did her hair, she put on her favorite shoes, and she looked in the mirror. To her surprise, her energy shifted immediately. She felt more focused, more capable, and far more ready to tackle her goals. She realized that dressing up isn't about impressing others; it's about honoring the person you are becoming.</p>
              <p>She discovered that your clothing is a form of self-expression and self-respect. By choosing "the sharp," she had reclaimed her own sense of agency. She wasn't just "getting dressed"; she was declaring her own presence. She felt professional. She felt powerful.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Dress like you're going somewhere better, even if you're staying home. Your appearance is a love letter to yourself. Honoring your presence with the choices you make for your body, and your confidence will follow.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_9",
    category: "Confidence",
    title: "Building Competence",
    img: "https://picsum.photos/seed/con9/300/400",
    content: {
      title: "Skill Acquisition",
      pages: [
        {
          title: "The Fake Facade",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She tried to "fake it till she made it." She talked the talk, she used the buzzwords, and she acted like she knew exactly what she was doing. But deep down, she felt like a fraud. Every success felt like a lucky break, and she lived in constant fear of being "exposed." Her confidence was a house of cards, built on a foundation of insecurity and the performance of expertise.</p>
              <p>The habit of comparison was a drain that was keeping her from the actual work of improvement.</p>
            </>
          )
        },
        {
          title: "The Real Growth",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop faking and start learning. She admitted when she didn't know something, and she spent time actually building the skill. She took the classes, did the practice, and embraced the mistakes. To her surprise, her confidence started to grow from the inside out. It wasn't a "feeling" anymore; it was a *fact*. She was capable, and she knew it.</p>
              <p>She discovered that real confidence is a natural byproduct of competence. By doing the work, she had built a foundation that was unbreakable. She wasn't just "acting"; she was *being*. She felt reliable. She felt unstoppable.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Confidence is not a destination; it's a byproduct of the journey toward competence. Don't worry about 'faking' anything; focus on the slow, deliberate work of becoming better. Real mastery is unmistakable.”</p>
        }
      ]
    }
  },
  {
    id: "confidence_10",
    category: "Confidence",
    title: "The First Step",
    img: "https://picsum.photos/seed/con10/300/400",
    content: {
      title: "Practicing Social Courage",
      pages: [
        {
          title: "The Lonely Corner",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was at a networking event, a party, or a new class, and she was glued to the far corner of the room. She waited for others to come to her, convinced that she had nothing interesting to say and that she would only be "bothering" people if she spoke first. She felt invisible, isolated, and increasingly anxious, her own internal noise drowning out the possibility of connection.</p>
              <p>The habit of social passivity was a cage that was keeping her from the very community she desired.</p>
            </>
          )
        },
        {
          title: "The Simple Question",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to take the risk. She walked up to a stranger, took a deep breath, and asked a simple, open-ended question. "What brings you here today?" or "How do you know the host?" To her surprise, the other person looked relieved. They started talking, and the conversation flowed naturally. She realized that most people are just as nervous as she was, and they are waiting for someone else to be brave first.</p>
              <p>She discovered that social courage isn't about being "fearless"; it's about being "willing." By taking the first step, she had opened a door to a new world. She wasn't just "talking"; she was connecting. She felt brave. She felt seen.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Courage is not the absence of fear; it's the realization that connection is more important than comfort. Take the first step, ask the simple question, and watch the world open up to meet you. You are more welcome than you think.”</p>
        }
      ]
    }
  },
  { id: "confidence_11", category: "Confidence", title: "Accepting Praise", img: "https://picsum.photos/seed/con11/300/400", content: { title: "The Compliment", pages: [ { title: "The Deflect", content: <p>Whenever someone said something nice, she argued with them.</p> }, { title: "The Thanks", content: <p>She said 'Thank you' and actually let the words sink in.</p> }, { title: "Reminder", content: <p>When you reject a compliment, you are rejecting a gift. Just say thanks.</p> } ] } },
  {
    id: "future_9",
    category: "Future",
    title: "Planning for Freedom",
    img: "https://picsum.photos/seed/fut9/300/400",
    content: {
      title: "Practicing Financial Literacy",
      pages: [
        {
          title: "The Financial Fog",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had no idea where her money was going every month. She spent when she had it, she worried when she didn't, and her finances felt like a chaotic, uncontrollable force that was always one step ahead of her. She avoided looking at her bank account because the "truth" felt too scary to face. She was living in a fog of "maybe," and her dreams for the future felt increasingly fragile and disconnected from reality.</p>
              <p>The habit of avoidance was a drain that was keeping her from her own power and security.</p>
            </>
          )
        },
        {
          title: "The Clear Map",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to sit down and track every single expense for thirty days. She looked at the numbers with curiosity rather than judgment. To her surprise, the "truth" wasn't as scary as the "unknown." She created a simple budget—a plan for her money rather than a restriction on it. She realized that financial literacy isn't about "math"; it's about "philosophy"—it's about choosing what matters most to you.</p>
              <p>She discovered that a budget is a tool for freedom. By owning her numbers, she had reclaimed her own future. She wasn't just "saving"; she was investing in her own peace of mind. She felt in control. She felt secure.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Knowledge is the antidote to fear, especially when it comes to your finances. Face the numbers, create a plan, and remember that every dollar is a seed for your future freedom. You are the architect of your own security.”</p>
        }
      ]
    }
  },
  {
    id: "future_10",
    category: "Future",
    title: "Small Steps for the Earth",
    img: "https://picsum.photos/seed/fut10/300/400",
    content: {
      title: "Practicing Sustainable Living",
      pages: [
        {
          title: "The Overwhelming Wave",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt completely paralyzed by the constant stream of environmental news. Headlines about climate change, plastic in the oceans, and disappearing species made her feel like a tiny, insignificant speck in a storm she couldn't control. She thought that if she couldn't do "everything" perfectly—go zero-waste, go vegan, stop driving—then she shouldn't do "anything" at all. She was drowning in eco-anxiety.</p>
              <p>The habit of perfectionism was a shield that was protecting her from actually taking part in the solution.</p>
            </>
          )
        },
        {
          title: "The Single Reusable",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start with one small, manageable change: she bought a reusable water bottle and committed to using it. She realized that we don't need one person doing sustainability "perfectly"; we need millions of people doing it "imperfectly." Slowly, she added more habits—composting, using less plastic, supporting local farmers. To her surprise, her small actions gave her a sense of agency and hope. She wasn't just "worrying"; she was acting.</p>
              <p>She discovered that sustainable living is a journey of intentionality, not a destination of purity. By choosing the "green path," she had reconnected with the beauty and the needs of the natural world. She was finally breathing. She felt helpful. She felt part of something larger.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The Earth doesn't need your perfection; it needs your participation. Start where you are, use what you have, and do what you can. Every small choice is a vote for the future you want to see. You are a vital part of the healing.”</p>
        }
      ]
    }
  },
  {
    id: "identity_9",
    category: "Identity",
    title: "Roots and Wings",
    img: "https://picsum.photos/seed/ide9/300/400",
    content: {
      title: "Embracing Your Multi-Dimensionality",
      pages: [
        {
          title: "The Fragmented Self",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt like she was caught between two worlds and didn't belong to either. She was a different person at home than she was at school, and a different person online than she was in real life. She was a mosaic of expectations, a fragmented set of "versions" that never seemed to fit together into a cohesive whole. She felt like a traveler who was always "visiting" but never truly "at home."</p>
              <p>The habit of compartmentalization was a barrier that was keeping her from her own sense of completeness.</p>
            </>
          )
        },
        {
          title: "The Beautiful Bridge",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to stop trying to choose one version of herself over the other. She started to see her different roles not as "conflicts," but as "dimensions." She realized that she could be both traditional and modern, both quiet and brave, both a student and a teacher. To her surprise, the more she integrated her different parts, the more "whole" she felt. She wasn't just a "mismatch"; she was a unique and complex masterpiece.</p>
              <p>She discovered that identity is not a choice, but an embrace. By becoming the bridge, she had found her own unique voice. She wasn't just "blending in"; she was standing out. She felt complete. She felt authentic.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are not a single note; you are a symphony. Don't be afraid to be complex, to be contradictory, and to embrace every part of your story. Your multi-dimensionality is your greatest gift. You are complete as you are.”</p>
        }
      ]
    }
  },
  {
    id: "identity_10",
    category: "Identity",
    title: "Think for Yourself",
    img: "https://picsum.photos/seed/ide10/300/400",
    content: {
      title: "Intellectual Identity",
      pages: [
        {
          title: "The Intellectual Mime",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She just repeated the opinions she heard from others to fit in. She adopted the politics of her friends, the tastes of her family, and the buzzwords of the internet, convinced that "safety" was found in agreement. She was a mirror reflecting everyone else's light, but she had no light of her own. She was living in a world of "shoulds" and "oughts," and her own internal voice was being quietly suffocated.</p>
              <p>The habit of conformity was a cage that was keeping her from the very agency she secretly craved.</p>
            </>
          )
        },
        {
          title: "The Independent Voice",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start reading outside her comfort zone and forming her own thoughts. She asked "why?" more often than she said "yes." She realized that thinking for yourself is not an act of "rebellion," but an act of "self-discovery." To her surprise, when she spoke her own truth, people didn't distance themselves—they leaned in. She was no longer just a "mirror"; she was a "source."</p>
              <p>She discovered that her mind is a sacred space that deserves her own unique cultivation. By honoring her own thoughts, she had found her own power. She wasn't just "agreeing"; she was contributing. She felt mentally alive. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your mind is a masterpiece in progress. Don't let others paint over your own unique colors. Have the courage to think, to question, and to find your own voice in the noise. To think for yourself is the ultimate act of liberation.”</p>
        }
      ]
    }
  },
  {
    id: "selflove_8",
    category: "Self-Love",
    title: "Body Gratitude",
    img: "https://picsum.photos/seed/lov8/300/400",
    content: {
      title: "Honoring Your Vessel",
      pages: [
        {
          title: "The Constant Critique",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She looked at her legs and wished they were thinner, longer, or more "perfect." She treated her body like a decoration that was always failing her, rather than the miraculous vessel that allowed her to experience the world. She lived in a state of internal war, her own self-image a battlefield of "not enoughs" and "should-haves." She was trying to force her physical form into a mold that didn't fit.</p>
              <p>The habit of objectification was a poison that was making her feel isolated from her own life.</p>
            </>
          )
        },
        {
          title: "The Walk of Thanks",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to take a walk and consciously thank her legs for every step. She felt the strength in her muscles, the rhythm of her heart, and the simple miracle of movement. To her surprise, her "imperfections" didn't seem so important anymore. She realized that her body is not a "thing" to be judged; it's a "process" to be lived. She was finally partnering with herself. She felt sturdy. She felt capable.</p>
              <p>She discovered that body gratitude is a form of liberation. By honoring her physical self, she had found her own center. She wasn't just "looking"; she was experiencing. She felt radiant. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is not a decoration; it is your home. Treat it with the same kindness and respect you would give to someone you love. Honoring its strength, its resilience, and its simple miracle of existence. You are beautiful in your being.”</p>
        }
      ]
    }
  },
  {
    id: "selflove_9",
    category: "Self-Love",
    title: "The Joy of Solitude",
    img: "https://picsum.photos/seed/lov9/300/400",
    content: {
      title: "Dating Yourself",
      pages: [
        {
          title: "The Fear of Being Alone",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to feel like being alone meant she was "lonely," or somehow unpopular and unwanted. She filled every silence with noise, every empty hour with distraction, and every solitary moment with a frantic search for company. She was afraid that if she stopped moving, she would have to face the person who lived inside her—and she wasn't sure if she liked that person very much.</p>
              <p>The habit of external flight was a drain that was keeping her from her own internal wealth.</p>
            </>
          )
        },
        {
          title: "The Solo Date",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to take herself out for coffee and a book, with zero distraction. She sat in the quiet, focused on her own thoughts, and actually listened to what she had to say. To her surprise, she didn't just "tolerate" her own company—she *enjoyed* it. She realized that solitude isn't a "lack" of others; it's a "presence" of self. She was finally becoming her own best friend. She felt peaceful.</p>
              <p>She discovered that if you aren't happy being alone, you'll never be truly happy with others. By choosing the quiet, she had found her own center. She wasn't just "waiting"; she was being. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Solitude is the soil where your soul grows. Don't be afraid of the quiet or the empty space; it is in the stillness that you will find your own unique truth. Learn to love your own company, and you will never be lonely again.”</p>
        }
      ]
    }
  },
  {
    id: "selflove_10",
    category: "Self-Love",
    title: "Filling Your Cup First",
    img: "https://picsum.photos/seed/lov10/300/400",
    content: {
      title: "Practicing Priority",
      pages: [
        {
          title: "The Social Doormat",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She put everyone else's needs ahead of her own. She said "yes" when she wanted to say "no," she gave her time until she was exhausted, and she neglected her own joy to ensure everyone else's comfort. She thought she was being "good," but she was actually becoming resentful, burnt out, and increasingly empty. She was a well that was running dry, and she had nothing left to offer.</p>
              <p>The habit of self-sacrifice was a poison that was destroying her own ability to contribute.</p>
            </>
          )
        },
        {
          title: "The Radiant Renewal",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to fill her own cup first. She started setting boundaries, saying "no" to things that drained her, and prioritizing her own rest and joy. To her surprise, she didn't become "selfish"; she became "sustainable." By honoring her own needs, she had found the energy to pour for others with a genuine heart. She was a fountain of vitality, and her presence was finally a gift. She felt vibrant.</p>
              <p>She discovered that self-love is the ultimate form of service. By choosing herself, she had reclaimed her own power to help others. She wasn't just "giving"; she was overflowing. She felt purposeful. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You cannot pour from an empty cup. Honoring your own needs, your own rest, and your own joy is not just a right—it's a responsibility. Fill your own spring first, and you will have far more to offer the world.”</p>
        }
      ]
    }
  },
  {
    id: "boundaries_9",
    category: "Boundaries",
    title: "Digital Sanctuary",
    img: "https://picsum.photos/seed/bou9/300/400",
    content: {
      title: "Practicing Digital Boundaries",
      pages: [
        {
          title: "The Notification Trap",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt obligated to reply to every message instantly, day or night. Her phone was a frantic tether to the world, a constant source of interruptions that left her unable to focus, unable to rest, and unable to ever truly be present in her own life. She was living in a state of high-alert responsiveness, her own peace of mind being slowly eroded by the demands and the "emergencies" of others. She was always "available," but she was never "there."</p>
              <p>The habit of over-accessibility was a drain that was making her feel like a prisoner of her own device.</p>
            </>
          )
        },
        {
          title: "The Quiet Revolution",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to turn off all non-essential notifications after 8 PM. She put her phone in another room and picked up a book, a journal, or simply sat in the quiet. To her surprise, her sleep improved, her focus returned, and a sense of profound calm washed over her. She realized that just because she was "reachable" didn't mean she had to be "available." Her time was her own sanctuary.</p>
              <p>She discovered that digital boundaries are a form of self-respect. By owning her attention, she had reclaimed her own peace of mind. She wasn't just "switching off"; she was "tuning in" to her own life. She felt refreshed. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your attention is the most valuable thing you own. Don't let the noise of the world drown out the music of your own life. Set your boundaries, protect your quiet, and remember that you deserve to be unavailable sometimes.”</p>
        }
      ]
    }
  },
  {
    id: "boundaries_10",
    category: "Boundaries",
    title: "The Courage of 'No'",
    img: "https://picsum.photos/seed/bou10/300/400",
    content: {
      title: "Conflict Resolution and Boundaries",
      pages: [
        {
          title: "The Silent Shrug",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She let people walk over her because she was terrified of "making a scene." She accepted the interruptions, the requests for last-minute favors, and the disrespectful comments, convinced that "peace" was found in compliance. But her silence was a lie, and the "peace" she was maintaining was actually a slow-burning fire of resentment and self-rejection. She was disappearing in an attempt to be "liked."</p>
              <p>The habit of self-minimization was a cage that was keeping her from the very respect she desired.</p>
            </>
          )
        },
        {
          title: "The Brave Stand",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to speak up. "I am not okay with this," she said, her voice steady and her heart racing. She realize that boundaries are not "mean"—they are the way we teach people how to treat us. To her surprise, the world didn't end. Some people pushed back, but others actually respected her more. She finally felt like a person with an interior that mattered. She was standing on her own ground.</p>
              <p>She discovered that setting boundaries is an act of clarity, not hostility. By honoring her own limits, she had strengthened her relationships. She wasn't just "saying no"; she was saying "yes" to her own dignity. She felt powerful. She felt authentic.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your boundaries are the invisible walls that protect your heart. Don't be afraid to defend them with grace and grit. When you speak your truth, you are honoring the sacred space that is your life. You deserve respect.”</p>
        }
      ]
    }
  },
  {
    id: "resilience_8",
    category: "Resilience",
    title: "Emotional Agility",
    img: "https://picsum.photos/seed/res8/300/400",
    content: {
      title: "Practicing Flexibility",
      pages: [
        {
          title: "The Brittle Shell",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She tried to be "perfect" and never show any weakness. She thought that if she just stayed strong enough, hard enough, and together enough, she could withstand any storm. But she was becoming brittle, like an old oak tree that snaps in the wind because it can no longer bend. Her rigidity was a defense against a world she didn't trust, and it was keeping her from the very healing she needed. She was one crack away from a total collapse.</p>
              <p>The habit of emotional suppression was a weight that was making her world feel incredibly fragile.</p>
            </>
          )
        },
        {
          title: "The Soft Flow",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to allow herself to feel "messy." She cried when she was sad, she admitted when she was afraid, and she chose to be soft instead of hard. To her surprise, her "weakness" was actually her greatest strength. By letting her emotions flow, she recovered from setbacks much faster. She realized that true resilience is not about avoiding the fall; it's about knowing how to get back up with grace. She was finally supple.</p>
              <p>She discovered that emotional agility is the power to be with yourself in all states. By choosing the "bend," she had ensured she would never break. She wasn't just "coping"; she was thriving. She felt resilient. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“True resilience is the ability to be soft in a hard world. Don't be afraid of your messy feelings; they are the water that keeps you flexible and the light that guides you home. Bend with the wind, and watch yourself bloom.”</p>
        }
      ]
    }
  },
  {
    id: "resilience_9",
    category: "Resilience",
    title: "The Kind Coach",
    img: "https://picsum.photos/seed/res9/300/400",
    content: {
      title: "Practicing Self-Compassion",
      pages: [
        {
          title: "The Harshest Critic",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to beat herself up for every tiny mistake, every perceived flaw, and every moment of "weakness." Her internal monologue was a relentless litany of self-judgment, a cold and unforgiving voice that demanded perfection and offered zero grace. She was her own worst enemy, and her internal environment was a toxic landscape of shame and "not enoughness." She was exhausted from the constant battle with herself.</p>
              <p>The habit of self-criticism was a poison that was making her world feel gray and hopeless.</p>
            </>
          )
        },
        {
          title: "The Compassionate Voice",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try talking to herself like she would talk to a dear friend. When she made a mistake, she said, "It's okay, you're learning," or "Everyone struggles sometimes." To her surprise, her whole physiology shifted. Her energy returned, her hope bloomed, and she felt a surge of authentic power. She realized that you cannot criticize yourself into a version of yourself that you love. Clarity begins with kindness.</p>
              <p>She discovered that self-compassion is the only true foundation for growth. By choosing the "kind coach," she had reclaimed her own spirit. She wasn't just "coping"; she was thriving. She felt patient. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are your own most important project, but you are also your own most important companion. Treat yourself with the same kindness and grace you offer to others. Compassion is the light that leads you through the dark. Trust your own beauty.”</p>
        }
      ]
    }
  },
  {
    id: "resilience_10",
    category: "Resilience",
    title: "Leaning on Others",
    img: "https://picsum.photos/seed/res10/300/400",
    content: {
      title: "Community and Support",
      pages: [
        {
          title: "The Isolated Island",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She thought that being "strong" meant doing everything by herself. She never asked for help, she never admitted when she was struggling, and she held all her burdens alone, convinced that vulnerability was a sign of weakness. She was high-achieving, but she was also incredibly lonely. Her world was a sterile landscape of self-reliance, and she was carrying a weight that was slowly crushing her spirit.</p>
              <p>The fear of dependency was a wall that was keeping her from the very community she needed.</p>
            </>
          )
        },
        {
          title: "The Brave Outreach",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to reach out to her friends and family and admit that she was overwhelmed. To her surprise, they didn't judge her—they leaned in. They offered support, they shared their own stories, and the burden immediately felt half as heavy. She realized that strength isn't just what you can do alone; it's also knowing when to ask for help. Her "tribe" was her greatest asset. She felt supported.</p>
              <p>She discovered that vulnerability is the bridge to true connection. By choosing the "outreach," she had fortified her own resilience. She wasn't just "surviving"; she was thriving in community. She felt connected. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“No one is an island, and no one is meant to carry the world alone. Have the courage to lean on others, to ask for help, and to build the community that sustains you. Strength is find through connection. Trust your tribe.”</p>
        }
      ]
    }
  },
  {
    id: "digital_8",
    category: "Digital",
    title: "T.H.I.N.K. Before Posting",
    img: "https://picsum.photos/seed/dig8/300/400",
    content: {
      title: "Practicing Online Etiquette",
      pages: [
        {
          title: "The Impulsive Comment",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She saw a post that bothered her, and she almost posted an angry, reactive comment without thinking about the person behind the screen. She was about to contribute to the noise, the drama, and the toxicity of the digital world, convinced that her "opinion" was more important than anyone's feelings. Her pulse was racing, her fingers were hovering over the keyboard, and she was seconds away from a regretful digital footprint.</p>
              <p>The habit of reactive anger was a drain that was making her world feel incredibly small and hostile.</p>
            </>
          )
        },
        {
          title: "The Mindful Pause",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to take a five-minute break and ask herself five questions: Is it True? Is it Helpful? Is it Inspiring? Is it Necessary? Is it Kind? To her surprise, her anger faded and she realized that her comment was none of those things. She deleted the draft and chose peace over "being right." She realized that every post is a small contribution to the collective digital weather. She felt clean.</p>
              <p>She discovered that digital kindness is a choice. By choosing the "pause," she had reclamation her own digital integrity. She wasn't just "scrolling"; she was contributing to a better world. She felt thoughtful. She felt connected.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The digital world is a reflection of our collective heart. Before you post, ask yourself if you are adding light or shadow. Choose kindness, choose truth, and remember that there is always a human being on the other side of the screen. Think first.”</p>
        }
      ]
    }
  },
  {
    id: "digital_9",
    category: "Digital",
    title: "The Secure Vault",
    img: "https://picsum.photos/seed/dig9/300/400",
    content: {
      title: "Practicing Cybersecurity",
      pages: [
        {
          title: "The Open Door",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to use the same, simple password for everything—her email, her bank, her social media—and she never thought twice about it. She felt "safe" because no one had ever hacked her, but she was actually leaving her entire life wide open to identity theft and data breaches. She was a house with no locks, and her most personal information was just one lucky guess away from being stolen. She was living in a state of unconscious vulnerability.</p>
              <p>The habit of convenience was a risk that was compromising her long-term security.</p>
            </>
          )
        },
        {
          title: "The Unique Code",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start using a password manager and enabled two-factor authentication on all her important accounts. She created unique, complex passwords for everything and felt a surge of authentic power. To her surprise, the "inconvenience" wasn't nearly as bad as she had feared, and the peace of mind was priceless. She realized that cybersecurity is a form of self-respect. She was finally secure.</p>
              <p>She discovered that digital safety is a skill, not a mystery. By owning her security, she had protected her future. She wasn't just "logging in"; she was defending her own life. She felt informed. She felt secure.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your digital identity is a sacred part of your life. Protect it with the same care and intention you use to protect your home. Use strong, unique passwords, enable 2FA, and remember that your security is your own responsibility. Stay safe online.”</p>
        }
      ]
    }
  },
  {
    id: "digital_10",
    category: "Digital",
    title: "Navigating the Truth",
    img: "https://picsum.photos/seed/dig10/300/400",
    content: {
      title: "Practicing Critical Thinking Online",
      pages: [
        {
          title: "The Fake Sensation",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She saw a video that looked incredibly real but felt "off" in a way she couldn't quite describe. It was provocative, sensational, and perfectly designed to trigger an emotional response. She was seconds away from sharing it with all her followers, convinced that she was "spreading the word" about an important event. She was about to contribute to the fog of misinformation that is always swirling online.</p>
              <p>The habit of reactive sharing was a drain that was making her world feel incredibly small and hostile.</p>
            </>
          )
        },
        {
          title: "The Source Check",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to pause and check multiple, reliable sources. To her surprise, she found that the video was a deepfake, manufactured to cause division and chaos. She realize that in an age of AI, critical thinking is the most important digital skill you can possess. She deleted the draft and chose truth over "engagement." She realized that she has a responsibility to curate the reality she shares. She felt alert.</p>
              <p>She discovered that digital integrity is a form of power. By choosing the "check," she had protected the collective understanding of the world. She wasn't just "surfing"; she was analyzing. She felt thoughtful. She felt connected.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“In a world of infinite information, critical thinking is your filter. Don't let your emotions be hijacked by the noise; seek out the sources, check the facts, and remember that truth is more important than trends. Stay curious and stay skeptical.”</p>
        }
      ]
    }
  },
  {
    id: "leadership_8",
    category: "Leadership",
    title: "The Peacemaker",
    img: "https://picsum.photos/seed/lea8/300/400",
    content: {
      title: "Navigating Conflict",
      pages: [
        {
          title: "The Divided Team",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>Two of her team members were locked in a bitter disagreement, and the entire project was grinding to a halt. The atmosphere was toxic, the communication was broken, and she felt like she was caught in the middle of a war she hadn't signed up for. She was afraid that taking a side would only make things worse, and that her "leadership" was being tested in a way she wasn't prepared for. She was stuck in the middle.</p>
              <p>The habit of avoiding conflict was a wall that was turning a small disagreement into a big disaster.</p>
            </>
          )
        },
        {
          title: "The Common Ground",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to sit them down in a neutral space and invited them to actually listen to each other. She used "reflective listening" and helped them find the shared goals that were being hidden by the drama. To her surprise, they didn't just "fix" the problem—they strengthened the relationship. She realized that a leader doesn't "take sides"; a leader "brings sides together." Progress resumed. She felt helpful.</p>
              <p>She discovered that mediation is a form of creation. By choosing the "meet," she had restored the harmony of the team. She wasn't just "managing"; she was healing. She felt sophisticated. She felt at peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Leadership is the art of building a bridge across the gap of human differences. When conflict arises, seek out the common ground, invite the honest dialogue, and remember that your greatest strength is your ability to unify. Be the peacemaker.”</p>
        }
      ]
    }
  },
  {
    id: "leadership_9",
    category: "Leadership",
    title: "The Art of Letting Go",
    img: "https://picsum.photos/seed/lea9/300/400",
    content: {
      title: "Practicing Delegation",
      pages: [
        {
          title: "The Micro-Manager",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She tried to check every single detail herself. She was involved in every meeting, every email, and every minor decision, convinced that if she wasn't looking, things would fall apart. She was exhausted, her focus was shattered, and her team felt untrusted, micromanaged, and quietly rebellious. She was a bottleneck in her own success, and she was terrified that "letting go" would mean "losing control."</p>
              <p>The habit of over-control was a wall that was keeping her team from their own peak performance.</p>
            </>
          )
        },
        {
          title: "The Trusted Team",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to give her team clear roles and the freedom to do their work. She stopped checking and started supporting. To her surprise, efficiency skyrocketed, creativity bloomed, and the team finally felt like they were part of something important. She realized that true leadership isn't about doing everything yourself; it's about empowering others to do their best. She was finally leading.</p>
              <p>She discovered that delegation is a form of respect. By choosing the "trust," she had reclaimed her own time and energy. She wasn't just "managing"; she was multiplying. She felt inspired. She felt at peace.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“If you want to do it fast, do it alone. If you want to do it far, do it with others. Empowerment is the ultimate act of leadership. Trust your team, let go of the details, and watch your collective potential reach the sky.”</p>
        }
      ]
    }
  },
  {
    id: "leadership_10",
    category: "Leadership",
    title: "The Integrity Standard",
    img: "https://picsum.photos/seed/lea10/300/400",
    content: {
      title: "Practicing Ethical Leadership",
      pages: [
        {
          title: "The Shortcut Trap",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She saw a way to win by taking a shortcut that wasn't quite "right." It was a small compromise, a half-truth, a little bit of hidden data that would ensure her project was finished on time and under budget. She was convinced that the "results" were more important than the "process," and that no one would ever know the difference. She was living for the appearance of success, but she was losing track of her own character.</p>
              <p>The habit of moral flexibility was a poison that was making her world feel incredibly small and generic.</p>
            </>
          )
        },
        {
          title: "The Honest Path",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to chose the honest path, even though it was harder and would take longer. She was transparent about the challenges, she admitted the mistakes, and she stood by her values. To her surprise, her team's trust in her reached an all-time high. She realized that your integrity is your most valuable asset, and that true leadership is doing the right thing, even when no one is looking. Her success was finally authentic.</p>
              <p>She discovered that character is the only foundation for true influence. By choosing the "honesty," she had found her own authentic voice. She wasn't just "leading"; she was inspiring. She felt sturdy. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Integrity is not a destination; it is a direction. Have the courage to choose the right path, even when it is the hard path, and remember that your character is the only thing you will ever truly own. Lead with your heart and your truth.”</p>
        }
      ]
    }
  },
  {
    id: "emotions_8",
    category: "Emotions",
    title: "Honoring Grief",
    img: "https://picsum.photos/seed/emo8/300/400",
    content: {
      title: "Practicing Grief Integration",
      pages: [
        {
          title: "The Heavy Shadow",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She had lost something profoundly important—a person, a dream, a pet, or a part of herself—and she felt like a piece of her own soul had been ripped away forever. She tried to "move on" by staying busy, by ignoring the pain, and by acting like "everything was fine." But the shadow was always there, a dull and persistent ache that was making her world feel gray and hollow. She was trapped in the "not-feeling."</p>
              <p>The habit of avoidance was a drain that was keeping her from the very healing she needed.</p>
            </>
          )
        },
        {
          title: "The Warm Memory",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to allow herself to cry, to remember, and to honor the love that was at the core of her grief. She realized that grief is not a "problem" to be solved, but a "process" to be lived. By allowing the pain to flow, she also allowed the healing to begin. She started to integrate the loss into her own story, finding a new and deeper connection to the thing she had lost. She felt soft.</p>
              <p>She discovered that grief is the price of love, and that it is a price worth paying. By choosing the "honor," she had broadened her own capacity for joy. She wasn't just "getting over it"; she was growing through it. She felt human. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Grief is not a process to be 'finished'; it's a part of life to be integrated with love. Give yourself the time, the space, and the grace to feel every part of your story. The healing begins in the honoring of the heart.”</p>
        }
      ]
    }
  },
  {
    id: "emotions_9",
    category: "Emotions",
    title: "The Joy in Small Things",
    img: "https://picsum.photos/seed/emo9/300/400",
    content: {
      title: "Practicing Micro-Joy",
      pages: [
        {
          title: "The Big Chase",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to think that she would only be happy when she got the "big" things—the promotion, the perfect relationship, the dream house, or the exotic vacation. She spent her life living in a state of "then," convinced that her present was just a waiting room for the future. She was chasing a horizon that was always moving, and she was missing the lush and vibrant life that was already surrounding her. She was high-achieving, but she was also perpetually dissatisfied.</p>
              <p>The habit of outcome-dependency was a drain that was making her world feel incredibly gray and sterile.</p>
            </>
          )
        },
        {
          title: "The Simple Sip",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start looking for joy in the "ordinary." She focused on the taste of her morning tea, the sun on her skin, and the sound of wind in the trees. To her surprise, she didn't just "feel better"—she felt *alive*. She realized that happiness is not a destination; it's a way of traveling through the ordinary moments. She was finally living in the "now." She felt vibrant.</p>
              <p>She discovered that joy is a skill of attention. By choosing the "small things," she had reclaimed her own internal wealth. She wasn't just "waiting"; she was being. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Happiness is not a prize at the end of the race; it is the light that guides your steps along the way. Stop chasing the 'big' things and start noticing the miracles that are already here. Your joy is in the ordinary moments. Savor them.”</p>
        }
      ]
    }
  },
  {
    id: "emotions_10",
    category: "Emotions",
    title: "Grounding Your Anxiety",
    img: "https://picsum.photos/seed/emo10/300/400",
    content: {
      title: "Practicing the 5-4-3-2-1 Technique",
      pages: [
        {
          title: "The Racing Mind",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She lived in a constant state of "what if." Her mind was a racing loop of worst-case scenarios, forgotten tasks, and future anxieties that left her unable to focus, unable to rest, and unable to ever truly be present in her own body. She felt like she was vibrating at a frequency that was too high for the world, and her sleep was a mess of shallow breaths and late-night worries. She was exhausted from the constant mental noise.</p>
              <p>The habit of future-tripping was a weight that was making her world feel incredibly fragile and hostile.</p>
            </>
          )
        },
        {
          title: "The Secure Ground",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try the 5-4-3-2-1 technique: 5 things she could see, 4 she could touch, 3 she could hear, 2 she could smell, and 1 she could taste. To her surprise, her racing mind slowed down, her breath deepened, and she felt a sense of profound calm. She realize that anxiety is a time-traveler that takes you out of the now. By coming back to her senses, she had found her own center. She was finally safe.</p>
              <p>She discovered that grounding is a form of self-rescue. By choosing the "5-4-3-2-1," she had reclaimed her own peace of mind. She wasn't just "coping"; she was being. She felt sturdy. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Anxiety is a storm that happens in the future; grounding is the anchor that keeps you in the present. Use your senses to come back to your body, protect your quiet, and remember that you are safe in this moment. You are here. You are alright.”</p>
        }
      ]
    }
  },
  {
    id: "creativity_8",
    category: "Creativity",
    title: "Unlocking the Flow",
    img: "https://picsum.photos/seed/cre8/300/400",
    content: {
      title: "Practicing Creative Freedom",
      pages: [
        {
          title: "The White Page",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She stared at the white page for hours and felt like she'd lost her spark forever. She was trying too hard to be "good," too hard to be "original," and too hard to meet the expectations she thought the world had for her. Her creativity had become a chore, a performance that was draining her instead of fueling her. She felt like a well that had run dry, and her internal environment was a toxic landscape of self-judgment and "writer's block."</p>
              <p>The habit of perfectionism was a barrier that was keeping her from the very flow she desired.</p>
            </>
          )
        },
        {
          title: "The Mindful Walk",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to leave her desk and go for a long, aimless run in the sun. She stopped "thinking" and started "doing," letting the rhythm of her feet guide her back to her senses. To her surprise, by the time she got back, the ideas were flowing with zero effort. She realized that if you're stuck, you need to change your environment. The mind follows the body into the open air. She was finally creating.</p>
              <p>She discovered that creativity is a process of play, not a process of pressure. By choosing the "walk," she had reclaimed her own internal wealth. She wasn't just "trying"; she was being. She felt inspired. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your spark is not gone; it is simply waiting for you to stop trying so hard. Give yourself the space to be messy, to be quiet, and to change your view. The ideas are already within you. You just need to step out of their way. Keep moving.”</p>
        }
      ]
    }
  },
  { id: "creativity_9", category: "Creativity", title: "Artistic Voice", img: "https://picsum.photos/seed/cre9/300/400", content: { title: "Being Yourself", pages: [ { title: "The Copy", content: <p>She tried to paint exactly like the famous artists she saw on social media.</p> }, { title: "The Me", content: <p>She started painting things that only she saw. Her work felt finally real.</p> }, { title: "Reminder", content: <p>You were born an original. Don't die a copy.</p> } ] } },
  {
    id: "creativity_10",
    category: "Creativity",
    title: "The Magic of Collaboration",
    img: "https://picsum.photos/seed/cre10/300/400",
    content: {
      title: "Practicing Creative Connection",
      pages: [
        {
          title: "The Solitary Studio",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to keep all her ideas to herself, convinced that if she shared them, they would be "stolen" or, worse, judged and rejected. She lived in a solitary castle of creative isolation, her own sparks of genius never having the chance to catch fire from anyone else's warmth. She was high-achieving, but she was also incredibly lonely. Her world was a sterile landscape of individual effort, and she was missing the lush and vibrant life of collective creation.</p>
              <p>The habit of creative secrecy was a barrier that was keeping her from the very breakthroughs she desired.</p>
            </>
          )
        },
        {
          title: "The Creative Jam",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to brainstorm with a friend and found that their ideas combined to form something ten times better than anything she could have done alone. To her surprise, the "sharing" didn't diminish her own creativity—it multiplied it. She realize that creativity is often a team sport. By choosing the "jam," she had reclaimed her own internal wealth. She wasn't just "protecting"; she was "propelling." She felt connected.</p>
              <p>She discovered that collaboration is a form of amplified magic. By choosing the team, she had ensured her ideas would reach the sky. She wasn't just "sharing"; she was evolving. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Two hearts and two minds are always better than one. Don't be afraid to share your sparks, to listen to others, and to build the collective dreams that define us. Collaboration is the bridge to the impossible. Pass the ball.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_7",
    category: "Wellness",
    title: "Honoring the Earth",
    img: "https://picsum.photos/seed/wel7/300/400",
    content: {
      title: "Practicing Forest Bathing",
      pages: [
        {
          title: "The Concrete Box",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She realized she'd been inside a building or a car for three days straight. Her world was a sterile landscape of recycled air, fluorescent lights, and digital screens, and she was feeling a deep and persistent sense of disconnect from her own physical environment. She was high-achieving, but she was also incredibly "boxed in," her own internal battery being slowly depleted by the lack of natural light and natural sound. She was a plant that needed sun.</p>
              <p>The habit of indoor isolation was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Ancient Shade",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to sit under a large oak tree for twenty minutes and simply "be." She felt the texture of the bark, the scent of the leaves, and the rhythm of the wind. To her surprise, her heart rate slowed down, her breath deepened, and a sense of profound calm washed over her. She realized that the earth has music for those who listen. By coming back to nature, she had found her own center. She felt rooted.</p>
              <p>She discovered that forest bathing is a form of self-rescue. By choosing the "tree," she had reclaimed her own internal wealth. She wasn't just "getting air"; she was "plugging in" to the planet. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The earth is your first home and your greatest teacher. Don't let the noise of the world drown out the music of the trees. Step outside, feel the soil, and remember that you are a part of a beautiful and living whole. Listen to the wind.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_8",
    category: "Wellness",
    title: "Radical Unplugging",
    img: "https://picsum.photos/seed/wel8/300/400",
    content: {
      title: "Practicing Digital Detox",
      pages: [
        {
          title: "The Constant Ping",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She felt a surge of intense stress every time her phone made a sound. Her digital lifecycle was a relentless stream of notifications, updates, and "urgencies" that left her unable to ever truly be present in her own life. She was always "available," but she was never "there." Her focus was shattered, and her sense of internal peace was being slowly eroded by the noise of the world. She was a responder, not a liver.</p>
              <p>The habit of over-accessibility was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Sunday Silence",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to turn her phone off for an entire Sunday and put it in a drawer. To her surprise, she didn't "miss" anything—she reclaimed everything. She spent the day reading, walking, and actually talking to her family. She realize that almost everything will work again if you unplug it for a few minutes, including you. Her vacation was right there in the quiet. She felt refreshed. She felt free.</p>
              <p>She discovered that digital boundaries are a form of self-respect. By choosing the "off," she had found her own internal wealth. She wasn't just "unplugging"; she was "tuning in" to her own life. She felt authentic. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your presence is the most valuable thing you own. Don't let the digital world steal the moments that matter most. Unplug your devices, protect your quiet, and remember that real life happens in the space between the pings. Be here.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_9",
    category: "Wellness",
    title: "The Sacred Rest",
    img: "https://picsum.photos/seed/wel9/300/400",
    content: {
      title: "Practicing Better Sleep",
      pages: [
        {
          title: "The Exhaustion Myth",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to think that staying up all night to study or work was a sign of "dedication" and "strength." She wore her dark circles like a badge of honor, convinced that her "productivity" was more important than her "recovery." But she was a machine that was grinding its gears—irritable, forgetful, and unable to actually integrate the information she was chasing. She was "on," but she wasn't "awake."</p>
              <p>The habit of sleep-deprivation was a poison that was making her world feel incredibly fragile and generic.</p>
            </>
          )
        },
        {
          title: "The Radiant Renewal",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to prioritize 8 hours of sleep and felt like a brand new person. She realized that sleep is not a "reward" for work; it is the "foundation" for it. To her surprise, her memory improved, her mood stabilized, and her creativity reached a new peak. She realize that rest is the best meditation, and that your brain needs the quiet to thrive. She was finally sharp. She felt vibrant.</p>
              <p>She discovered that radical rest is a form of self-respect. By choosing the "sleep," she had reclaimed her own internal wealth. She wasn't just "resting"; she was "restoring." She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Sleep is the sacred ground where your body and mind come back to life. Don't sacrifice your well-being on the altar of productivity. Value your rest, protect your dark, and remember that you are more than what you do. Rest well.”</p>
        }
      ]
    }
  },
  {
    id: "wellness_10",
    category: "Wellness",
    title: "The Medicine of Mirth",
    img: "https://picsum.photos/seed/wel10/300/400",
    content: {
      title: "Practicing Laughter Therapy",
      pages: [
        {
          title: "The Gravity Trap",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She'd been taking everything so seriously that she'd forgotten how to smile, let alone laugh. Her life was a sterile landscape of "important" tasks, "urgent" deadlines, and "serious" conversations, and she was feeling a deep and persistent sense of emotional weight. She was high-achieving, but she was also incredibly heavy-hearted, her own sense of play being slowly crushed by the gravity of her responsibilities. She was a stone.</p>
              <p>The habit of over-seriousness was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Joyful Release",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to watch a silly movie and laughed until it physically hurt. To her surprise, the "seriousness" of her problems didn't just "go away"—it became manageable. She realize that a good belly laugh heals a lot of hurts. By coming back to the "ha-ha," she had found her own internal wealth. She wasn't just "laughing"; she was "liberating" herself from the weight. She felt light. She felt vibrant.</p>
              <p>She discovered that mirth is a choice of attention. By choosing the "laugh," she had reclaimed her own internal wealth. She wasn't just "playing"; she was "partnering" with her own joy. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Laughter is the shortest distance between two hearts and the most efficient way to lighten the load of the world. Don't be afraid to be silly, to play, and to find the humor in the ordinary moments. Your joy is your power. Laugh often.”</p>
        }
      ]
    }
  },
  { id: "hobby_6", category: "Hobby", title: "Amateur Astronomy", img: "https://picsum.photos/seed/hob6/300/400", content: { title: "Star Gazing", pages: [ { title: "The Dark", content: <p>She felt lost in the vastness of the universe and didn't know the constellations.</p> }, { title: "The Map", content: <p>She learned the names of the stars. She felt a connection to the cosmos.</p> }, { title: "Reminder", content: <p>We are all made of star-stuff. Don't forget to look up.</p> } ] } },
  { id: "hobby_7", category: "Hobby", title: "Baking Bread", img: "https://picsum.photos/seed/hob7/300/400", content: { title: "Rising Up", pages: [ { title: "The Yeast", content: <p>She thought baking was too difficult and precise for her messy style.</p> }, { title: "The Loaf", content: <p>She kneaded the dough and smelled the fresh bread. It was soul-soothing.</p> }, { title: "Reminder", content: <p>Some things just need time and warmth to rise to their full potential.</p> } ] } },
  { id: "hobby_8", category: "Hobby", title: "Journaling", img: "https://picsum.photos/seed/hob8/300/400", content: { title: "Dear Diary", pages: [ { title: "The Clutter", content: <p>Her head was full of thoughts that she couldn't sort out or quiet down.</p> }, { title: "The Page", content: <p>She wrote them all down. Her mind felt clean and airy again.</p> }, { title: "Reminder", content: <p>A journal is a mirror for your mind. Keep it clear.</p> } ] } },
  { id: "hobby_9", category: "Hobby", title: "Photography", img: "https://picsum.photos/seed/hob9/300/400", content: { title: "The Lens", pages: [ { title: "The Ordinary", content: <p>Everything around her seemed boring and gray and not worth noticing.</p> }, { title: "The Angle", content: <p>She looked through the viewfinder and saw the beauty in a single leaf.</p> }, { title: "Reminder", content: <p>Beauty is everywhere; you just have to choose to see it.</p> } ] } },
  { id: "hobby_10", category: "Hobby", title: "Learning Guitar", img: "https://picsum.photos/seed/hob10/300/400", content: { title: "The First Chord", pages: [ { title: "The Sore", content: <p>Her fingers hurt and the music sounded like noise instead of a song.</p> }, { title: "The Tune", content: <p>She practiced every day for ten minutes. A melody finally emerged.</p> }, { title: "Reminder", content: <p>The secret to any new skill is the willingness to be bad at it first.</p> } ] } },
  { id: "communication_6", category: "Communication", title: "Active Listening", img: "https://picsum.photos/seed/com6/300/400", content: { title: "Hear the Heart", pages: [ { title: "The Wait", content: <p>She was just waiting for her turn to speak instead of truly listening.</p> }, { title: "The Silence", content: <p>She stopped talking and listened with her eyes and heart. Trust grew.</p> }, { title: "Reminder", content: <p>The most basic of all human needs is the need to be understood. Listening is the key.</p> } ] } },
  { id: "communication_7", category: "Communication", title: "Non-Verbal Cues", img: "https://picsum.photos/seed/com7/300/400", content: { title: "Body Language", pages: [ { title: "The Mixed", content: <p>She said she was 'fine' but her arms were crossed and she was looking away.</p> }, { title: "The congruency", content: <p>She learned to match her body to her words. Her relationships felt more honest.</p> }, { title: "Reminder", content: <p>Your actions often speak so loudly that I can't hear what you're saying.</p> } ] } },
  {
    id: "communication_8",
    category: "Communication",
    title: "The Digital Bridge",
    img: "https://picsum.photos/seed/com8/300/400",
    content: {
      title: "Practicing Better Writing",
      pages: [
        {
          title: "The Wall of Text",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to send long, confusing emails that were difficult to read, hard to respond to, and often ignored. She was trying to share everything—the context, the details, and the questions—in one massive "wall of text" that left her recipients feeling overwhelmed and the communication broken. She was high-achieving, but she was also incredibly inefficient. Her world was a sterile landscape of unread drafts and missing answers.</p>
              <p>The habit of over-complication was a drain that was making her digital world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Clear Bullet",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start using clear headings, bullet points, and a single, direct question at the end. To her surprise, her response rate skyrocketed and her relationships improved. She realize that brevity is the soul of wit and the key to authentic connection. By choosing the "clarity," she had reclaimed her own digital wealth. She wasn't just "sending"; she was "communicating." She felt efficient. She felt heard.</p>
              <p>She discovered that better writing is a form of self-respect. By owning her message, she had ensured she would always be understood. She wasn't just "typing"; she was "bridging." She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your words are the tools you use to build the world you inhabit. Be clear, be kind, and remember that the goal of communication is understanding, not just expression. Simplify your message, and watch your connection grow. Speak clearly.”</p>
        }
      ]
    }
  },
  {
    id: "communication_9",
    category: "Communication",
    title: "The Art of Feedback",
    img: "https://picsum.photos/seed/com9/300/400",
    content: {
      title: "Practicing Constructive Feedback",
      pages: [
        {
          title: "The Blunt Critique",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to be "brutally honest" with her feedback. She told a friend their work was "bad" or "confusing" without offering any support or path to improvement. She thought she was being "helpful," but she was actually causing pain, triggering defensiveness, and damaging the very relationships she was trying to build. She was high-achieving, but she was also incredibly insensitive. Her world was a sterile landscape of blunt judgments.</p>
              <p>The habit of over-criticism was a drain that was making her world feel incredibly generic and hostile.</p>
            </>
          )
        },
        {
          title: "The Feedback Sandwich",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to try the "feedback sandwich": a praise, a constructive point, and another praise. To her surprise, her friends didn't just "accept" her feedback—they acted on it. She realized that correction does much, but encouragement does more. By choosing the "warmth," she had reclaimed her own social wealth. She wasn't just "pointing out"; she was "propelling." She felt supportive. She felt heard.</p>
              <p>She discovered that better feedback is a form of self-respect. By owning her message, she had ensured she would always be a force for growth. She wasn't just "judging"; she was "helping." She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Words can be windows or they can be walls. When you offer feedback, strive to build a bridge to a better version of someone else. Be honest, be kind, and remember that encouragement is the most powerful tool for change. Speak with love.”</p>
        }
      ]
    }
  },
  {
    id: "communication_10",
    category: "Communication",
    title: "Mastering the Apology",
    img: "https://picsum.photos/seed/com10/300/400",
    content: {
      title: "Practicing Authentic Repair",
      pages: [
        {
          title: "The Defensive Non-Apology",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to say "I'm sorry if you felt that way," which wasn't an apology at all—it was a way to shift the blame back onto the other person. She was trying to skip the discomfort of being "wrong" and the responsibility of the "repair." But her non-apologies were a lie, and the "peace" she was maintaining was actually a slow-burning fire of resentment and self-rejection. She was disappearing in an attempt to be "right."</p>
              <p>The habit of moral flexibility was a cage that was keeping her from the very respect she desired.</p>
            </>
          )
        },
        {
          title: "The Honest Own",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to say "I was wrong, and I'm sorry. How can I make it right?" To her surprise, the world didn't end—it opened up. People didn't just "forgive" her—they trusted her more. She realize that a sincere apology is the superglue of human relationships. By choosing the "honesty," she had reclaimed her own social wealth. She was standing on her own ground. She felt powerful. She felt authentic.</p>
              <p>She discovered that accountability is a form of power. By owning her mistakes, she had fortified her own resilience. She wasn't just "saying sorry"; she was "being whole." She felt worthy. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“An apology without change is just manipulation. Have the courage to own your mistakes, to feel the discomfort of being wrong, and to offer the repair that restores the relationship. True strength is found in the ability to say 'I'm sorry'. Be real.”</p>
        }
      ]
    }
  },
  { id: "motivation_6", category: "Motivation", title: "Small Wins", img: "https://picsum.photos/seed/mot6/300/400", content: { title: "The Step", pages: [ { title: "The Mountain", content: <p>She was terrified by how much work she had to do and felt like giving up.</p> }, { title: "The Ant", content: <p>She focused on moving one tiny piece of dirt. The mountain started to move.</p> }, { title: "Reminder", content: <p>Success is the sum of small efforts, repeated day in and day out.</p> } ] } },
  { id: "motivation_7", category: "Motivation", title: "Intrinsic Joy", img: "https://picsum.photos/seed/mot7/300/400", content: { title: "The Flow State", pages: [ { title: "The Reward", content: <p>She was only working for the grades or the praise from others. She felt bored.</p> }, { title: "The Game", content: <p>She turned the study session into a challenge for herself. She lost track of time.</p> }, { title: "Reminder", content: <p>When you enjoy the process, the result takes care of itself.</p> } ] } },
  {
    id: "motivation_8",
    category: "Motivation",
    title: "Navigating the Slump",
    img: "https://picsum.photos/seed/mot8/300/400",
    content: {
      title: "Practicing Resilience in Motivation",
      pages: [
        {
          title: "The Mid-Way Wall",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was halfway through a massive project and felt like she'd hit a brick wall. Her initial enthusiasm had faded, her energy was depleted, and she was convinced that she "couldn't go another day." She lived in a state of perpetual shadow, her own internal narrative a litany of "I can't do this" and "it's too hard." She was trapped in the valley of her own fatigue, and she was ready to quit. She felt empty.</p>
              <p>The habit of over-work was a poison that was making her world feel incredibly fragile and generic.</p>
            </>
          )
        },
        {
          title: "The Second Wind",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to take a full weekend off and simply "be." She unplugged, she rested, and she choose to return with a new, more sustainable strategy. To her surprise, she didn't just "finish"—she finished with a surge of authentic power. She realize that a slump is just a sign that you need a change of pace, not a sign that you've failed. Her energy returned. She felt vibrant.</p>
              <p>She discovered that motivation is a marathon, not a sprint. By choosing the "pause," she had reclamation her own internal wealth. She wasn't just "trying"; she was "being." She felt resilient. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The middle is always the hardest part. Don't be afraid of the slump; it is simply a reminder to rest, to regroup, and to remember why you started. Have the courage to keep moving, and trust that your second wind is already within you. You can do this.”</p>
        }
      ]
    }
  },
  {
    id: "motivation_9",
    category: "Motivation",
    title: "Surrounding Yourself with Light",
    img: "https://picsum.photos/seed/mot9/300/400",
    content: {
      title: "Practicing Social Motivation",
      pages: [
        {
          title: "The Isolated Procrastination",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She spent her days working alone in her room, and she felt a deep and persistent sense of loneliness and fatigue. She was trying to do everything by herself, convinced that her "independence" was her greatest strength. But her solo environment was a sterile landscape of zero accountability and zero inspiration. She was a spark that was trying to stay alive in a cold and dark room. She was fading away.</p>
              <p>The habit of social isolation was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Study Community",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to meet a friend at the library and simply "be" in each other's presence while they worked. To her surprise, seeing someone else focus made it ten times easier for her to focus too. She realize that we are social creatures, and that we can borrow energy from those around us. Her "tribe" was her greatest asset. She felt supported. She felt finally productive.</p>
              <p>She discovered that connection is a form of amplified magic. By choosing the "together," she had ensured her potential would reach the sky. She wasn't just "working"; she was "being" in community. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“You are the average of the people you spend the most time with. Surround yourself with those who challenge you to be better, who inspire you to grow, and who make the hard work feel like a shared adventure. Find your tribe and thrive together. Connect.”</p>
        }
      ]
    }
  },
  {
    id: "motivation_10",
    category: "Motivation",
    title: "Becoming Your Own Cheerleader",
    img: "https://picsum.photos/seed/mot10/300/400",
    content: {
      title: "Practicing Positive Self-Talk",
      pages: [
        {
          title: "The Internal Critic",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to tell herself she was "lazy," "stupid," or "failing" whenever she took a break or made a mistake. Her internal dialogue was a relentless litany of self-judgment, a cold and unforgiving voice that demanded perfection and offered zero grace. She was her own worst enemy, and her internal environment was a toxic landscape of shame and "not enoughness." She was exhausted from the constant battle with herself. She was fading.</p>
              <p>The habit of self-criticism was a poison that was making her world feel incredibly fragile and hostile.</p>
            </>
          )
        },
        {
          title: "The Radiant Cheerleader",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start saying, "I'm learning," "I'm working hard," and "I'm doing my best." To her surprise, her whole energy shifted. Her confidence bloomed, her hope returned, and she felt a surge of authentic power. She realize that way you talk to yourself creates the reality you live in. By choosing the "cheerleader," she had reclaimed her own internal wealth. She was finally alive. She felt vibrant.</p>
              <p>She discovered that self-compassion is the only true foundation for growth. By choosing the "kind voice," she had ensured her future would be bright. She wasn't just "coping"; she was thriving. She felt patient. She felt whole.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“The most important conversation you will ever have is the one you have with yourself. Speak to yourself with the same kindness, encouragement, and belief that you offer to those you love. Your words are the architects of your life. Speak with hope.”</p>
        }
      ]
    }
  },
  {
    id: "health_6",
    category: "Health",
    title: "Fueling Your Potential",
    img: "https://picsum.photos/seed/hea6/300/400",
    content: {
      title: "Practicing Better Nutrition",
      pages: [
        {
          title: "The Caffeine Crash",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to live on energy drinks, sugary snacks, and instant coffee—anything that would give her a quick "up" followed by an inevitable and crushing "down." She felt foggy, irritable, and perpetually tired, her own physical energy being a roller-coaster of highs and lows that she couldn't control. She was trying to force her body to run on fumes, and she was missing the steady and vibrant vitality of authentic health.</p>
              <p>The habit of emergency-fueling was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Balanced Plate",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start eating more fruits, colorful vegetables, and stable proteins. She focused on "slow" energy instead of "fast" fixes. To her surprise, her brain felt clear, her mood stabilized, and her energy stayed consistent all day long. She realized that food is not just "calories"—it's the information you give your body. By choosing the "balance," she had reclamation her own physical wealth. She felt sharp. She felt vibrant.</p>
              <p>She discovered that better nutrition is a form of self-respect. By owning her plate, she had ensured she would always have the power to live her best life. She wasn't just "eating"; she was "nourishing." She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is a miracle, but it needs the right materials to perform its magic. Treat your nutrition with the same care and intention you use to protect your dreams. Choice the best fuel for the machine that is your life. Nourish your soul.”</p>
        }
      ]
    }
  },
  {
    id: "health_7",
    category: "Health",
    title: "The Radiant Smile",
    img: "https://picsum.photos/seed/hea7/300/400",
    content: {
      title: "Practicing Dental Hygiene",
      pages: [
        {
          title: "The Dull Ache",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to neglect her teeth, convinced that brushing was just an "option" and that flossing was a waste of time. She felt a dull and persistent ache while eating, and she was increasingly self-conscious about her own smile. She was high-achieving, but she was also incredibly avoidant of the basic care that her skeleton required. She was a house with a beautiful facade, but the foundation was being slowly eroded by neglect.</p>
              <p>The habit of physical avoidance was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Consistent Routine",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to start a consistent flossing and brushing routine. She visited the dentist and choose to take control of her physical health. To her surprise, the ache faded, her confidence returned, and her smile felt vibrant and bright. She realize that your teeth are the only part of your skeleton you can see. By choosing the "consistency," she had reclamation her own physical self-respect. She felt clean.</p>
              <p>She discovered that daily care is a form of self-love. By owning her hygiene, she had protected her own physical integrity. She wasn't just "brushing"; she was "partnering" with herself. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your smile is your first message to the world. Protect it with the same care and intention you use to protect your heart. Consistency is the secret to all long-term success. Take care of your teeth, and they will take care of you. Shine bright.”</p>
        }
      ]
    }
  },
  {
    id: "health_8",
    category: "Health",
    title: "The Proper Alignment",
    img: "https://picsum.photos/seed/hea8/300/400",
    content: {
      title: "Practicing Ergonomics",
      pages: [
        {
          title: "The Humped Back",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She used to study for hours while sitting cross-legged on her bed, her shoulders hunched and her neck craned over her laptop. She was high-achieving, but she was also in constant pain—headaches, backaches, and a persistent sense of physical strain that made it difficult to focus or to rest. She was treating her body like a tool that didn't need maintenance, and her physical form was beginning to scream for relief. She was a knot.</p>
              <p>The habit of physical neglect was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Supporting Space",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to move to a chair with proper back support and put her laptop at eye level. She choose to respect the physical mechanics of her own body. To her surprise, her pain immediately started to fade, her focus returned, and she felt a surge of authentic power. She realize that your environment can either support your body or strain it. By choosing the "alignment," she had reclamation her own physical wealth. She felt sturdy.</p>
              <p>She discovered that ergonomics is a form of self-respect. By owning her space, she had ensured she would always be comfortable in her own skin. She wasn't just "sitting"; she was "being supported." She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is the only home you will ever truly inhabit. Treat its structure with the same respect and care you use to protect your most precious belongings. Stand tall, sit supported, and remember that your posture is a reflection of your self-worth. Align yourself.”</p>
        }
      ]
    }
  },
  {
    id: "health_9",
    category: "Health",
    title: "The Liquid Life",
    img: "https://picsum.photos/seed/hea9/300/400",
    content: {
      title: "Practicing Hydration",
      pages: [
        {
          title: "The Stuffy Fog",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She'd been in a windowless room for five hours and felt a dull headache coming on. She realized she'd gone the entire day without drinking any water, her own physical battery being slowly depleted by the lack of the most basic resource. She was high-achieving, but she was also incredibly "parched," her own internal environment a sterile landscape of dehydration. She was a desert.</p>
              <p>The habit of physical neglect was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Refreshing Breeze",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She went outside for five minutes and filled her lungs with fresh air while she drank a glass of cool water. To her surprise, her brain felt sharp, her skin glowed, and a sense of profound vitality washed over her. She realize that oxygen and water are the most basic nutrients. By coming back to the "sip," she had found her own physical wealth. She felt clear. She felt vibrant.</p>
              <p>She discovered that hydration is a skill of attention. By choosing the "bottle," she had reclaimed her own physical integrity. She wasn't just "logging in"; she was "powering up" from the inside. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Water is the first and most powerful medicine for your body and your mind. Don't wait until you're parched to offer yourself the resource you need. Stay hydrated, stay refreshed, and remember that you deserve to reach your full potential. Drink up.”</p>
        }
      ]
    }
  },
  {
    id: "health_10",
    category: "Health",
    title: "The Preventative Check-Up",
    img: "https://picsum.photos/seed/hea10/300/400",
    content: {
      title: "Practicing Better Health",
      pages: [
        {
          title: "The Fear of Maintenance",
          icon: <Cloud className="text-radiant-pink" />,
          content: (
            <>
              <p>She was avoiding going to the doctor for her annual exam because she was terrified of "what they might find" or "what they'd say." She preferred to live in a state of ignorant anxiety, convinced that "what I don't know can't hurt me." But her fear was a weight that was always there, a dull and persistent ache of uncertainty that made it difficult to ever truly feel secure in her own body. She was a bird waiting for a cage.</p>
              <p>The habit of physical avoidance was a drain that was making her world feel incredibly generic and sterile.</p>
            </>
          )
        },
        {
          title: "The Secure Answer",
          icon: <Sunrise className="text-radiant-pink" />,
          content: (
            <>
              <p>She decided to make the appointment and chose to take control of her own health. To her surprise, everything was fine, and the "relief" she felt was a surge of authentic power. She realize that maintenance is easier than repair, and that true peace of mind is found in clarity. By choosing the "check-up," she had reclamation her own physical self-respect. She felt safe.</p>
              <p>She discovered that preventative care is a form of self-love. By owning her numbers, she had protected her own future. She wasn't just "checking"; she was "partnering" with her own health. She felt authentic. She felt free.</p>
            </>
          )
        },
        {
          title: "Reminder",
          icon: <Heart className="text-radiant-pink" />,
          content: <p className="font-serif italic text-lg text-radiant-pink">“Your body is a precious inheritance that deserves your care and your attention. Don't wait until things break to offer yourself the maintenance you need. Be brave, seek the truth, and remember that your health is the foundation of your future. Take care.”</p>
        }
      ]
    }
  }
];
