import React from "react";
import { motion } from "motion/react";
import { Phone, MessageSquare, Heart, Shield, ExternalLink, ArrowLeft } from "lucide-react";
import { cn } from "@/src/lib/utils";

interface Helpline {
  name: string;
  number: string;
  description: string;
  type: "phone" | "text" | "web";
}

interface SupportHubProps {
  country: string;
  onClose?: () => void;
}

const HELPLINES: Record<string, Helpline[]> = {
  "South Africa": [
    { name: "Childline South Africa", number: "116", description: "Free 24/7 helpline for children and young people.", type: "phone" },
    { name: "SADAG Mental Health", number: "0800 567 567", description: "South African Depression and Anxiety Group.", type: "phone" },
    { name: "LifeLine SA", number: "0861 322 322", description: "Emotional support and crisis intervention.", type: "phone" }
  ],
  "Ghana": [
    { name: "Ghana Health Service", number: "055 522 2777", description: "Mental health support and counseling.", type: "phone" },
    { name: "HopeLine Ghana", number: "050 636 3385", description: "Emotional support and suicide prevention.", type: "phone" }
  ],
  "Kenya": [
    { name: "Childline Kenya", number: "116", description: "National 24-hour toll-free helpline for children.", type: "phone" },
    { name: "Befrienders Kenya", number: "+254 722 178 177", description: "Suicide prevention and emotional support.", type: "phone" },
    { name: "Red Cross Kenya", number: "1199", description: "Psychosocial support and emergency services.", type: "phone" }
  ],
  "Default": [
    { name: "International Support", number: "Check local listings", description: "Please reach out to a trusted adult or local emergency services.", type: "phone" }
  ]
};

const ADVICE = [
  { title: "Breathe First", text: "When things feel heavy, take 3 slow breaths. In for 4, hold for 4, out for 4." },
  { title: "You're Not Alone", text: "Reaching out is a sign of incredible strength, not weakness." },
  { title: "One Step at a Time", text: "Focus only on the next 5 minutes. You don't have to solve everything today." },
  { title: "Your Voice Matters", text: "Your feelings are valid and you deserve to be heard and supported." }
];

export default function SupportHub({ country, onClose }: SupportHubProps) {
  const helplines = HELPLINES[country] || HELPLINES["Default"];

  return (
    <div className="flex flex-col space-y-8 pb-12">
      {onClose && (
        <button 
          onClick={onClose}
          className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-radiant-pink transition-colors mb-2"
        >
          <ArrowLeft size={14} />
          Back to Dashboard
        </button>
      )}

      <header className="space-y-2">
        <div className="flex items-center gap-2">
          <h2 className="text-3xl font-serif">Support Hub</h2>
          <Heart className="text-radiant-pink fill-radiant-pink/10" size={24} />
        </div>
        <p className="text-gray-500 text-sm leading-relaxed">
          You're in <span className="font-bold text-gray-700">{country}</span>. Here are some trusted people you can talk to right now.
        </p>
      </header>

      {/* Helplines Section */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 px-1">Trusted Helplines</h3>
        <div className="grid gap-4">
          {helplines.map((line, i) => (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={line.name}
              className="bg-white p-6 rounded-[28px] border border-black/5 shadow-sm flex items-center justify-between group hover:border-radiant-pink/20 transition-all"
            >
              <div className="flex gap-4 items-center">
                <div className="w-12 h-12 bg-radiant-pink/5 rounded-2xl flex items-center justify-center text-radiant-pink">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">{line.name}</h4>
                  <p className="text-xs text-gray-500">{line.description}</p>
                </div>
              </div>
              <a 
                href={`tel:${line.number}`}
                className="bg-radiant-pink text-white px-5 py-2.5 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform active:scale-95"
              >
                Call {line.number}
              </a>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Supportive Advice */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 px-1">Supportive Advice</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ADVICE.map((item, i) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + (i * 0.1) }}
              key={item.title}
              className="bg-radiant-accent/5 p-6 rounded-[28px] border border-radiant-accent/10"
            >
              <div className="flex items-center gap-2 mb-2">
                <Shield className="text-radiant-accent" size={16} />
                <h4 className="text-sm font-bold text-gray-800">{item.title}</h4>
              </div>
              <p className="text-xs text-gray-600 leading-relaxed">{item.text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Emergency Note */}
      <footer className="bg-gray-50 p-6 rounded-[28px] border border-black/5 text-center">
        <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">In an immediate emergency</p>
        <p className="text-xs text-gray-500 leading-relaxed">
          If you or someone else is in immediate danger, please contact your local emergency services or go to the nearest hospital.
        </p>
      </footer>
    </div>
  );
}
