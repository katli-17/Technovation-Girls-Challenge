import React, { useState } from "react";
import { ChevronDown, Smartphone } from "lucide-react";
import { cn, COUNTRY_CODES } from "../lib/utils";

interface PhoneInputProps {
  value: string;
  onChange: (value: string, countryCode: string) => void;
  countryCode: string;
  error?: string;
  label?: string;
}

export default function PhoneInput({ value, onChange, countryCode, error, label }: PhoneInputProps) {
  const [showDropdown, setShowDropdown] = useState(false);
  const currentCountry = COUNTRY_CODES.find(c => c.code === countryCode) || COUNTRY_CODES[0];

  return (
    <div className="space-y-2">
      {label && <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-2">{label}</label>}
      <div className="relative flex gap-2">
        {/* Country Selector */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowDropdown(!showDropdown)}
            className="flex items-center gap-2 h-full px-4 bg-gray-50/50 border border-black/5 rounded-2xl hover:border-radiant-pink/30 transition-all"
          >
            <span className="text-lg">{currentCountry.flag}</span>
            <span className="text-sm font-medium">{currentCountry.code}</span>
            <ChevronDown size={14} className={cn("text-gray-400 transition-transform", showDropdown && "rotate-180")} />
          </button>

          {showDropdown && (
            <div className="absolute left-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-black/5 py-2 z-50 animate-in fade-in zoom-in-95 duration-200">
              <div className="max-h-64 overflow-y-auto custom-scrollbar">
                {COUNTRY_CODES.map((c) => (
                  <button
                    key={c.code}
                    type="button"
                    onClick={() => {
                      onChange(value, c.code);
                      setShowDropdown(false);
                    }}
                    className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{c.flag}</span>
                      <div className="text-left">
                        <p className="text-xs font-bold text-gray-700">{c.country}</p>
                        <p className="text-[10px] text-gray-400 font-medium">{c.code}</p>
                      </div>
                    </div>
                    {countryCode === c.code && <div className="w-1.5 h-1.5 bg-radiant-pink rounded-full" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Number Input */}
        <div className="relative flex-1 group">
          <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-radiant-pink transition-colors" size={18} />
          <input
            type="tel"
            required
            placeholder="Phone number"
            value={value}
            onChange={(e) => onChange(e.target.value.replace(/\D/g, ""), countryCode)}
            className={cn(
              "w-full pl-12 pr-4 py-4 rounded-2xl border border-black/5 bg-gray-50/50 focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 transition-all text-sm",
              error && "border-red-500 focus:ring-red-500/10"
            )}
          />
        </div>
      </div>
      {error && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest px-2">{error}</p>}
    </div>
  );
}
