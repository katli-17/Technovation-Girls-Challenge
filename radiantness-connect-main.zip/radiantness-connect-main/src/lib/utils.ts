import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const COUNTRY_CODES = [
  { country: "South Africa", code: "+27", flag: "🇿🇦", digits: 9 },
  { country: "Nigeria", code: "+234", flag: "🇳🇬", digits: 10 },
  { country: "Kenya", code: "+254", flag: "🇰🇪", digits: 9 },
  { country: "Ghana", code: "+233", flag: "🇬🇭", digits: 9 },
  { country: "USA/Canada", code: "+1", flag: "🇺🇸", digits: 10 },
  { country: "UK", code: "+44", flag: "🇬🇧", digits: 10 },
  { country: "Other", code: "+", flag: "🌐", digits: 15 },
];

export function validateEmail(email: string) {
  return email.includes("@");
}

export function validatePhone(phone: string, countryCode: string) {
  const country = COUNTRY_CODES.find(c => c.code === countryCode);
  const digitsOnly = phone.replace(/\D/g, "");
  if (!country) return digitsOnly.length > 5;
  if (country.code === "+") return digitsOnly.length > 5;
  return digitsOnly.length === country.digits;
}
