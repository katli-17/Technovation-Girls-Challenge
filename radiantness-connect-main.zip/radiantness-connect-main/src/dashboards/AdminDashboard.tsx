import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Users, Package, TrendingUp, Shield, BarChart3, RefreshCw, LogOut, CheckCircle, XCircle, FileText, MapPin, Mail, ChevronRight, Clock, Building2, Handshake, DollarSign, PieChart } from "lucide-react";
import { db, handleFirestoreError, OperationType, resetUserData, logout } from "../lib/firebase";
import { collection, query, onSnapshot, limit, getCountFromServer, updateDoc, doc, orderBy } from "firebase/firestore";
import { cn } from "../lib/utils";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalSchools: 0,
    verifiedSchools: 0,
    pendingSchools: 0,
    totalNgos: 0,
    approvedNgos: 0,
    pendingNgos: 0,
    totalRequests: 0,
    totalDonations: 0,
    totalDonationAmount: 0,
    platformRevenue: 0
  });
  const [users, setUsers] = useState<any[]>([]);
  const [activity, setActivity] = useState<any[]>([]);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [viewedDocs, setViewedDocs] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<"overview" | "revenue">("overview");

  useEffect(() => {
    // Listen for all users
    const qUsers = query(collection(db, "users"), orderBy("createdAt", "desc"));
    const unsubscribeUsers = onSnapshot(qUsers, (snapshot) => {
      const allUsers = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      console.log("AdminDashboard: Fetched", allUsers.length, "users");
      setUsers(allUsers);

      // Calculate Stats
      const schools = allUsers.filter(u => u.userRole === "school");
      const ngos = allUsers.filter(u => u.userRole === "ngo" || u.userRole === "ngo_business");

      setStats(prev => ({
        ...prev,
        totalSchools: schools.length,
        verifiedSchools: schools.filter(s => s.isVerified === true).length,
        pendingSchools: schools.filter(s => s.isVerified !== true).length,
        totalNgos: ngos.length,
        approvedNgos: ngos.filter(n => n.isVerified === true).length,
        pendingNgos: ngos.filter(n => n.isVerified !== true).length,
      }));

      // Generate Activity Feed
      const recentActivity = allUsers.slice(0, 10).map(u => {
        let action = "joined the platform";
        if (u.isVerified) action = "was verified/approved";

        let timeStr = "Recently";
        try {
          if (u.createdAt && typeof u.createdAt.toDate === 'function') {
            timeStr = u.createdAt.toDate().toLocaleTimeString();
          } else if (u.createdAt instanceof Date) {
            timeStr = u.createdAt.toLocaleTimeString();
          }
        } catch (e) {
          console.warn("Error formatting date for user", u.id, e);
        }

        return {
          id: u.id,
          text: `${u.userRole === 'school' ? 'School' : u.userRole === 'ngo' ? 'NGO' : 'User'} ${u.displayName || u.email || 'New User'} ${action}`,
          time: timeStr,
          type: u.userRole
        };
      });
      setActivity(recentActivity);
    }, (error) => {
      console.error("AdminDashboard: Firestore error:", error);
    });

    // Fetch Global Stats & Donation Amounts
    const unsubscribeDonations = onSnapshot(collection(db, "donations"), (snapshot) => {
      let totalAmount = 0;
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        totalAmount += Number(data.amount) || 0;
      });

      setStats(prev => ({
        ...prev,
        totalDonations: snapshot.size,
        totalDonationAmount: totalAmount,
        platformRevenue: totalAmount * 0.05 // 5% hypothetical fee
      }));
    });

    const fetchGlobalStats = async () => {
      try {
        const reqCount = await getCountFromServer(collection(db, "requests"));
        setStats(prev => ({
          ...prev,
          totalRequests: reqCount.data().count
        }));
      } catch (e) {
        console.error(e);
      }
    };
    fetchGlobalStats();

    return () => {
      unsubscribeUsers();
      unsubscribeDonations();
    };
  }, []);

  const [previewDoc, setPreviewDoc] = useState<{ id: string; name: string; base64: string } | null>(null);

  const markAsViewed = (id: string) => {
    setViewedDocs(prev => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  };

  const handleVerify = async (userId: string, status: boolean) => {
    try {
      await updateDoc(doc(db, "users", userId), {
        isVerified: status,
        rejectionNote: status ? null : "Document verification failed. Please re-upload clear documents."
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
    }
  };

  const pendingSchools = users.filter(u => u.userRole === "school" && u.isVerified !== true);
  const pendingNgos = users.filter(u => (u.userRole === "ngo" || u.userRole === "ngo_business") && u.isVerified !== true);

  const schoolProgress = stats.totalSchools > 0 ? (stats.verifiedSchools / stats.totalSchools) * 100 : 0;
  const ngoProgress = stats.totalNgos > 0 ? (stats.approvedNgos / stats.totalNgos) * 100 : 0;

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-20">
      {/* DOCUMENT PREVIEW MODAL */}
      <AnimatePresence>
        {previewDoc && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[100] flex items-center justify-center p-6" onClick={() => setPreviewDoc(null)}>
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-[40px] p-8 max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-serif">{previewDoc.name}</h2>
                <button onClick={() => setPreviewDoc(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <XCircle size={24} className="text-gray-400" />
                </button>
              </div>
              <div className="flex-1 overflow-auto bg-gray-50 rounded-3xl p-4 flex items-center justify-center min-h-[400px]">
                {previewDoc.base64.startsWith('data:image') ? (
                  <img src={previewDoc.base64} alt="Document" className="max-w-full h-auto rounded-xl shadow-lg" />
                ) : (
                  <div className="text-center">
                    <FileText size={80} className="text-gray-200 mx-auto mb-4" />
                    <p className="text-gray-500 font-serif">PDF Document</p>
                    <a
                      href={previewDoc.base64}
                      download={previewDoc.name}
                      className="inline-block mt-4 px-8 py-3 bg-radiant-pink text-white rounded-full font-bold uppercase tracking-widest text-xs shadow-lg"
                    >
                      Download to View
                    </a>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-serif text-radiant-ink">Admin Dashboard</h1>
          <p className="text-gray-500 mt-1">Verifying partners and monitoring platform growth.</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setShowResetConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-black/5 rounded-full text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-red-500 transition-colors shadow-sm"
          >
            <RefreshCw size={12} />
            Reset Data
          </button>
          <button
            onClick={() => logout()}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-black/5 rounded-full text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-radiant-pink transition-colors shadow-sm"
          >
            <LogOut size={12} />
            Sign Out
          </button>
        </div>
      </div>

      {/* TAB NAVIGATION */}
      <div className="flex gap-4 border-b border-black/5 pb-2">
        <button
          onClick={() => setActiveTab("overview")}
          className={cn(
            "pb-4 px-2 text-sm font-bold uppercase tracking-widest transition-all relative",
            activeTab === "overview" ? "text-radiant-pink" : "text-gray-400 hover:text-gray-600"
          )}
        >
          Overview
          {activeTab === "overview" && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-radiant-pink" />}
        </button>
        <button
          onClick={() => setActiveTab("revenue")}
          className={cn(
            "pb-4 px-2 text-sm font-bold uppercase tracking-widest transition-all relative",
            activeTab === "revenue" ? "text-radiant-pink" : "text-gray-400 hover:text-gray-600"
          )}
        >
          Revenue & Sustainability
          {activeTab === "revenue" && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-radiant-pink" />}
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === "overview" ? (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-8"
          >
            {/* PROGRESS TRACKER */}
            <section className="grid md:grid-cols-2 gap-6">
              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center">
                      <Building2 size={20} />
                    </div>
                    <h3 className="text-xl font-serif">Schools Progress</h3>
                  </div>
                  <span className="text-2xl font-serif text-blue-600">{Math.round(schoolProgress)}%</span>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Verified</p>
                    <p className="text-xl font-serif">{stats.verifiedSchools}</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Pending</p>
                    <p className="text-xl font-serif text-orange-500">{stats.pendingSchools}</p>
                  </div>
                </div>
                <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${schoolProgress}%` }}
                    className="h-full bg-blue-500"
                  />
                </div>
                <p className="text-[10px] text-gray-400 mt-3 uppercase tracking-widest font-bold text-center">Total Schools: {stats.totalSchools}</p>
              </div>

              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-radiant-pink/10 text-radiant-pink rounded-2xl flex items-center justify-center">
                      <Handshake size={20} />
                    </div>
                    <h3 className="text-xl font-serif">NGOs Progress</h3>
                  </div>
                  <span className="text-2xl font-serif text-radiant-pink">{Math.round(ngoProgress)}%</span>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Approved</p>
                    <p className="text-xl font-serif">{stats.approvedNgos}</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Pending</p>
                    <p className="text-xl font-serif text-orange-500">{stats.pendingNgos}</p>
                  </div>
                </div>
                <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${ngoProgress}%` }}
                    className="h-full bg-radiant-pink"
                  />
                </div>
                <p className="text-[10px] text-gray-400 mt-3 uppercase tracking-widest font-bold text-center">Total NGOs: {stats.totalNgos}</p>
              </div>
            </section>

            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                {/* PENDING SCHOOLS */}
                <section className="bg-white rounded-[32px] p-8 border border-black/5 shadow-sm">
                  <div className="flex items-center gap-3 mb-6">
                    <Shield className="text-blue-500" size={24} />
                    <h3 className="text-xl font-serif">Pending Schools ({pendingSchools.length})</h3>
                  </div>
                  <div className="space-y-4">
                    {pendingSchools.map((school) => (
                      <div key={school.id} className="p-6 bg-gray-50 rounded-3xl border border-black/5 flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-blue-500 shadow-sm border border-black/5">
                              <Building2 size={24} />
                            </div>
                            <div>
                              <h4 className="font-serif text-lg">{school.displayName || school.onboardingData?.school_basic?.schoolName || "Unknown School"}</h4>
                              <div className="flex items-center gap-2 text-gray-400 text-xs font-medium">
                                <MapPin size={12} />
                                {school.onboardingData?.school_basic?.city || "Unknown City"}, {school.onboardingData?.school_basic?.country || "Unknown Country"}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleVerify(school.id, true)}
                            disabled={!viewedDocs.has(school.id)}
                            className="px-4 py-2 bg-green-500 text-white text-[10px] font-bold uppercase tracking-widest rounded-full hover:scale-105 transition-all shadow-lg shadow-green-500/20 disabled:opacity-30 disabled:grayscale disabled:scale-100"
                          >
                            Verify School
                          </button>
                          <button
                            onClick={() => handleVerify(school.id, false)}
                            className="px-4 py-2 bg-white border border-gray-200 text-gray-400 text-[10px] font-bold uppercase tracking-widest rounded-full hover:bg-red-50 hover:text-red-500 transition-all"
                          >
                            Reject
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* PENDING NGOS */}
                <section className="bg-white rounded-[32px] p-8 border border-black/5 shadow-sm">
                  <div className="flex items-center gap-3 mb-6">
                    <Shield className="text-radiant-pink" size={24} />
                    <h3 className="text-xl font-serif">Pending NGOs ({pendingNgos.length})</h3>
                  </div>
                  <div className="space-y-4">
                    {pendingNgos.map((ngo) => (
                      <div key={ngo.id} className="p-6 bg-gray-50 rounded-3xl border border-black/5 flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-radiant-pink shadow-sm border border-black/5">
                              <Handshake size={24} />
                            </div>
                            <div>
                              <h4 className="font-serif text-lg">{ngo.displayName || ngo.onboardingData?.ngo_basic?.orgName || "Unknown NGO"}</h4>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleVerify(ngo.id, true)}
                            disabled={!viewedDocs.has(ngo.id)}
                            className="px-4 py-2 bg-radiant-pink text-white text-[10px] font-bold uppercase tracking-widest rounded-full hover:scale-105 transition-all shadow-lg shadow-radiant-pink/20 disabled:opacity-30 disabled:grayscale disabled:scale-100"
                          >
                            Approve NGO
                          </button>
                          <button
                            onClick={() => handleVerify(ngo.id, false)}
                            className="px-4 py-2 bg-white border border-gray-200 text-gray-400 text-[10px] font-bold uppercase tracking-widest rounded-full hover:bg-red-50 hover:text-red-500 transition-all"
                          >
                            Reject
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>

              {/* ACTIVITY FEED */}
              <div className="space-y-8">
                <section className="bg-white rounded-[32px] p-8 border border-black/5 shadow-sm sticky top-8">
                  <div className="flex items-center gap-3 mb-6">
                    <TrendingUp className="text-green-500" size={24} />
                    <h3 className="text-xl font-serif">Recent Activity</h3>
                  </div>
                  <div className="space-y-6">
                    {activity.map((item, idx) => (
                      <div key={idx} className="flex gap-4 relative">
                        <div className="w-6 h-6 rounded-full bg-gray-50 flex items-center justify-center shrink-0 z-10 text-gray-400">
                          <Clock size={12} />
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 leading-relaxed">{item.text}</p>
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{item.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="revenue"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-8"
          >
            {/* REVENUE STATS */}
            <section className="grid md:grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="w-10 h-10 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mb-4">
                  <DollarSign size={20} />
                </div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Total Donation Value</p>
                <h3 className="text-3xl font-serif text-gray-800">R {stats.totalDonationAmount.toLocaleString()}</h3>
                <p className="text-[10px] text-green-500 font-bold mt-2 flex items-center gap-1">
                  <TrendingUp size={12} /> 12% from last month
                </p>
              </div>

              <div className="bg-white p-8 rounded-[32px] border border-radiant-pink/10 shadow-xl shadow-radiant-pink/5">
                <div className="w-10 h-10 bg-radiant-pink/10 text-radiant-pink rounded-2xl flex items-center justify-center mb-4">
                  <TrendingUp size={20} />
                </div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Platform Revenue (5%)</p>
                <h3 className="text-3xl font-serif text-radiant-pink">R {stats.platformRevenue.toLocaleString()}</h3>
                <p className="text-[10px] text-gray-400 font-bold mt-2 uppercase tracking-widest">Calculated from successful transactions</p>
              </div>

              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center mb-4">
                  <Package size={20} />
                </div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Total Items Shipped</p>
                <h3 className="text-3xl font-serif text-gray-800">{stats.totalDonations}</h3>
                <p className="text-[10px] text-gray-400 font-bold mt-2 uppercase tracking-widest">Support units delivered</p>
              </div>
            </section>

            {/* REVENUE DETAILS */}
            <div className="grid lg:grid-cols-2 gap-8">
              <section className="bg-white rounded-[32px] p-8 border border-black/5 shadow-sm">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center">
                    <PieChart size={20} />
                  </div>
                  <h3 className="text-xl font-serif">Revenue Streams</h3>
                </div>

                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-radiant-pink" />
                      <span className="text-sm font-medium">Donation Service Fees</span>
                    </div>
                    <span className="text-sm font-bold">75%</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                      <span className="text-sm font-medium">Premium NGO Memberships</span>
                    </div>
                    <span className="text-sm font-bold">15%</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-sm font-medium">Corporate Sponsorships</span>
                    </div>
                    <span className="text-sm font-bold">10%</span>
                  </div>
                </div>

              </section>

              <section className="bg-white rounded-[32px] p-8 border border-black/5 shadow-sm">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-10 h-10 bg-radiant-pink/10 text-radiant-pink rounded-2xl flex items-center justify-center">
                    <TrendingUp size={20} />
                  </div>
                  <h3 className="text-xl font-serif">Sustainability Goal</h3>
                </div>

                <div className="space-y-4">
                  <p className="text-sm text-gray-500 leading-relaxed">
                    Our current goal is to reach **R 10,000** in platform revenue per month.
                    This will allow us to support **50 more schools** across the province.
                  </p>
                  <div className="pt-4">
                    <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">
                      <span>Progress towards goal</span>
                      <span>{Math.min(100, Math.round((stats.platformRevenue / 10000) * 100))}%</span>
                    </div>
                    <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(100, (stats.platformRevenue / 10000) * 100)}%` }}
                        className="h-full bg-radiant-pink"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Target Schools</p>
                      <p className="text-xl font-serif">150</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Target ROI</p>
                      <p className="text-xl font-serif">24%</p>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {showResetConfirm && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl text-center"
          >
            <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center text-orange-500 mx-auto mb-4">
              <RefreshCw size={32} />
            </div>
            <h2 className="text-2xl font-serif mb-2">Reset Profile?</h2>
            <p className="text-sm text-gray-500 mb-6">
              This will clear all your onboarding data and sign you out. This action is permanent.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => resetUserData()}
                className="flex-1 py-3 rounded-full text-sm font-medium bg-orange-500 text-white shadow-lg shadow-orange-500/20 hover:scale-105 transition-transform"
              >
                Reset
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
