import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Package, RefreshCw, LogOut, Megaphone, Bell, Home, MessageCircle, HeartHandshake, User, ChevronRight, Heart, CheckCircle2, ArrowRight } from "lucide-react";
import MoodTracker from "../components/MoodTracker";
import ActivityFlow from "../components/ActivityFlow";
import SupportHub from "../components/SupportHub";
import ResourceReader from "../components/ResourceReader";
import ResourceHub from "../components/ResourceHub";
import NotificationCenter, { Notification } from "../components/NotificationCenter";
import CommunityChat from "../components/CommunityChat";
import { ALL_ARTICLES, Article } from "../data/resources";
import { db, auth, handleFirestoreError, OperationType, resetUserData, logout } from "../lib/firebase";
import { cn } from "../lib/utils";
import { collection, query, orderBy, limit, onSnapshot, doc, getDoc } from "firebase/firestore";
import { useEffect } from "react";

interface StudentDashboardProps {
  user: { role: string; [key: string]: any };
  userName?: string;
  streak?: number;
  confidenceScore?: number;
  onboardingData?: any;
}

export default function StudentDashboard({
  user,
  userName = "Radiant",
  streak = 0,
  confidenceScore = 0,
}: StudentDashboardProps) {
  const [activeTab, setActiveTab] = useState("home");
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showActivity, setShowActivity] = useState(false);
  const [showResource, setShowResource] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<any>(null);
  const [recentArticles, setRecentArticles] = useState<Article[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [studentOnboardingData, setStudentOnboardingData] = useState<any>(null);

  const handleArticleClick = (article: any) => {
    if (article.content) {
      setSelectedArticle(article.content);
      setShowResource(true);
      
      // Update recent articles
      setRecentArticles(prev => {
        const filtered = prev.filter(a => a.id !== article.id);
        return [article, ...filtered].slice(0, 5);
      });
    }
  };
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      category: "support",
      message: "Your school has received your support request.",
      timestamp: "2 hours ago",
      isRead: false,
      type: "support_hub"
    },
    {
      id: "2",
      category: "wellbeing",
      message: "How are you feeling today? Don't forget your daily check-in.",
      timestamp: "5 hours ago",
      isRead: false,
      type: "mood_checkin"
    },
    {
      id: "3",
      category: "alert",
      message: "A trusted organization has updated their services.",
      timestamp: "1 day ago",
      isRead: true,
      type: "alert_info"
    },
    {
      id: "4",
      category: "support",
      message: "Sanitary products are now available at your school.",
      timestamp: "3 hours ago",
      isRead: false,
      type: "support_hub"
    },
    {
      id: "5",
      category: "wellbeing",
      message: "Here's today's confidence boost ✨",
      timestamp: "6 hours ago",
      isRead: false,
      type: "mood_checkin"
    },
    {
      id: "6",
      category: "alert",
      message: "Important update from your school.",
      timestamp: "2 days ago",
      isRead: true,
      type: "alert_info"
    }
  ]);

  useEffect(() => {
    // Fetch private onboarding data for students
    const fetchPrivateData = async () => {
      if (!auth.currentUser) return;
      try {
        const docRef = doc(db, "student_private_details", auth.currentUser.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setStudentOnboardingData(docSnap.data().onboardingData);
        }
      } catch (error) {
        console.error("Error fetching private data:", error);
      }
    };

    fetchPrivateData();

    const q = query(
      collection(db, "announcements"),
      orderBy("timestamp", "desc"),
      limit(5)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setAnnouncements(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "announcements");
    });

    return () => unsubscribe();
  }, []);

  const renderTabContent = () => {
    switch (activeTab) {
      case "home":
        return (
          <div className="space-y-8">
            <header className="flex justify-between items-start">
              <div>
                <h1 className="text-4xl font-serif flex items-center gap-2">
                  Hey {userName} <span className="text-2xl">✨💖</span>
                </h1>
                <p className="text-gray-500 text-sm font-medium mt-1">How are you <span className="text-radiant-pink italic">really</span> feeling today?</p>
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setShowNotifications(true)}
                  className="relative p-2 bg-white rounded-full shadow-sm border border-black/5 text-gray-400 hover:text-radiant-pink transition-colors"
                >
                  <Bell size={20} />
                  {notifications.some(n => !n.isRead) && (
                    <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
                  )}
                </button>
                <div className="w-10 h-10 rounded-full bg-radiant-accent/20 border-2 border-white shadow-sm overflow-hidden">
                  <img 
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${userName}`} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </header>

            <MoodTracker />

            {/* Tiny Glow-Up Card */}
            <section className="relative overflow-hidden rounded-[32px] p-8 text-white shadow-xl shadow-radiant-pink/20">
              <div className="absolute inset-0 bg-gradient-to-br from-[#ff85b2] via-[#ea80fc] to-[#b388ff]" />
              <div className="absolute inset-0 opacity-30">
                {[...Array(6)].map((_, i) => (
                  <Sparkles 
                    key={i} 
                    className="absolute text-white" 
                    size={Math.random() * 20 + 10}
                    style={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      transform: `rotate(${Math.random() * 360}deg)`
                    }}
                  />
                ))}
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-4">
                  <h3 className="text-2xl font-serif">Tiny Glow-Up</h3>
                  <Sparkles className="text-yellow-200" size={20} />
                </div>
                
                <div className="space-y-4 mb-8">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/70 mb-1">Today's reminder:</p>
                    <p className="text-lg font-medium leading-tight">You don't need to be perfect to be worthy.</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/70 mb-1">Try this:</p>
                    <p className="text-sm text-white/90 italic">Say something kind to yourself out loud 🤍</p>
                  </div>
                </div>

                <button 
                  onClick={() => setShowActivity(true)}
                  className="w-full bg-white text-radiant-pink py-4 rounded-full font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 shadow-lg hover:scale-[1.02] transition-transform active:scale-95"
                >
                  I've got this ✨ <ChevronRight size={16} />
                </button>
              </div>
            </section>

            {/* Support Card */}
            <section className="bg-white rounded-[32px] p-8 border border-black/5 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-radiant-pink/5 rounded-full -mr-16 -mt-16 blur-3xl" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-xl font-serif">We've got you</h3>
                  <Heart className="text-radiant-pink/30 fill-radiant-pink/10" size={18} />
                </div>
                <p className="text-sm text-gray-500 mb-6 leading-relaxed">
                  If you need anything, you can ask here.<br />
                  No pressure. No judgement.
                </p>
                <button 
                  onClick={() => setActiveTab("support")}
                  className="w-full bg-radiant-pink text-white py-4 rounded-full font-bold uppercase tracking-widest text-xs shadow-lg shadow-radiant-pink/20 hover:bg-radiant-pink/90 transition-all active:scale-95"
                >
                  Ask for support
                </button>
              </div>
            </section>

            {/* For your glow-up */}
            <section className="space-y-6">
              <div className="flex items-center justify-between px-2">
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-serif">For your glow-up:</h3>
                  <Sparkles className="text-yellow-400" size={18} />
                </div>
              </div>
              
              <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide -mx-6 px-6">
                {ALL_ARTICLES.slice(0, 6).map((item, i) => (
                  <motion.div 
                    key={i}
                    whileHover={{ y: -5 }}
                    onClick={() => handleArticleClick(item)}
                    className="flex-shrink-0 w-44 bg-white rounded-[24px] overflow-hidden border border-black/5 shadow-sm group cursor-pointer active:scale-95 transition-transform"
                  >
                    <div className="h-32 bg-radiant-bg relative overflow-hidden">
                      <img 
                        src={item.img} 
                        alt={item.title} 
                        className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-500" 
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent" />
                    </div>
                    <div className="p-4">
                      <h4 className="text-xs font-bold text-gray-700 leading-tight">{item.title}</h4>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="px-2">
                <button 
                  onClick={() => setActiveTab("explore")}
                  className="w-full py-4 bg-gray-50 border border-black/5 rounded-2xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:bg-gray-100 hover:text-radiant-pink transition-all flex items-center justify-center gap-2"
                >
                  Explore more topics <ChevronRight size={14} />
                </button>
              </div>
            </section>
          </div>
        );
      case "explore":
        return (
          <ResourceHub 
            onBack={() => setActiveTab("home")}
            onArticleClick={handleArticleClick}
            recentArticles={recentArticles}
          />
        );
      case "support":
        return (
          <SupportHub 
            country={(studentOnboardingData || user.onboardingData)?.country || "South Africa"} 
          />
        );
      case "profile":
        return (
          <div className="space-y-8">
            <header className="text-center space-y-4">
              <div className="w-24 h-24 rounded-full bg-radiant-accent/20 border-4 border-white shadow-lg overflow-hidden mx-auto">
                <img 
                  src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${userName}`} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h2 className="text-3xl font-serif">{userName}</h2>
                <p className="text-gray-500 text-sm">Radiant Member since 2024</p>
              </div>
            </header>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-[24px] border border-black/5 shadow-sm text-center">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Streak</p>
                <p className="text-2xl font-serif text-radiant-pink">{streak} Days</p>
              </div>
              <div className="bg-white p-6 rounded-[24px] border border-black/5 shadow-sm text-center">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Confidence</p>
                <p className="text-2xl font-serif text-radiant-pink">{confidenceScore}%</p>
              </div>
            </div>

            <div className="bg-white rounded-[32px] p-2 border border-black/5 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-50">
                <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400">Settings</h3>
              </div>
              <div className="divide-y divide-gray-50">
                <button 
                  onClick={() => setShowResetConfirm(true)}
                  className="w-full flex items-center justify-between p-6 hover:bg-gray-50 transition-colors group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-orange-500">
                      <RefreshCw size={20} />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold text-gray-700">Reset Profile</p>
                      <p className="text-[10px] text-gray-400">Clear all data and start over</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-gray-300 group-hover:text-radiant-pink transition-colors" />
                </button>

                <button 
                  onClick={() => logout()}
                  className="w-full flex items-center justify-between p-6 hover:bg-gray-50 transition-colors group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center text-red-500">
                      <LogOut size={20} />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold text-gray-700">Sign Out</p>
                      <p className="text-[10px] text-gray-400">Logout from your account</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-gray-300 group-hover:text-radiant-pink transition-colors" />
                </button>
              </div>
            </div>
          </div>
        );
      case "chat":
        return (
          <div className="space-y-8 h-full">
            <header>
              <h2 className="text-3xl font-serif">Community Circle</h2>
              <p className="text-gray-500 text-sm">A safe space for girls to support each other.</p>
            </header>
            <CommunityChat />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      key="dashboard"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="pb-32"
    >
      {renderTabContent()}

      <AnimatePresence>
        {showActivity && (
          <ActivityFlow 
            onboardingData={studentOnboardingData || user.onboardingData} 
            onClose={() => setShowActivity(false)} 
          />
        )}
      </AnimatePresence>

      <NotificationCenter 
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        notifications={notifications}
        onMarkAsRead={(id) => {
          setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
        }}
        onClearAll={() => setNotifications([])}
        onAction={(type) => {
          setShowNotifications(false);
          if (type === "mood_checkin") {
            setActiveTab("home");
            // Scroll to mood tracker could be added here
          } else if (type === "support_hub") {
            setActiveTab("support");
          }
          // Add more navigation logic as needed
        }}
      />

      {selectedArticle && (
        <ResourceReader 
          isOpen={showResource}
          onClose={() => setShowResource(false)}
          article={selectedArticle}
        />
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-100 px-6 py-4 z-50">
        <div className="max-w-md mx-auto flex justify-between items-center">
          <button 
            onClick={() => setActiveTab("home")}
            className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === "home" ? "text-radiant-pink" : "text-gray-300")}
          >
            <Home size={24} />
            <span className="text-[10px] font-bold uppercase tracking-widest">Home</span>
          </button>
          <button 
            onClick={() => setActiveTab("chat")}
            className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === "chat" ? "text-radiant-pink" : "text-gray-300")}
          >
            <MessageCircle size={24} />
            <span className="text-[10px] font-bold uppercase tracking-widest">Chat</span>
          </button>
          <button 
            onClick={() => setActiveTab("support")}
            className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === "support" ? "text-radiant-pink" : "text-gray-300")}
          >
            <HeartHandshake size={24} />
            <span className="text-[10px] font-bold uppercase tracking-widest">Support</span>
          </button>
          <button 
            onClick={() => setActiveTab("profile")}
            className={cn("flex flex-col items-center gap-1 transition-colors", activeTab === "profile" ? "text-radiant-pink" : "text-gray-300")}
          >
            <User size={24} />
            <span className="text-[10px] font-bold uppercase tracking-widest">Profile</span>
          </button>
        </div>
      </nav>

      {showResetConfirm && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl text-center"
          >
            <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center text-orange-500 mx-auto mb-4">
              <RefreshCw size={32} />
            </div>
            <h2 className="text-2xl font-serif mb-2">Reset Profile?</h2>
            <p className="text-sm text-gray-500 mb-6">
              This will clear all your onboarding data and sign you out. This action is permanent.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => resetUserData()}
                className="flex-1 py-3 rounded-full text-sm font-medium bg-orange-500 text-white shadow-lg shadow-orange-500/20 hover:scale-105 transition-transform"
              >
                Reset
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}