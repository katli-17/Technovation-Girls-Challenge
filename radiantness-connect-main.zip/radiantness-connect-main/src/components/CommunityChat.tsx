import { useState, useEffect, useRef } from "react";
import { Send, Users, ShieldCheck, Heart, MessageCircle, ArrowLeft, PlusCircle, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "@/src/lib/utils";
import { db, auth, handleFirestoreError, OperationType } from "@/src/lib/firebase";
import { 
  collection, 
  query, 
  orderBy, 
  limit, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  doc, 
  updateDoc, 
  increment 
} from "firebase/firestore";

interface Post {
  id: string;
  text: string;
  author: string;
  authorId: string;
  color: string;
  likes: number;
  commentCount: number;
  timestamp: any;
}

interface Comment {
  id: string;
  text: string;
  author: string;
  authorId: string;
  timestamp: any;
}

export default function CommunityChat() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [activePostId, setActivePostId] = useState<string | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  
  // Separate states for feed input and modal input
  const [feedInput, setFeedInput] = useState("");
  const [modalInput, setModalInput] = useState("");
  
  const [isSending, setIsSending] = useState(false);
  const [showPostModal, setShowPostModal] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch Posts
  useEffect(() => {
    try {
      // Remove orderBy from the database query to ensure new posts (with null timestamps) 
      // appear immediately in the snapshot.
      const q = query(
        collection(db, "community_posts"),
        limit(50)
      );

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const fetchedPosts = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Post[];
        
        // Sort them locally so new posts (with null/pending timestamps) appear at the top
        fetchedPosts.sort((a, b) => {
          const timeA = a.timestamp?.toMillis ? a.timestamp.toMillis() : Date.now();
          const timeB = b.timestamp?.toMillis ? b.timestamp.toMillis() : Date.now();
          return timeB - timeA;
        });

        setPosts(fetchedPosts);
      }, (error) => {
        console.error("Feed Listener Error:", error);
        setErrorMessage("Could not load community feed. Check your permissions.");
      });

      return () => unsubscribe();
    } catch (err) {
      console.error("Setup Error:", err);
    }
  }, []);

  // Fetch Comments
  useEffect(() => {
    if (!activePostId) {
      setComments([]);
      return;
    }

    const q = query(
      collection(db, "community_posts", activePostId, "comments"),
      orderBy("timestamp", "asc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setComments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Comment[]);
    }, (error) => {
      console.error("Comments Listener Error:", error);
    });

    return () => unsubscribe();
  }, [activePostId]);

  const handleCreatePost = async () => {
    // Clear previous errors
    setErrorMessage(null);

    // Validation
    if (!modalInput.trim()) return;
    if (!auth.currentUser) {
      setErrorMessage("You must be signed in to post.");
      return;
    }
    if (isSending) return;

    setIsSending(true);
    console.log("Attempting to post to community_posts...");

    try {
      const anonymousName = `Radiant Girl ${Math.floor(Math.random() * 1000)}`;
      const colors = ["#d682bd", "#7c4dff", "#ea80fc", "#f06292", "#ff80ab"];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];

      const postData = {
        text: modalInput.trim(),
        author: anonymousName,
        authorId: auth.currentUser.uid,
        color: randomColor,
        likes: 0,
        commentCount: 0,
        timestamp: serverTimestamp()
      };

      await addDoc(collection(db, "community_posts"), postData);
      
      console.log("Post success!");
      setModalInput("");
      setShowPostModal(false);
    } catch (error: any) {
      console.error("CRITICAL POST ERROR:", error);
      setErrorMessage(error.message || "Failed to post. This is usually a Permission Denied error from Firebase.");
    } finally {
      setIsSending(false);
    }
  };

  const handleAddComment = async () => {
    if (!feedInput.trim() || !auth.currentUser || !activePostId || isSending) return;

    setIsSending(true);
    try {
      const anonymousName = `Radiant Girl ${Math.floor(Math.random() * 1000)}`;
      
      await addDoc(collection(db, "community_posts", activePostId, "comments"), {
        text: feedInput.trim(),
        author: anonymousName,
        authorId: auth.currentUser.uid,
        timestamp: serverTimestamp()
      });

      await updateDoc(doc(db, "community_posts", activePostId), {
        commentCount: increment(1)
      });

      setFeedInput("");
    } catch (error: any) {
      console.error("Comment Error:", error);
      setErrorMessage("Could not post comment.");
    } finally {
      setIsSending(false);
    }
  };

  const handleLike = async (postId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await updateDoc(doc(db, "community_posts", postId), {
        likes: increment(1)
      });
    } catch (error) {
      console.error("Like Error:", error);
    }
  };

  return (
    <div className="flex flex-col h-[700px] bg-radiant-bg/30 rounded-[40px] shadow-sm border border-black/5 overflow-hidden relative">
      {/* Error Overlay */}
      <AnimatePresence>
        {errorMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-20 left-6 right-6 z-[110] bg-red-500 text-white p-4 rounded-2xl shadow-xl flex items-center justify-between gap-4"
          >
            <div className="flex items-center gap-3">
              <AlertCircle size={20} />
              <p className="text-xs font-medium">{errorMessage}</p>
            </div>
            <button onClick={() => setErrorMessage(null)} className="text-white/70 hover:text-white font-bold">✕</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="p-6 bg-white border-b border-black/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {activePostId ? (
            <button 
              onClick={() => setActivePostId(null)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft size={20} className="text-gray-500" />
            </button>
          ) : (
            <div className="w-10 h-10 rounded-2xl bg-radiant-pink/10 flex items-center justify-center text-radiant-pink">
              <Users size={20} />
            </div>
          )}
          <div>
            <h3 className="font-serif text-lg leading-tight">
              {activePostId ? "Conversation" : "Community Circle"}
            </h3>
            <p className="text-[10px] uppercase tracking-widest text-gray-400">
              {activePostId ? "Sharing support" : "Connect with other girls"}
            </p>
          </div>
        </div>
        {!activePostId && (
          <button 
            onClick={() => setShowPostModal(true)}
            className="flex items-center gap-2 bg-radiant-pink text-white px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform"
          >
            <PlusCircle size={14} /> New Post
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        <AnimatePresence mode="wait">
          {!activePostId ? (
            <motion.div 
              key="feed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              {posts.map((post) => (
                <motion.div
                  key={post.id}
                  onClick={() => setActivePostId(post.id)}
                  className="bg-white p-6 rounded-[32px] border border-black/5 shadow-sm hover:shadow-md transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: post.color }} />
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{post.author}</span>
                  </div>
                  <p className="text-sm text-gray-700 leading-relaxed mb-4">{post.text}</p>
                  <div className="flex items-center gap-6 pt-4 border-t border-gray-50">
                    <button 
                      onClick={(e) => handleLike(post.id, e)}
                      className="flex items-center gap-2 text-gray-400 hover:text-radiant-pink transition-colors"
                    >
                      <Heart size={16} className={cn(post.likes > 0 && "fill-radiant-pink text-radiant-pink")} />
                      <span className="text-[10px] font-bold">{post.likes}</span>
                    </button>
                    <div className="flex items-center gap-2 text-gray-400">
                      <MessageCircle size={16} />
                      <span className="text-[10px] font-bold">{post.commentCount} Comments</span>
                    </div>
                  </div>
                </motion.div>
              ))}
              {posts.length === 0 && (
                <div className="text-center py-20 bg-white rounded-[32px] border border-dashed border-gray-200">
                  <p className="text-gray-400 italic">No posts yet. Be the first to share! ✨</p>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="thread"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Original Post */}
              {posts.find(p => p.id === activePostId) && (
                <div className="bg-white p-8 rounded-[32px] border border-radiant-pink/10 shadow-lg shadow-radiant-pink/5">
                  {(() => {
                    const post = posts.find(p => p.id === activePostId)!;
                    return (
                      <>
                        <div className="flex items-center gap-2 mb-4">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: post.color }} />
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{post.author}</span>
                        </div>
                        <p className="text-base text-gray-800 leading-relaxed">{post.text}</p>
                      </>
                    );
                  })()}
                </div>
              )}

              {/* Comments Section */}
              <div className="space-y-4 pl-4 border-l-2 border-radiant-pink/10">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-4">Supportive Comments</h4>
                {comments.map((comment) => (
                  <div key={comment.id} className="bg-white/80 p-4 rounded-2xl shadow-sm border border-black/5">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-[10px] font-bold text-radiant-pink uppercase tracking-wider">{comment.author}</span>
                    </div>
                    <p className="text-xs text-gray-600">{comment.text}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Input Area (Only for comments) */}
      {activePostId && (
        <div className="p-6 bg-white border-t border-black/5">
          <div className="relative">
            <input
              type="text"
              value={feedInput}
              onChange={(e) => setFeedInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddComment()}
              placeholder="Write a supportive comment..."
              className="w-full bg-radiant-bg rounded-full py-4 pl-6 pr-14 text-sm focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
            />
            <button
              onClick={handleAddComment}
              disabled={!feedInput.trim() || isSending}
              className="absolute right-2 top-2 w-10 h-10 bg-radiant-pink text-white rounded-full flex items-center justify-center transition-transform active:scale-90 disabled:opacity-50"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      )}

      {/* New Post Modal */}
      {showPostModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[40px] p-8 w-full max-w-md shadow-2xl"
          >
            <h3 className="text-2xl font-serif mb-2">Share with Community</h3>
            <p className="text-xs text-gray-400 mb-6 uppercase tracking-widest font-bold">Safe & Anonymous</p>
            
            <textarea
              value={modalInput}
              onChange={(e) => setModalInput(e.target.value)}
              placeholder="What's on your mind? You can ask for help or share an experience..."
              className="w-full h-40 bg-radiant-bg rounded-3xl p-6 text-sm focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 resize-none border-none mb-6"
            />
            
            <div className="flex gap-4">
              <button 
                onClick={() => {
                  setShowPostModal(false);
                  setModalInput("");
                  setErrorMessage(null);
                }}
                className="flex-1 py-4 rounded-full text-sm font-bold text-gray-400 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button 
                onClick={handleCreatePost}
                disabled={!modalInput.trim() || isSending}
                className={cn(
                  "flex-1 py-4 rounded-full text-sm font-bold text-white shadow-xl transition-all",
                  isSending ? "bg-gray-400" : "bg-radiant-pink shadow-radiant-pink/20 hover:scale-105 active:scale-95"
                )}
              >
                {isSending ? "Posting..." : "Post Now ✨"}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
