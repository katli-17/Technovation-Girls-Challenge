import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Package, Plus, Clock, CheckCircle, AlertCircle, ClipboardList, LogOut, RefreshCw, Megaphone, Trash2, Settings, UserPlus, Shield, Building2, ChevronDown, UserMinus } from "lucide-react";
import { db, auth, handleFirestoreError, OperationType, deleteAccount, logout } from "../lib/firebase";
import { collection, addDoc, query, where, onSnapshot, serverTimestamp, orderBy, doc, deleteDoc, updateDoc, limit } from "firebase/firestore";
import { cn, validateEmail } from "../lib/utils";

export default function SchoolDashboard({ user }: { user: any }) {
  const [activeSubTab, setActiveSubTab] = useState<"requests" | "announcements" | "history" | "profile" | "settings">("requests");
  const [requests, setRequests] = useState<any[]>([]);
  const [ngoOffers, setNgoOffers] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [staffMembers, setStaffMembers] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showAnnouncementModal, setShowAnnouncementModal] = useState(false);
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [newRequest, setNewRequest] = useState({ productType: "Pads", quantity: 50, urgency: "medium" });
  const [newAnnouncement, setNewAnnouncement] = useState({
    type: "supplies" as "supplies" | "workshop" | "session" | "general",
    title: "",
    content: ""
  });
  const [newStaff, setNewStaff] = useState({
    name: "",
    email: "",
    role: "teacher" as "admin" | "teacher" | "coordinator"
  });

  // Settings State
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [editProfile, setEditProfile] = useState({
    displayName: "",
    school_location: { city: "", country: "", address: "" }
  });

  useEffect(() => {
    if (!auth.currentUser) return;

    // Fetch Profile
    const unsubscribeProfile = onSnapshot(doc(db, "users", auth.currentUser.uid), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setProfile(data);
        setEditProfile({
          displayName: data.displayName || "",
          school_location: data.onboardingData?.school_location || { city: "", country: "", address: "" }
        });
      }
    });

    // Fetch Requests
    const qRequests = query(
      collection(db, "requests"),
      where("requesterUid", "==", auth.currentUser.uid),
      orderBy("timestamp", "desc")
    );

    const unsubscribeRequests = onSnapshot(qRequests, (snapshot) => {
      setRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "requests");
    });

    // Fetch Announcements
    const qAnnouncements = query(
      collection(db, "announcements"),
      where("schoolUid", "==", auth.currentUser.uid),
      orderBy("timestamp", "desc")
    );

    const unsubscribeAnnouncements = onSnapshot(qAnnouncements, (snapshot) => {
      setAnnouncements(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "announcements");
    });

    // Fetch Staff
    const qStaff = query(
      collection(db, "staff"),
      where("schoolUid", "==", auth.currentUser.uid),
      orderBy("addedAt", "desc")
    );

    const unsubscribeStaff = onSnapshot(qStaff, (snapshot) => {
      setStaffMembers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "staff");
    });

    // Fetch NGO Offers (Donations logged by NGOs)
    const qOffers = query(
      collection(db, "donations"),
      orderBy("timestamp", "desc"),
      limit(10)
    );

    const unsubscribeOffers = onSnapshot(qOffers, (snapshot) => {
      setNgoOffers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "donations");
    });

    return () => {
      unsubscribeProfile();
      unsubscribeRequests();
      unsubscribeAnnouncements();
      unsubscribeStaff();
      unsubscribeOffers();
    };
  }, []);

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    try {
      await addDoc(collection(db, "requests"), {
        requesterUid: auth.currentUser.uid,
        schoolName: profile?.displayName || "Unknown School",
        productType: newRequest.productType,
        quantity: newRequest.quantity,
        urgency: newRequest.urgency,
        status: "pending",
        location: profile?.onboardingData?.school_location || null,
        timestamp: serverTimestamp(),
      });
      setShowRequestModal(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "requests");
    }
  };

  const handleSubmitAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    try {
      await addDoc(collection(db, "announcements"), {
        schoolUid: auth.currentUser.uid,
        schoolName: profile?.displayName || "Your School",
        type: newAnnouncement.type,
        title: newAnnouncement.title,
        content: newAnnouncement.content,
        timestamp: serverTimestamp(),
      });
      setShowAnnouncementModal(false);
      setNewAnnouncement({ type: "supplies", title: "", content: "" });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "announcements");
    }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    try {
      await deleteDoc(doc(db, "announcements", id));
      setShowDeleteConfirm(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `announcements/${id}`);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    setIsSavingProfile(true);
    setSaveSuccess(false);
    try {
      await updateDoc(doc(db, "users", auth.currentUser.uid), {
        displayName: editProfile.displayName,
        "onboardingData.school_location": editProfile.school_location
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${auth.currentUser.uid}`);
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleStaffSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    if (!validateEmail(newStaff.email)) {
      alert("Please enter a valid email address with '@'.");
      return;
    }

    try {
      await addDoc(collection(db, "staff"), {
        schoolUid: auth.currentUser.uid,
        name: newStaff.name,
        email: newStaff.email,
        role: newStaff.role,
        addedAt: serverTimestamp(),
      });
      setShowStaffModal(false);
      setNewStaff({ name: "", email: "", role: "teacher" });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "staff");
    }
  };

  const handleRemoveStaff = async (id: string) => {
    try {
      await deleteDoc(doc(db, "staff", id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `staff/${id}`);
    }
  };

  const handleTogglePermission = async (permission: string) => {
    if (!auth.currentUser || !profile) return;
    
    const currentPermissions = profile.permissions || {
      postAnnouncements: true,
      requestSupplies: true,
      viewAnalytics: true
    };

    try {
      await updateDoc(doc(db, "users", auth.currentUser.uid), {
        [`permissions.${permission}`]: !currentPermissions[permission as keyof typeof currentPermissions]
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${auth.currentUser.uid}`);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="text-orange-500" size={18} />;
      case "approved": return <CheckCircle className="text-blue-500" size={18} />;
      case "rejected": return <AlertCircle className="text-red-500" size={18} />;
      case "shipped": return <Package className="text-purple-500" size={18} />;
      case "delivered": return <CheckCircle className="text-green-500" size={18} />;
      default: return <AlertCircle className="text-gray-500" size={18} />;
    }
  };

  return (
    <div className="space-y-8">
      {profile && profile.isVerified === true && (
        <div className="bg-green-50 border border-green-100 p-4 rounded-3xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-green-500 shadow-sm">
            <CheckCircle size={20} />
          </div>
          <div>
            <p className="text-sm font-serif text-green-950">Your school is verified! You can now request supplies.</p>
            <p className="text-[10px] text-green-700/70 font-bold uppercase tracking-widest">Profile Active & Visible to NGOs</p>
          </div>
        </div>
      )}
      
      {profile && profile.isVerified !== true && (
        <div className="bg-orange-50 border border-orange-100 p-4 rounded-3xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-orange-500 shadow-sm">
            <Shield size={20} />
          </div>
          <div>
            <p className="text-sm font-serif text-orange-950">Your school profile is pending admin verification.</p>
            <p className="text-[10px] text-orange-700/70 font-bold uppercase tracking-widest">Donations unlock after approval.</p>
          </div>
        </div>
      )}

      <div className="flex justify-end gap-3 -mb-4">
        <button 
          onClick={() => logout()}
          className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-radiant-pink transition-colors"
        >
          <LogOut size={12} />
          Sign Out
        </button>
      </div>

      <header className="flex justify-between items-end">
        <div className="flex items-center gap-4">
          {profile?.avatarBase64 ? (
            <img src={profile.avatarBase64} alt="Profile" className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-md" />
          ) : (
            <div className="w-16 h-16 rounded-full bg-radiant-pink/10 flex items-center justify-center text-radiant-pink shadow-md">
              <Building2 size={32} />
            </div>
          )}
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-serif">
                {profile?.displayName || (profile?.userRole === "parent" ? "Parent Dashboard" : "School Dashboard")}
              </h1>
              {profile?.isVerified ? (
                <span className="bg-green-100 text-green-700 text-[9px] font-bold uppercase tracking-widest px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
                  <CheckCircle size={10} />
                  Verified School
                </span>
              ) : (
                <span className="bg-gray-100 text-gray-500 text-[9px] font-bold uppercase tracking-widest px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
                  <Clock size={10} />
                  Awaiting Verification
                </span>
              )}
            </div>
            <p className="text-gray-500 text-sm italic mt-1">
              {profile?.userRole === "parent" 
                ? `Supporting ${profile?.onboardingData?.parent_basic?.studentName || "your student"}'s growth.`
                : "Support your students and monitor well-being."}
            </p>
          </div>
        </div>
        <div className="flex bg-white rounded-full p-1 border border-black/5 shadow-sm overflow-x-auto scrollbar-hide">
          <button 
            onClick={() => setActiveSubTab("requests")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeSubTab === "requests" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <ClipboardList size={14} />
            Requests
          </button>
          <button 
            onClick={() => setActiveSubTab("history")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeSubTab === "history" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <Clock size={14} />
            History
          </button>
          <button 
            onClick={() => setActiveSubTab("announcements")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeSubTab === "announcements" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <Megaphone size={14} />
            Announcements
          </button>
          <button 
            onClick={() => setActiveSubTab("settings")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeSubTab === "settings" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <Settings size={14} />
            Settings
          </button>
        </div>
      </header>

      {activeSubTab === "requests" ? (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <section className="grid grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-[24px] border border-black/5 shadow-sm">
              <span className="text-3xl font-serif text-radiant-pink">{requests.length}</span>
              <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-1">Total Requests</p>
            </div>
            <div className="bg-white p-6 rounded-[24px] border border-black/5 shadow-sm">
              <span className="text-3xl font-serif text-radiant-pink">
                {requests.filter(r => r.status === "pending" || r.status === "approved" || r.status === "in-progress" || r.status === "shipped").length}
              </span>
              <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-1">Active Requests</p>
            </div>
          </section>

          <section>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-serif">Active Requests</h3>
              <button 
                onClick={() => !profile?.isVerified ? null : setShowRequestModal(true)}
                disabled={profile?.isVerified === false}
                className={cn(
                  "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg transition-all flex items-center gap-2",
                  profile?.isVerified === false 
                    ? "bg-gray-100 text-gray-400 cursor-not-allowed shadow-none" 
                    : "bg-radiant-pink text-white shadow-radiant-pink/20 hover:scale-105"
                )}
              >
                <Plus size={14} />
                New Request
              </button>
            </div>
            <div className="space-y-3">
              {requests.filter(r => r.status !== "delivered" && r.status !== "rejected").map((request) => (
                <div key={request.id} className="bg-white p-4 rounded-[20px] border border-black/5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-radiant-bg flex items-center justify-center text-radiant-pink">
                      <Package size={20} />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">{request.productType}</h4>
                      <p className="text-[10px] text-gray-400 uppercase tracking-wider">Qty: {request.quantity} • {request.timestamp?.toDate().toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-gray-50 rounded-full">
                    {getStatusIcon(request.status)}
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">
                      {request.status}
                    </span>
                  </div>
                </div>
              ))}
              {requests.filter(r => r.status !== "delivered" && r.status !== "rejected").length === 0 && (
                <p className="text-center py-12 text-gray-400 italic text-sm">No active requests. Start by creating one!</p>
              )}
            </div>
          </section>
        </div>
      ) : activeSubTab === "history" ? (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <section>
            <h3 className="text-xl font-serif mb-4">Request History</h3>
            <div className="space-y-3">
              {requests.map((request) => (
                <div key={request.id} className="bg-white p-4 rounded-[20px] border border-black/5 flex items-center justify-between opacity-80 hover:opacity-100 transition-opacity">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center",
                      request.status === "delivered" ? "bg-green-50 text-green-500" : 
                      request.status === "rejected" ? "bg-red-50 text-red-500" : 
                      "bg-gray-50 text-gray-400"
                    )}>
                      {request.status === "delivered" ? <CheckCircle size={20} /> : <Clock size={20} />}
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">{request.productType}</h4>
                      <p className="text-[10px] text-gray-400 uppercase tracking-wider">
                        Requested: {request.timestamp?.toDate().toLocaleDateString()} • Qty: {request.quantity}
                      </p>
                      {request.rejectionReason && (
                        <p className="text-[10px] text-red-500 mt-1 italic">Reason: {request.rejectionReason}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-gray-50 rounded-full">
                    {getStatusIcon(request.status)}
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">
                      {request.status}
                    </span>
                  </div>
                </div>
              ))}
              {requests.length === 0 && (
                <p className="text-center py-12 text-gray-400 italic text-sm">Your request history will appear here.</p>
              )}
            </div>
          </section>
        </div>
      ) : activeSubTab === "announcements" ? (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <section>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-serif">Announcements</h3>
              <button 
                onClick={() => !profile?.isVerified ? null : setShowAnnouncementModal(true)}
                disabled={profile?.isVerified === false}
                className={cn(
                  "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg transition-all flex items-center gap-2",
                  profile?.isVerified === false 
                    ? "bg-gray-100 text-gray-400 cursor-not-allowed shadow-none" 
                    : "bg-radiant-pink text-white shadow-radiant-pink/20 hover:scale-105"
                )}
              >
                <Plus size={14} />
                New Announcement
              </button>
            </div>
            <div className="space-y-4">
              {announcements.map((announcement) => (
                <div key={announcement.id} className="bg-white p-6 rounded-[24px] border border-black/5 shadow-sm relative group">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        "px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-widest",
                        announcement.type === "supplies" ? "bg-green-100 text-green-600" :
                        announcement.type === "workshop" ? "bg-blue-100 text-blue-600" :
                        announcement.type === "session" ? "bg-purple-100 text-purple-600" :
                        "bg-gray-100 text-gray-600"
                      )}>
                        {announcement.type}
                      </span>
                      <span className="text-[10px] text-gray-400">
                        {announcement.timestamp?.toDate().toLocaleDateString()}
                      </span>
                    </div>
                    <button 
                      onClick={() => setShowDeleteConfirm(announcement.id)}
                      className="text-gray-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <h4 className="font-serif text-lg mb-2">{announcement.title}</h4>
                  <p className="text-sm text-gray-600 leading-relaxed">{announcement.content}</p>
                </div>
              ))}
              {announcements.length === 0 && (
                <p className="text-center py-12 text-gray-400 italic text-sm">No announcements yet. Keep your students informed!</p>
              )}
            </div>
          </section>
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <section className="grid md:grid-cols-3 gap-6">
            {/* School Profile */}
            <div className="md:col-span-2 bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
              <div className="flex items-center gap-3 mb-6">
                <Building2 className="text-radiant-pink" size={24} />
                <h3 className="text-xl font-serif">School Profile</h3>
              </div>
              <form onSubmit={handleSaveProfile} className="space-y-6">
                <div className="flex items-center gap-6 mb-4">
                  <div className="relative">
                    {profile?.avatarBase64 ? (
                      <img src={profile.avatarBase64} alt="Avatar" className="w-20 h-20 rounded-full object-cover border-2 border-gray-100" />
                    ) : (
                      <div className="w-20 h-20 rounded-full bg-gray-50 flex items-center justify-center text-gray-300 border-2 border-gray-100">
                        <Building2 size={24} />
                      </div>
                    )}
                    <label className="absolute bottom-0 right-0 bg-radiant-pink text-white p-1.5 rounded-full shadow-lg cursor-pointer hover:scale-110 transition-transform">
                      <Plus size={12} />
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            const img = new Image();
                            img.onload = () => {
                              const canvas = document.createElement("canvas");
                              const MAX_WIDTH = 250;
                              const MAX_HEIGHT = 250;
                              let width = img.width;
                              let height = img.height;

                              if (width > height) {
                                if (width > MAX_WIDTH) {
                                  height *= MAX_WIDTH / width;
                                  width = MAX_WIDTH;
                                }
                              } else {
                                if (height > MAX_HEIGHT) {
                                  width *= MAX_HEIGHT / height;
                                  height = MAX_HEIGHT;
                                }
                              }
                              canvas.width = width;
                              canvas.height = height;
                              const ctx = canvas.getContext("2d");
                              ctx?.drawImage(img, 0, 0, width, height);
                              const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
                              
                              if (auth.currentUser) {
                                updateDoc(doc(db, "users", auth.currentUser.uid), { avatarBase64: dataUrl });
                              }
                            };
                            img.src = event.target?.result as string;
                          };
                          reader.readAsDataURL(file);
                        }}
                      />
                    </label>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-700">Profile Picture</h4>
                    <p className="text-[10px] text-gray-400">Upload a logo or photo. (Max 5MB)</p>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">School Name</label>
                  <input 
                    type="text"
                    value={editProfile.displayName}
                    onChange={(e) => setEditProfile({ ...editProfile, displayName: e.target.value })}
                    className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">City</label>
                    <input 
                      type="text"
                      value={editProfile.school_location.city}
                      onChange={(e) => setEditProfile({ 
                        ...editProfile, 
                        school_location: { ...editProfile.school_location, city: e.target.value } 
                      })}
                      className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Country</label>
                    <input 
                      type="text"
                      value={editProfile.school_location.country}
                      onChange={(e) => setEditProfile({ 
                        ...editProfile, 
                        school_location: { ...editProfile.school_location, country: e.target.value } 
                      })}
                      className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Address</label>
                  <input 
                    type="text"
                    value={editProfile.school_location.address}
                    onChange={(e) => setEditProfile({ 
                      ...editProfile, 
                      school_location: { ...editProfile.school_location, address: e.target.value } 
                    })}
                    className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                  />
                </div>
                <button 
                  type="submit"
                  disabled={isSavingProfile}
                  className={cn(
                    "w-full py-3 rounded-full text-sm font-medium shadow-lg transition-all",
                    saveSuccess 
                      ? "bg-green-500 text-white shadow-green-500/20" 
                      : "bg-radiant-pink text-white shadow-radiant-pink/20 hover:scale-105"
                  )}
                >
                  {isSavingProfile ? "Saving..." : saveSuccess ? "Changes Saved!" : "Save Changes"}
                </button>
              </form>
            </div>

            {/* Staff Access & Permissions */}
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-[32px] border border-black/5 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <UserPlus className="text-radiant-pink" size={20} />
                  <h3 className="text-lg font-serif">Staff Access</h3>
                </div>
                <p className="text-xs text-gray-500 mb-4">Manage who can access this dashboard.</p>
                <div className="space-y-3">
                  {staffMembers.map((member) => (
                    <div key={member.id} className="flex items-center justify-between p-3 bg-radiant-bg rounded-xl border border-black/5 group">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-[10px] font-bold text-radiant-pink">
                          {member.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-xs font-medium">{member.name}</p>
                          <p className="text-[8px] text-gray-400 uppercase tracking-widest">{member.role}</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleRemoveStaff(member.id)}
                        className="text-gray-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  ))}
                  <button 
                    onClick={() => setShowStaffModal(true)}
                    className="w-full py-2 border-2 border-dashed border-black/5 rounded-xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:border-radiant-pink/20 hover:text-radiant-pink transition-all"
                  >
                    Add Staff Member
                  </button>
                </div>
              </div>

              <div className="bg-white p-6 rounded-[32px] border border-black/5 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <Shield className="text-radiant-pink" size={20} />
                  <h3 className="text-lg font-serif">Permissions</h3>
                </div>
                <div className="space-y-3">
                  {[
                    { id: "postAnnouncements", label: "Allow staff to post announcements" },
                    { id: "requestSupplies", label: "Allow staff to request supplies" },
                    { id: "viewAnalytics", label: "View analytics data" }
                  ].map((perm) => {
                    const isEnabled = profile?.permissions?.[perm.id] !== false;
                    return (
                      <div key={perm.id} className="flex items-center justify-between">
                        <span className="text-xs text-gray-600">{perm.label}</span>
                        <button 
                          onClick={() => handleTogglePermission(perm.id)}
                          className={cn(
                            "w-8 h-4 rounded-full relative transition-colors",
                            isEnabled ? "bg-radiant-pink" : "bg-gray-200"
                          )}
                        >
                          <div className={cn(
                            "absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all",
                            isEnabled ? "right-0.5" : "left-0.5"
                          )}></div>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Danger Zone */}
              <div className="bg-red-50 p-6 rounded-[32px] border border-red-100 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <AlertCircle className="text-red-500" size={20} />
                  <h3 className="text-lg font-serif text-red-900">Danger Zone</h3>
                </div>
                <p className="text-xs text-red-600 mb-6">
                  Deleting your profile is permanent. All your schools records, requests, and your account email will be removed from our servers.
                </p>
                <button 
                  onClick={() => setShowResetConfirm(true)}
                  className="w-full py-4 rounded-full text-[10px] font-bold uppercase tracking-widest bg-red-500 text-white shadow-lg shadow-red-500/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <UserMinus size={14} />
                  Delete Profile & Account
                </button>
              </div>
            </div>
          </section>
        </div>
      )}

      {showRequestModal && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl"
          >
            <div className="mb-6">
              <h2 className="text-2xl font-serif">New Supply Request</h2>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">
                Requesting as: <span className="text-radiant-pink">{profile?.displayName || "Your School"}</span>
              </p>
            </div>
            <form onSubmit={handleSubmitRequest} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Product Type</label>
                <select 
                  value={newRequest.productType}
                  onChange={(e) => setNewRequest({ ...newRequest, productType: e.target.value })}
                  className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                >
                  <option>Sanitary Pads</option>
                  <option>Uniforms</option>
                  <option>Stationary</option>
                  <option>Hygiene Kits</option>
                </select>
              </div>
              <div className="relative">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Urgency Level</label>
                <div className="relative">
                  <select 
                    value={newRequest.urgency}
                    onChange={(e) => setNewRequest({ ...newRequest, urgency: e.target.value })}
                    className="w-full appearance-none p-3 pr-10 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 text-sm"
                  >
                    <option value="low">Low (Next few weeks)</option>
                    <option value="medium">Medium (Next 7 days)</option>
                    <option value="high">High (Immediate need)</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Quantity</label>
                <input 
                  type="number"
                  value={newRequest.quantity}
                  onChange={(e) => setNewRequest({ ...newRequest, quantity: parseInt(e.target.value) })}
                  className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setShowRequestModal(false)}
                  className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-3 rounded-full text-sm font-medium bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform"
                >
                  Submit
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {showAnnouncementModal && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl"
          >
            <h2 className="text-2xl font-serif mb-6">New Announcement</h2>
            <form onSubmit={handleSubmitAnnouncement} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Type</label>
                <select 
                  value={newAnnouncement.type}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, type: e.target.value as any })}
                  className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                >
                  <option value="supplies">Supplies Available</option>
                  <option value="workshop">Workshop</option>
                  <option value="session">Session</option>
                  <option value="general">General</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Title</label>
                <input 
                  type="text"
                  required
                  value={newAnnouncement.title}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })}
                  placeholder="e.g. New Supplies Arrived!"
                  className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Content</label>
                <textarea 
                  required
                  value={newAnnouncement.content}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })}
                  placeholder="Details about the announcement..."
                  className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 h-32 resize-none"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setShowAnnouncementModal(false)}
                  className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-3 rounded-full text-sm font-medium bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform"
                >
                  Post
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {showStaffModal && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl"
          >
            <h2 className="text-2xl font-serif mb-6">Add Staff Member</h2>
            <form onSubmit={handleStaffSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Full Name</label>
                <input 
                  type="text"
                  required
                  value={newStaff.name}
                  onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                  placeholder="e.g. Jane Doe"
                  className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Email Address</label>
                <input 
                  type="email"
                  required
                  value={newStaff.email}
                  onChange={(e) => setNewStaff({ ...newStaff, email: e.target.value })}
                  placeholder="jane@school.edu"
                  className={cn(
                    "w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20",
                    newStaff.email && !validateEmail(newStaff.email) && "border-red-300 ring-2 ring-red-500/10"
                  )}
                />
                {newStaff.email && !validateEmail(newStaff.email) && (
                  <p className="text-[10px] text-red-500 font-bold uppercase tracking-widest mt-1">Missing @ symbol</p>
                )}
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Role</label>
                <select 
                  value={newStaff.role}
                  onChange={(e) => setNewStaff({ ...newStaff, role: e.target.value as any })}
                  className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                >
                  <option value="teacher">Teacher</option>
                  <option value="coordinator">Coordinator</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setShowStaffModal(false)}
                  className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-3 rounded-full text-sm font-medium bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform"
                >
                  Add Member
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl text-center"
          >
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center text-red-500 mx-auto mb-4">
              <Trash2 size={32} />
            </div>
            <h2 className="text-2xl font-serif mb-2">Delete Announcement?</h2>
            <p className="text-sm text-gray-500 mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowDeleteConfirm(null)}
                className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => handleDeleteAnnouncement(showDeleteConfirm)}
                className="flex-1 py-3 rounded-full text-sm font-medium bg-red-500 text-white shadow-lg shadow-red-500/20 hover:scale-105 transition-transform"
              >
                Delete
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {showResetConfirm && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[70] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl text-center"
          >
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center text-red-500 mx-auto mb-4">
              <UserMinus size={32} />
            </div>
            <h2 className="text-2xl font-serif mb-2">Delete Account?</h2>
            <p className="text-sm text-gray-500 mb-6">
              This will permanently delete your school profile and your authentication record. This cannot be undone.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => deleteAccount()}
                className="flex-1 py-3 rounded-full text-sm font-medium bg-red-600 text-white shadow-lg shadow-red-600/20 hover:scale-105 transition-transform"
              >
                Delete All Data
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
