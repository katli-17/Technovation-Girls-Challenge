import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Bell, Heart, ShieldAlert, HeartHandshake, CheckCircle2, Trash2, ChevronRight } from "lucide-react";
import { cn } from "@/src/lib/utils";

export type NotificationCategory = "support" | "wellbeing" | "alert";

export interface Notification {
  id: string;
  category: NotificationCategory;
  message: string;
  timestamp: string; // For simplicity in this demo, using strings like "2 hours ago"
  isRead: boolean;
  type: string; // specific type for navigation
}

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onClearAll: () => void;
  onAction: (type: string) => void;
}

export default function NotificationCenter({
  isOpen,
  onClose,
  notifications,
  onMarkAsRead,
  onClearAll,
  onAction
}: NotificationCenterProps) {
  const [activeFilter, setActiveFilter] = useState<"all" | NotificationCategory>("all");

  const filteredNotifications = notifications.filter(n => 
    activeFilter === "all" ? true : n.category === activeFilter
  );

  const getIcon = (category: NotificationCategory) => {
    switch (category) {
      case "support": return <HeartHandshake className="text-blue-500" size={20} />;
      case "wellbeing": return <Heart className="text-radiant-pink" size={20} />;
      case "alert": return <ShieldAlert className="text-amber-500" size={20} />;
    }
  };

  const getBgColor = (category: NotificationCategory) => {
    switch (category) {
      case "support": return "bg-blue-50";
      case "wellbeing": return "bg-radiant-pink/5";
      case "alert": return "bg-amber-50";
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: "100%" }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="fixed inset-0 bg-white z-[100] flex flex-col"
        >
          {/* Header */}
          <div className="p-6 flex justify-between items-center border-b border-gray-50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-radiant-pink/10 rounded-full flex items-center justify-center">
                <Bell className="text-radiant-pink" size={20} />
              </div>
              <h2 className="text-2xl font-serif">Notifications</h2>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X size={24} className="text-gray-400" />
            </button>
          </div>

          {/* Filters */}
          <div className="px-6 py-4 flex gap-2 overflow-x-auto scrollbar-hide">
            {["all", "support", "wellbeing", "alert"].map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter as any)}
                className={cn(
                  "px-5 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all whitespace-nowrap",
                  activeFilter === filter 
                    ? "bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20" 
                    : "bg-gray-50 text-gray-400 hover:bg-gray-100"
                )}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
            {filteredNotifications.length > 0 ? (
              <>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">
                    {filteredNotifications.length} Messages
                  </span>
                  <button 
                    onClick={onClearAll}
                    className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={12} />
                    Clear All
                  </button>
                </div>
                {filteredNotifications.map((n) => (
                  <motion.div
                    layout
                    key={n.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    onClick={() => {
                      onMarkAsRead(n.id);
                      onAction(n.type);
                    }}
                    className={cn(
                      "relative p-5 rounded-[24px] border border-black/5 shadow-sm transition-all active:scale-[0.98] cursor-pointer group",
                      n.isRead ? "bg-white opacity-70" : "bg-white ring-1 ring-radiant-pink/10"
                    )}
                  >
                    {!n.isRead && (
                      <div className="absolute top-5 right-5 w-2 h-2 bg-radiant-pink rounded-full" />
                    )}
                    <div className="flex gap-4">
                      <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center shrink-0", getBgColor(n.category))}>
                        {getIcon(n.category)}
                      </div>
                      <div className="space-y-1 pr-4">
                        <p className={cn("text-sm leading-relaxed", !n.isRead ? "font-bold text-gray-900" : "text-gray-600")}>
                          {n.message}
                        </p>
                        <p className="text-[10px] text-gray-400 font-medium">{n.timestamp}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                <div className="w-24 h-24 bg-radiant-pink/5 rounded-full flex items-center justify-center text-radiant-pink/20">
                  <CheckCircle2 size={48} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-serif">You're all caught up 💜</h3>
                  <p className="text-sm text-gray-400 max-w-[200px] mx-auto">No new notifications at the moment. Take a deep breath and have a radiant day!</p>
                </div>
              </div>
            )}
          </div>

          {/* Footer Info */}
          <div className="p-8 text-center">
            <p className="text-[10px] text-gray-300 uppercase tracking-[0.2em] font-medium">
              Your privacy is our priority. <br /> These alerts are for your eyes only.
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
