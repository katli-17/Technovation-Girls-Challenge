import RoleOnboarding from "../components/RoleOnboarding";

interface SchoolOnboardingProps {
  onComplete: (data: any) => void;
  onBack: () => void;
  onSignIn: () => void;
}

export default function SchoolOnboarding({ onComplete, onBack, onSignIn }: SchoolOnboardingProps) {
  return (
    <RoleOnboarding 
      role="school"
      onComplete={onComplete}
      onBack={onBack}
      onSignIn={onSignIn}
    />
  );
}
