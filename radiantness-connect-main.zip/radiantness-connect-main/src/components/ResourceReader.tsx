import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ChevronRight, Star, Sparkles, CheckCircle2, ArrowRight } from "lucide-react";
import { cn } from "@/src/lib/utils";

interface Page {
  title: string;
  content: React.ReactNode;
  icon?: React.ReactNode;
}

interface ResourceReaderProps {
  isOpen: boolean;
  onClose: () => void;
  article: {
    title: string;
    pages: Page[];
  };
}

export default function ResourceReader({ isOpen, onClose, article }: ResourceReaderProps) {
  const [currentPage, setCurrentPage] = useState(0);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const handleNext = () => {
    if (currentPage < article.pages.length - 1) {
      setCurrentPage(prev => prev + 1);
    } else {
      setIsFinished(true);
    }
  };

  const handleRatingSubmit = () => {
    // In a real app, save rating to Firestore
    onClose();
    setTimeout(() => {
      setCurrentPage(0);
      setRating(0);
      setIsFinished(false);
    }, 500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/20 backdrop-blur-md z-[100] flex items-end sm:items-center justify-center p-0 sm:p-6"
        >
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="bg-white w-full max-w-lg h-[90vh] sm:h-auto sm:max-h-[85vh] rounded-t-[40px] sm:rounded-[40px] flex flex-col overflow-hidden shadow-2xl"
          >
            {/* Header */}
            <div className="p-6 flex justify-between items-center border-b border-gray-50 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-radiant-pink/10 rounded-full flex items-center justify-center text-radiant-pink">
                  <Sparkles size={16} />
                </div>
                <h2 className="text-sm font-bold uppercase tracking-widest text-gray-400">
                  {article.title}
                </h2>
              </div>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X size={20} className="text-gray-400" />
              </button>
            </div>

            {/* Progress Bar */}
            <div className="h-1 bg-gray-100 flex overflow-hidden">
              <motion.div 
                className="h-full bg-radiant-pink transition-all duration-300"
                style={{ width: `${((currentPage + (isFinished ? 1 : 0)) / (article.pages.length + 1)) * 100}%` }}
              />
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8 sm:p-10 custom-scrollbar">
              <AnimatePresence mode="wait">
                {!isFinished ? (
                  <motion.div
                    key={currentPage}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-8"
                  >
                    <div className="flex flex-col items-center text-center space-y-6">
                      {article.pages[currentPage].icon && (
                        <div className="w-20 h-20 bg-radiant-pink/5 rounded-full flex items-center justify-center text-radiant-pink">
                          {article.pages[currentPage].icon}
                        </div>
                      )}
                      <h3 className="text-3xl font-serif leading-tight">
                        {article.pages[currentPage].title}
                      </h3>
                      <div className="text-gray-600 leading-relaxed space-y-4">
                        {article.pages[currentPage].content}
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="rating"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-10 text-center py-10"
                  >
                    <div className="w-24 h-24 bg-radiant-pink/10 rounded-full flex items-center justify-center mx-auto text-radiant-pink shadow-inner">
                      <CheckCircle2 size={48} />
                    </div>
                    
                    <div className="space-y-3">
                      <h3 className="text-3xl font-serif">You've finished!</h3>
                      <p className="text-gray-500">How did you find this article?</p>
                    </div>

                    <div className="flex justify-center gap-3">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <motion.button
                          key={star}
                          whileHover={{ scale: 1.2, rotate: 5 }}
                          whileTap={{ scale: 0.9 }}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setRating(star)}
                          className={cn(
                            "transition-colors duration-200 p-2",
                            (hoverRating || rating) >= star ? "text-yellow-400" : "text-gray-100"
                          )}
                        >
                          <Star 
                            size={40} 
                            fill={(hoverRating || rating) >= star ? "currentColor" : "none"} 
                            strokeWidth={1.5}
                          />
                        </motion.button>
                      ))}
                    </div>

                    <button
                      onClick={handleRatingSubmit}
                      disabled={!rating}
                      className={cn(
                        "w-full py-5 rounded-full font-bold uppercase tracking-widest text-xs shadow-lg transition-all active:scale-95 disabled:opacity-50",
                        rating ? "bg-radiant-pink text-white shadow-radiant-pink/20" : "bg-gray-100 text-gray-400"
                      )}
                    >
                      Complete & Exit
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Footer Navigation */}
            {!isFinished && (
              <div className="p-8 pt-0 shrink-0">
                <button
                  onClick={handleNext}
                  className="w-full bg-radiant-pink text-white py-5 rounded-full font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 shadow-xl shadow-radiant-pink/20 hover:scale-[1.02] transition-transform active:scale-95"
                >
                  {currentPage === article.pages.length - 1 ? "Finish Article" : "Continue"}
                  <ArrowRight size={16} />
                </button>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
