import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged, User as FirebaseUser, signInAnonymously, deleteUser } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, deleteDoc, collection, query, orderBy, limit, onSnapshot, addDoc, serverTimestamp, Timestamp, terminate, clearIndexedDbPersistence, getDocFromServer } from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

// Connection Test
async function testConnection() {
  try {
    // Attempt to fetch a non-existent document from the server to verify connectivity
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Firestore connection verified.");
  } catch (error: any) {
    if (error.message && error.message.includes('the client is offline')) {
      console.error("Firestore Error: The client is offline. This usually means the Firebase configuration is incorrect or the database is not provisioned.");
    }
  }
}
testConnection();

// Auth Helpers
let isSigningIn = false;
let lastSignInTime = 0;

export const signInWithGoogle = async () => {
  const now = Date.now();
  // Prevent multiple calls within 2 seconds
  if (isSigningIn || (now - lastSignInTime < 2000)) return null;
  
  try {
    isSigningIn = true;
    lastSignInTime = now;
    
    // Small delay to ensure browser state is settled in iframe
    await new Promise(resolve => setTimeout(resolve, 100));
    
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    // Handle common popup errors gracefully
    if (error.code === 'auth/popup-closed-by-user' || error.code === 'auth/cancelled-popup-request') {
      console.log("User closed or cancelled the login popup.");
      return null;
    }
    console.error("Error signing in with Google:", error);
    throw error;
  } finally {
    // Add a small delay before resetting the flag
    setTimeout(() => {
      isSigningIn = false;
    }, 1000);
  }
};

export const signGuestIn = async () => {
  try {
    const result = await signInAnonymously(auth);
    return result.user;
  } catch (error: any) {
    if (error.code === 'auth/admin-restricted-operation') {
      console.error("Firebase Configuration Error: Anonymous Authentication is disabled. Please enable it in the Firebase Console (Authentication > Sign-in method).");
    }
    console.error("Error signing in anonymously:", error);
    throw error;
  }
};

export const logout = async () => {
  localStorage.removeItem("radiant_local_session");
  return auth.signOut();
};

export const deleteAccount = async () => {
  const localSession = localStorage.getItem("radiant_local_session");
  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || (localSession ? JSON.parse(localSession).uid : null);
  
  if (!uid) {
    window.location.reload();
    return;
  }

  try {
    // 1. Delete the user document from Firestore
    await deleteDoc(doc(db, "users", uid));
    
    // 2. Delete private details if they exist
    await deleteDoc(doc(db, "student_private_details", uid));
    
    // 3. Clear local session
    localStorage.removeItem("radiant_local_session");

    // 4. Delete Auth User if real firebase user
    if (currentUser) {
      try {
        await deleteUser(currentUser);
      } catch (authError: any) {
        console.warn("Auth deletion failed (likely needs recent login):", authError.message);
        // Fallback to signs out if account deletion requires re-auth
        await auth.signOut();
      }
    }
    
    // 5. Clear Firestore local cache (IndexedDB)
    await terminate(db);
    await clearIndexedDbPersistence(db);
    
    // 6. Force reload to clear any local React state
    window.location.reload();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `users/${uid}`);
  }
};

// Keep for backward compatibility
export const resetUserData = deleteAccount;

// Firestore Error Handler Spec
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const message = error instanceof Error ? error.message : String(error);
  
  // Silence "Firestore shutting down" errors which happen during reset/delete/logout
  if (message.includes('Firestore shutting down') || message.includes('The client is offline')) {
    console.warn(`Firestore cleaning up (${operationType} on ${path}): ${message}`);
    return;
  }

  const errInfo: FirestoreErrorInfo = {
    error: message,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
