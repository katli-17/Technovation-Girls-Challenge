import { useState } from "react";
import { motion } from "motion/react";
import { Smile, Meh, Frown, Heart, Star, RefreshCw, Eye, Zap, Cloud, Sun, AlertCircle } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { Mood } from "@/src/types";
import { db, auth, handleFirestoreError, OperationType } from "@/src/lib/firebase";
import { collection, addDoc, serverTimestamp, doc, updateDoc, increment, getDoc } from "firebase/firestore";

export default function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const moods: { type: Mood; icon: any; label: string; color: string }[] = [
    { type: "great", icon: "😊", label: "Good", color: "text-yellow-500" },
    { type: "okay", icon: "😐", label: "Meh", color: "text-blue-500" },
    { type: "low", icon: "😔", label: "Low", color: "text-orange-500" },
    { type: "bad", icon: "😫", label: "Overwhelmed", color: "text-red-500" },
  ];

  const handleMoodSelect = async (mood: Mood) => {
    if (!auth.currentUser || isSaving) return;
    
    setSelectedMood(mood);
    setIsSaving(true);

    try {
      const userId = auth.currentUser.uid;
      const moodLog = {
        uid: userId,
        mood: mood,
        timestamp: serverTimestamp(),
      };

      // Save mood log
      await addDoc(collection(db, "users", userId, "moods"), moodLog);

      // Update streak and confidence score
      // For simplicity, we increment streak on every mood log for now
      // In a real app, you'd check if it's a new day
      const userRef = doc(db, "users", userId);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        await updateDoc(userRef, {
          streak: increment(1),
          confidenceScore: increment(2), // Small boost for checking in
          lastCheckIn: serverTimestamp()
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${auth.currentUser.uid}/moods`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-[32px] p-8 shadow-sm border border-black/5">
      <h3 className="text-lg font-medium text-gray-700 mb-6">Be honest... how's your energy today?</h3>
      <div className="grid grid-cols-4 gap-3">
        {moods.map((mood) => (
          <button
            key={mood.type}
            onClick={() => handleMoodSelect(mood.type)}
            disabled={isSaving}
            className={cn(
              "flex flex-col items-center gap-2 p-4 rounded-2xl transition-all duration-300 border border-transparent",
              selectedMood === mood.type 
                ? "bg-radiant-pink/5 border-radiant-pink/20 scale-105" 
                : "bg-gray-50 hover:bg-gray-100",
              isSaving && "cursor-not-allowed opacity-50"
            )}
          >
            <div className="text-4xl mb-1">{mood.icon}</div>
            <span className={cn(
              "text-[10px] font-bold uppercase tracking-widest",
              selectedMood === mood.type ? "text-radiant-pink" : "text-gray-400"
            )}>
              {mood.label}
            </span>
          </button>
        ))}
      </div>
      
      {selectedMood && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 space-y-4"
        >
          <div className="p-4 bg-radiant-bg rounded-2xl text-sm italic text-center text-radiant-pink">
            "It's okay to feel {selectedMood}. Remember, every emotion is a step toward self-awareness."
          </div>

          {selectedMood === "low" && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-6 bg-white border border-radiant-pink/10 rounded-[24px] shadow-xl shadow-radiant-pink/5"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-radiant-pink/10 flex items-center justify-center text-radiant-pink">
                  <Heart size={16} className="fill-radiant-pink" />
                </div>
                <h4 className="font-serif text-lg text-gray-800">Extra Love for You</h4>
              </div>
              
              <p className="text-sm text-gray-500 mb-6 leading-relaxed">
                When things feel heavy, a small moment of peace can make a world of difference. Try this tiny reset:
              </p>

              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                      <RefreshCw size={12} />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-700">Box Breathing</span>
                  </div>
                  <p className="text-xs text-gray-500 leading-relaxed mb-3">
                    A powerful tool to reset your nervous system. Follow this pattern:
                  </p>
                  <div className="grid grid-cols-4 gap-2 text-center">
                    <div className="p-2 bg-white rounded-xl border border-black/5">
                      <p className="text-[8px] font-bold uppercase text-gray-400">Inhale</p>
                      <p className="font-serif text-blue-500">4s</p>
                    </div>
                    <div className="p-2 bg-white rounded-xl border border-black/5">
                      <p className="text-[8px] font-bold uppercase text-gray-400">Hold</p>
                      <p className="font-serif text-blue-500">4s</p>
                    </div>
                    <div className="p-2 bg-white rounded-xl border border-black/5">
                      <p className="text-[8px] font-bold uppercase text-gray-400">Exhale</p>
                      <p className="font-serif text-blue-500">4s</p>
                    </div>
                    <div className="p-2 bg-white rounded-xl border border-black/5">
                      <p className="text-[8px] font-bold uppercase text-gray-400">Rest</p>
                      <p className="font-serif text-blue-500">4s</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-lg bg-green-500/10 text-green-500 flex items-center justify-center">
                      <Star size={12} />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-700">Gentle Movement</span>
                  </div>
                  <p className="text-xs text-gray-500 leading-relaxed">
                    Simply rolling your shoulders or taking 5 slow steps can help shift your energy. You've got this.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {selectedMood === "bad" && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-6 bg-white border border-red-100 rounded-[24px] shadow-xl shadow-red-500/5"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-red-50 flex items-center justify-center text-red-500">
                  <AlertCircle size={16} />
                </div>
                <h4 className="font-serif text-lg text-gray-800">You're not alone</h4>
              </div>
              
              <p className="text-sm text-gray-500 mb-6 leading-relaxed">
                Feeling overwhelmed is your brain's way of saying it needs a break. Let's come back to the present moment:
              </p>

              <div className="p-4 bg-red-50/50 rounded-2xl border border-red-100">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-6 h-6 rounded-lg bg-red-500/10 text-red-500 flex items-center justify-center">
                    <Eye size={12} />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-red-700">5-4-3-2-1 Grounding</span>
                </div>
                <div className="space-y-2">
                  <p className="text-xs text-gray-600"><span className="font-bold text-red-500">5</span> things you can <span className="font-bold">see</span></p>
                  <p className="text-xs text-gray-600"><span className="font-bold text-red-500">4</span> things you can <span className="font-bold">touch</span></p>
                  <p className="text-xs text-gray-600"><span className="font-bold text-red-500">3</span> things you can <span className="font-bold">hear</span></p>
                  <p className="text-xs text-gray-600"><span className="font-bold text-red-500">2</span> things you can <span className="font-bold">smell</span></p>
                  <p className="text-xs text-gray-600"><span className="font-bold text-red-500">1</span> thing you can <span className="font-bold">taste</span></p>
                </div>
              </div>
            </motion.div>
          )}

          {selectedMood === "great" && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-6 bg-white border border-yellow-100 rounded-[24px] shadow-xl shadow-yellow-500/5"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-yellow-50 flex items-center justify-center text-yellow-500">
                  <Sun size={16} />
                </div>
                <h4 className="font-serif text-lg text-gray-800">Keep that Energy!</h4>
              </div>
              
              <p className="text-sm text-gray-500 mb-4 leading-relaxed">
                Your positive energy is your superpower! 🌟 Take a second to lock it in:
              </p>

              <div className="p-4 bg-yellow-50/50 rounded-2xl border border-yellow-100">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-lg bg-yellow-500/10 text-yellow-500 flex items-center justify-center">
                    <Zap size={12} />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-yellow-700">Power Pose</span>
                </div>
                <p className="text-xs text-gray-600">
                  Stand tall, stretch your arms wide, and take one deep breath. You are capable of amazing things!
                </p>
              </div>
            </motion.div>
          )}

          {selectedMood === "okay" && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-6 bg-white border border-blue-100 rounded-[24px] shadow-xl shadow-blue-500/5"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center text-blue-500">
                  <Cloud size={16} />
                </div>
                <h4 className="font-serif text-lg text-gray-800">Quiet & Calm</h4>
              </div>
              
              <p className="text-sm text-gray-500 mb-4 leading-relaxed">
                A steady day is a productive day. ☁️ Keep your momentum going with a small reset:
              </p>

              <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                    <RefreshCw size={12} />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-blue-700">Hydration Break</span>
                </div>
                <p className="text-xs text-gray-600">
                  Take a slow sip of water. Notice how it feels. This tiny act of self-care keeps your mind sharp.
                </p>
              </div>
            </motion.div>
          )}
        </motion.div>
      )}
    </div>
  );
}
