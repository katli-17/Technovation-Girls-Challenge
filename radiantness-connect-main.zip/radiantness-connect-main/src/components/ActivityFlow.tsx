import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, X, ChevronRight, Heart, Wind, PenLine, CheckCircle2, HeartHandshake } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { GoogleGenAI } from "@google/genai";

interface ActivityFlowProps {
  onboardingData: any;
  onClose: () => void;
}

type ActivityType = "confidence" | "self_esteem" | "stress" | "support" | "default";

interface Step {
  title: string;
  content: React.ReactNode;
  buttonText?: string;
  showInput?: boolean;
}

export default function ActivityFlow({ onboardingData, onClose }: ActivityFlowProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [userInput, setUserInput] = useState("");
  const [checkInInput, setCheckInInput] = useState("");
  const [aiComment, setAiComment] = useState("");
  const [isReviewing, setIsReviewing] = useState(false);
  const [activityType, setActivityType] = useState<ActivityType>("default");

  useEffect(() => {
    const answers = onboardingData?.answers || {};
    
    // Logic to determine activity based on onboarding answers
    if (answers.confidence === "low" || answers.confidence === "medium") {
      setActivityType("confidence");
    } else if (answers.self_image === "comparison" || answers.self_image === "invisible") {
      setActivityType("self_esteem");
    } else if (answers.stress === "daily" || answers.stress === "weekly") {
      setActivityType("stress");
    } else if (answers.community_support === "no" || answers.community_support === "unsure") {
      setActivityType("support");
    } else {
      setActivityType("default");
    }
  }, [onboardingData]);

  const handleCheckInSubmit = async () => {
    if (!checkInInput.trim()) return;
    setIsReviewing(true);
    try {
      if (!process.env.GEMINI_API_KEY) {
        console.warn("GEMINI_API_KEY is missing. Using fallback response.");
        setAiComment("Thank you for sharing that with me. Your feelings are valid and important. 🤍");
        setCurrentStep(1);
        return;
      }
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `You are a supportive AI companion for a student dashboard called RadiantNess. 
        The student is doing a ${activityType} activity and just shared this thought: "${checkInInput}". 
        Provide a very short (1-2 sentences), warm, and supportive comment reviewing their input. 
        Be encouraging and empathetic. Do not give advice, just validate and support. 
        Keep it soft and kind.`,
      });
      
      setAiComment(response.text || "Thank you for sharing that with me. Your feelings are valid and important. 🤍");
      setCurrentStep(1); // Move to the comment step
    } catch (error) {
      console.error("Review error:", error);
      setAiComment("Thank you for sharing that with me. Your feelings are valid and important. 🤍");
      setCurrentStep(1);
    } finally {
      setIsReviewing(false);
    }
  };

  const getSteps = (): Step[] => {
    const checkInStep: Step = {
      title: "Quick Check-in 🌸",
      content: (
        <div className="space-y-6 w-full">
          <p className="text-lg text-gray-600 text-center">
            {activityType === "confidence" ? "What's one thing you're proud of today?" :
             activityType === "self_esteem" ? "How are you feeling about yourself in this moment?" :
             activityType === "stress" ? "What's the biggest thing on your mind right now?" :
             activityType === "support" ? "What's one thing you wish someone would say to you right now?" :
             "How are you feeling right now?"}
          </p>
          <textarea 
            value={checkInInput}
            onChange={(e) => setCheckInInput(e.target.value)}
            placeholder="Type your thoughts here..."
            className="w-full h-32 p-4 rounded-2xl border border-gray-100 focus:border-radiant-pink focus:ring-2 focus:ring-radiant-pink/5 outline-none transition-all resize-none"
          />
        </div>
      ),
      buttonText: isReviewing ? "Reviewing..." : "Share with me",
      showInput: true
    };

    const commentStep: Step = {
      title: "A thought for you...",
      content: (
        <div className="space-y-6 text-center">
          <div className="p-8 bg-radiant-pink/5 rounded-[32px] border border-radiant-pink/10 shadow-inner">
            <p className="text-xl font-serif text-radiant-pink italic leading-relaxed">
              "{aiComment}"
            </p>
          </div>
          <p className="text-sm text-gray-400 italic">Ready to continue with your activity?</p>
        </div>
      ),
      buttonText: "Let's begin"
    };

    let activitySteps: Step[] = [];
    switch (activityType) {
      case "confidence":
        activitySteps = [
          {
            title: "Mirror Magic ✨",
            content: (
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-radiant-pink/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="text-radiant-pink" size={40} />
                </div>
                <p className="text-lg text-gray-600">Find a mirror or use your front camera. Look yourself in the eyes.</p>
              </div>
            ),
            buttonText: "I'm looking"
          },
          {
            title: "Repeat after me...",
            content: (
              <div className="space-y-6">
                <div className="p-6 bg-radiant-pink/5 rounded-3xl border border-radiant-pink/10 text-center">
                  <p className="text-2xl font-serif text-radiant-pink italic">"I am capable, I am strong, and I am enough exactly as I am."</p>
                </div>
                <p className="text-sm text-gray-500 text-center">Say it out loud. Feel the words in your heart.</p>
              </div>
            ),
            buttonText: "I said it"
          },
          {
            title: "One more time",
            content: (
              <div className="space-y-6">
                <div className="p-6 bg-radiant-pink/5 rounded-3xl border border-radiant-pink/10 text-center">
                  <p className="text-2xl font-serif text-radiant-pink italic">"My voice matters, and I deserve to be heard."</p>
                </div>
                <p className="text-sm text-gray-500 text-center">Believe it. You are radiant.</p>
              </div>
            ),
            buttonText: "Done"
          }
        ];
        break;
      case "self_esteem":
        activitySteps = [
          {
            title: "Letter to Little You 💌",
            content: (
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-radiant-pink/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="text-radiant-pink" size={40} />
                </div>
                <p className="text-lg text-gray-600">Think back to when you were 7 years old. What would you tell her today?</p>
              </div>
            ),
            buttonText: "I'm thinking"
          },
          {
            title: "3 Kind Sentences",
            content: (
              <div className="space-y-4">
                <p className="text-sm text-gray-500">Write 3 kind things to your younger self:</p>
                <textarea 
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  placeholder="Example: You are so brave for trying new things..."
                  className="w-full h-32 p-4 rounded-2xl border border-gray-100 focus:border-radiant-pink focus:ring-2 focus:ring-radiant-pink/5 outline-none transition-all resize-none"
                />
              </div>
            ),
            showInput: true,
            buttonText: "Send Love"
          }
        ];
        break;
      case "stress":
        activitySteps = [
          {
            title: "Breathe with me 🌬️",
            content: (
              <div className="text-center space-y-8">
                <motion.div 
                  animate={{ scale: [1, 1.5, 1] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="w-32 h-32 bg-radiant-pink/20 rounded-full flex items-center justify-center mx-auto"
                >
                  <Wind className="text-radiant-pink" size={48} />
                </motion.div>
                <div className="space-y-2">
                  <p className="text-xl font-serif italic text-radiant-pink">Inhale... Exhale...</p>
                  <p className="text-sm text-gray-500">Follow the circle. Let the tension melt away.</p>
                </div>
              </div>
            ),
            buttonText: "I feel calmer"
          }
        ];
        break;
      case "support":
        activitySteps = [
          {
            title: "You're Not Alone 🫂",
            content: (
              <div className="text-center space-y-6">
                <div className="w-24 h-24 bg-radiant-pink/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <HeartHandshake className="text-radiant-pink" size={40} />
                </div>
                <div className="space-y-4">
                  <p className="text-lg text-gray-700 font-medium">"It's okay to ask for help. It's a sign of strength, not weakness."</p>
                  <p className="text-sm text-gray-500 leading-relaxed">RadiantNess is a community built for you. There are people here who care and want to see you thrive.</p>
                </div>
              </div>
            ),
            buttonText: "I understand"
          },
          {
            title: "A Gentle Reminder",
            content: (
              <div className="p-8 bg-radiant-pink/5 rounded-[32px] border border-radiant-pink/10 text-center space-y-4">
                <p className="text-xl font-serif text-radiant-pink italic">"You are worthy of support, love, and care. You don't have to carry everything by yourself."</p>
              </div>
            ),
            buttonText: "Thank you"
          }
        ];
        break;
      default:
        activitySteps = [
          {
            title: "Daily Glow-Up ✨",
            content: (
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-radiant-pink/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="text-radiant-pink" size={40} />
                </div>
                <p className="text-lg text-gray-600">Take a moment to appreciate one thing you did well today.</p>
              </div>
            ),
            buttonText: "I've got it"
          }
        ];
        break;
    }
    return [checkInStep, commentStep, ...activitySteps];
  };

  const steps = getSteps();
  const isLastStep = currentStep === steps.length;

  return (
    <div className="fixed inset-0 bg-white z-[100] flex flex-col">
      {/* Header */}
      <div className="p-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-radiant-pink/10 rounded-lg flex items-center justify-center">
            <Sparkles className="text-radiant-pink" size={18} />
          </div>
          <span className="font-bold tracking-tight text-gray-900">Activity</span>
        </div>
        <button 
          onClick={onClose}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X size={24} className="text-gray-400" />
        </button>
      </div>

      {/* Progress Bar */}
      <div className="px-6 mb-8">
        <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${((currentStep + 1) / (steps.length + 1)) * 100}%` }}
            className="h-full bg-radiant-pink"
          />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 flex flex-col justify-center max-w-md mx-auto w-full">
        <AnimatePresence mode="wait">
          {!isLastStep ? (
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <h2 className="text-3xl font-serif text-center">{steps[currentStep].title}</h2>
              <div className="min-h-[200px] flex items-center justify-center">
                {steps[currentStep].content}
              </div>
              
              <button
                onClick={() => {
                  if (currentStep === 0) {
                    handleCheckInSubmit();
                  } else {
                    setCurrentStep(prev => prev + 1);
                  }
                }}
                disabled={currentStep === 0 && (!checkInInput.trim() || isReviewing)}
                className="w-full bg-radiant-pink text-white py-4 rounded-full font-bold uppercase tracking-widest text-xs shadow-lg shadow-radiant-pink/20 hover:bg-radiant-pink/90 transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {steps[currentStep].buttonText || "Continue"} <ChevronRight size={16} />
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="finish"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-8"
            >
              <div className="w-32 h-32 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-8">
                <CheckCircle2 className="text-green-500" size={64} />
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-serif">Activity Complete!</h2>
                <p className="text-xl font-serif text-radiant-pink italic">I'm proud of you 🤍</p>
              </div>
              <p className="text-gray-500">You've taken a beautiful step for yourself today.</p>
              
              <button
                onClick={onClose}
                className="w-full bg-gray-900 text-white py-4 rounded-full font-bold uppercase tracking-widest text-xs shadow-lg hover:bg-gray-800 transition-all active:scale-95"
              >
                Back to Dashboard
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Background Decoration */}
      <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-20 w-64 h-64 bg-radiant-pink/5 blur-[100px] rounded-full" />
        <div className="absolute bottom-1/4 -right-20 w-64 h-64 bg-radiant-accent/10 blur-[100px] rounded-full" />
      </div>
    </div>
  );
}

