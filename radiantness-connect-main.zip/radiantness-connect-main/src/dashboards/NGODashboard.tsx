import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Package, Plus, Clock, CheckCircle, AlertCircle, TrendingUp, Users, MapPin, School, User, RefreshCw, LogOut, Truck, Settings, Search, Filter, ChevronDown, GraduationCap, MessageCircle, Shield } from "lucide-react";
import { db, auth, handleFirestoreError, OperationType, resetUserData, logout } from "../lib/firebase";
import { collection, addDoc, query, onSnapshot, serverTimestamp, orderBy, updateDoc, doc, limit, Timestamp, where } from "firebase/firestore";
import { cn } from "../lib/utils";

type RequestStatus = "pending" | "approved" | "in-progress" | "shipped" | "delivered";

export default function NGODashboard({ user }: { user: any }) {
  const [activeTab, setActiveTab] = useState<"analytics" | "requests" | "donations" | "settings" | "schools">("analytics");
  const [requests, setRequests] = useState<any[]>([]);
  const [schools, setSchools] = useState<any[]>([]);
  const [displayRequests, setDisplayRequests] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [donations, setDonations] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [activeRequestTab, setActiveRequestTab] = useState<RequestStatus>("pending");
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  
  // Settings State
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [editProfile, setEditProfile] = useState({
    displayName: "",
    ngo_location: { city: "", country: "", address: "" }
  });

  // Rejection Modal State
  const [showRejectionModal, setShowRejectionModal] = useState(false);
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [rejectionStep, setRejectionStep] = useState<"reason" | "confirm">("reason");

  // Info Modal State
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  
  // Donation Modal State
  const [donationStep, setDonationStep] = useState(1);
  const [newDonation, setNewDonation] = useState({
    donorType: "school" as "school" | "individual",
    schoolName: "",
    productType: "Pads",
    amount: 100,
    brand: "",
    urgency: "within this month" as "within a week" | "within this month" | "within the next 2 months"
  });

  useEffect(() => {
    if (!auth.currentUser) return;

    // Fetch NGO Profile
    const unsubscribeProfile = onSnapshot(doc(db, "users", auth.currentUser.uid), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setProfile(data);
        setEditProfile({
          displayName: data.displayName || "",
          ngo_location: data.onboardingData?.ngo_location || { city: "", country: "", address: "" }
        });
      }
    });

    // Listen for all requests
    const qRequests = query(
      collection(db, "requests"),
      orderBy("timestamp", "desc"),
      limit(50)
    );

    const unsubscribeRequests = onSnapshot(qRequests, { includeMetadataChanges: true }, (snapshot) => {
      setRequests(prev => {
        const next = [...prev];
        snapshot.docChanges().forEach(change => {
          const data = { id: change.doc.id, ...change.doc.data() };
          if (change.type === 'added') {
            if (!next.find(r => r.id === data.id)) next.push(data);
          } else if (change.type === 'modified') {
            const index = next.findIndex(r => r.id === data.id);
            if (index !== -1) next[index] = data;
          } else if (change.type === 'removed') {
            const index = next.findIndex(r => r.id === data.id);
            if (index !== -1) next.splice(index, 1);
          }
        });
        return next.sort((a, b) => {
          const tA = (a.timestamp as Timestamp)?.toMillis() || 0;
          const tB = (b.timestamp as Timestamp)?.toMillis() || 0;
          return tB - tA;
        });
      });
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "requests");
    });

    // Listen for NGO's own donations
    const qDonations = query(
      collection(db, "donations"),
      orderBy("timestamp", "desc"),
      limit(50)
    );
    const unsubscribeDonations = onSnapshot(qDonations, (snapshot) => {
      setDonations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "donations");
    });

    // Fetch all schools for browsing
    const qSchools = query(
      collection(db, "users"),
      where("userRole", "==", "school")
    );
    const unsubscribeSchools = onSnapshot(qSchools, (snapshot) => {
      setSchools(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, "users/schools");
    });

    return () => {
      unsubscribeProfile();
      unsubscribeRequests();
      unsubscribeDonations();
      unsubscribeSchools();
    };
  }, []);

  // Sticky filtering to prevent flickering when status updates
  useEffect(() => {
    setDisplayRequests(prev => {
      // 1. Update existing items in the display list with latest data from Firestore
      const updatedPrev = prev.map(p => {
        const latest = requests.find(r => r.id === p.id);
        return latest || p;
      });

      // 2. Add new items that match the current tab and aren't already displayed
      const currentTabItems = requests.filter(r => r.status === activeRequestTab);
      const newItems = currentTabItems.filter(r => !prev.find(p => p.id === r.id));
      
      // 3. Combine and sort
      return [...updatedPrev, ...newItems].sort((a, b) => {
        const tA = (a.timestamp as Timestamp)?.toMillis() || 0;
        const tB = (b.timestamp as Timestamp)?.toMillis() || 0;
        return tB - tA;
      });
    });
  }, [requests, activeRequestTab]);

  // When tab changes, we reset the display list to only items matching the new tab
  useEffect(() => {
    setDisplayRequests(requests.filter(r => r.status === activeRequestTab));
  }, [activeRequestTab]);

  const handleUpdateStatus = async (requestId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, "requests", requestId), { 
        status: newStatus,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `requests/${requestId}`);
    }
  };

  const handleRejectRequest = async () => {
    if (!selectedRequestId) return;
    try {
      await updateDoc(doc(db, "requests", selectedRequestId), { 
        status: "rejected",
        rejectionReason: rejectionReason
      });
      setShowRejectionModal(false);
      setSelectedRequestId(null);
      setRejectionReason("");
      setRejectionStep("reason");
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `requests/${selectedRequestId}`);
    }
  };

  const handleShipDonation = async (donationId: string) => {
    try {
      await updateDoc(doc(db, "donations", donationId), { status: "shipped" });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `donations/${donationId}`);
    }
  };

  const handleSubmitDonation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    try {
      await addDoc(collection(db, "donations"), {
        donorUid: auth.currentUser.uid,
        donorType: newDonation.donorType,
        schoolName: newDonation.donorType === "school" ? newDonation.schoolName : null,
        productType: newDonation.productType,
        amount: newDonation.amount,
        brand: newDonation.brand || null,
        urgency: newDonation.donorType === "school" ? newDonation.urgency : null,
        status: "approved", // Starts as approved/outstanding
        timestamp: serverTimestamp(),
      });
      setShowDonationModal(false);
      setDonationStep(1);
      setNewDonation({
        donorType: "school",
        schoolName: "",
        productType: "Pads",
        amount: 100,
        brand: "",
        urgency: "within this month"
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "donations");
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    setIsSavingProfile(true);
    setSaveSuccess(false);
    try {
      await updateDoc(doc(db, "users", auth.currentUser.uid), {
        displayName: editProfile.displayName,
        "onboardingData.ngo_location": editProfile.ngo_location
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${auth.currentUser.uid}`);
    } finally {
      setIsSavingProfile(false);
    }
  };

  const requestsPending = requests.filter(r => r.status === "pending").length;
  const requestsApproved = requests.filter(r => r.status === "approved" || r.status === "in-progress" || r.status === "shipped").length;
  const requestsDelivered = requests.filter(r => r.status === "delivered").length;
  const totalRequests = requests.length;
  const successRate = totalRequests > 0 ? Math.round(((requestsApproved + requestsDelivered) / totalRequests) * 100) : 0;

  return (
    <div className="space-y-8">
      {profile && profile.isVerified === true && (
        <div className="bg-green-50 border border-green-100 p-4 rounded-3xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-green-500 shadow-sm">
            <CheckCircle size={20} />
          </div>
          <div>
            <p className="text-sm font-serif text-green-950">Your NGO is approved! You can now browse school requests and donate.</p>
            <p className="text-[10px] text-green-700/70 font-bold uppercase tracking-widest">Platform Access Granted</p>
          </div>
        </div>
      )}

      {profile && profile.isVerified !== true && (
        <div className="bg-orange-50 border border-orange-100 p-4 rounded-3xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-orange-500 shadow-sm">
            <Shield size={20} />
          </div>
          <div>
            <p className="text-sm font-serif text-orange-950">Your NGO profile is pending admin approval.</p>
            <p className="text-[10px] text-orange-700/70 font-bold uppercase tracking-widest">Donation features unlock after approval.</p>
          </div>
        </div>
      )}

      <div className="flex justify-end gap-3 -mb-4">
        <button 
          onClick={() => setShowResetConfirm(true)}
          className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-red-500 transition-colors"
        >
          <RefreshCw size={12} />
          Reset Profile
        </button>
        <button 
          onClick={() => logout()}
          className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-radiant-pink transition-colors"
        >
          <LogOut size={12} />
          Sign Out
        </button>
      </div>

      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-serif">
            {profile?.displayName || "NGO Dashboard"}
          </h1>
          <p className="text-gray-500 text-sm italic">
            {profile?.onboardingData?.donation_specialization === 'other' 
              ? profile?.onboardingData?.other_specialization?.other_spec 
              : profile?.onboardingData?.donation_specialization || "Empowering youth through support."}
          </p>
        </div>
        <div className="flex bg-white rounded-full p-1 border border-black/5 shadow-sm overflow-x-auto scrollbar-hide">
          <button 
            onClick={() => setActiveTab("requests")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeTab === "requests" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <Clock size={14} />
            Requests
          </button>
          <button 
            onClick={() => setActiveTab("schools")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeTab === "schools" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <School size={14} />
            Schools
          </button>
          <button 
            onClick={() => setActiveTab("analytics")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeTab === "analytics" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <TrendingUp size={14} />
            Analytics
          </button>
          <button 
            onClick={() => setActiveTab("donations")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeTab === "donations" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <Package size={14} />
            Donations
          </button>
          <button 
            onClick={() => setActiveTab("settings")}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap",
              activeTab === "settings" ? "bg-radiant-pink text-white shadow-md" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <Settings size={14} />
            Settings
          </button>
        </div>
        </header>

        {activeTab === "analytics" ? (
          <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Editorial Header */}
            <div className="space-y-2">
              <h2 className="text-4xl font-serif font-bold tracking-tight">Donor Dashboard</h2>
              <p className="text-gray-500 italic">
                Welcome back, {profile?.displayName?.split(' ')[0] || "tz"}! Here's your impact overview.
              </p>
            </div>

            {/* Stat Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              <button 
                onClick={() => setActiveTab("schools")}
                className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm text-left group hover:border-radiant-pink/30 hover:shadow-xl transition-all duration-500"
              >
                <div className="w-12 h-12 bg-radiant-bg rounded-2xl flex items-center justify-center text-radiant-pink mb-4 transition-transform group-hover:scale-110">
                  <Search size={24} />
                </div>
                <p className="text-lg font-serif mb-1 italic">Browse Schools</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Find schools</p>
              </button>

              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="w-12 h-12 bg-orange-50 rounded-2xl flex items-center justify-center text-orange-500 mb-4">
                  <Clock size={24} />
                </div>
                <p className="text-3xl font-serif mb-1">{requestsPending}</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Pending Requests</p>
              </div>

              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-500 mb-4">
                  <Package size={24} />
                </div>
                <p className="text-3xl font-serif mb-1">{requestsApproved}</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Approved</p>
              </div>

              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-500 mb-4">
                  <CheckCircle size={24} />
                </div>
                <p className="text-3xl font-serif mb-1">{requestsDelivered}</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Delivered</p>
              </div>

              <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm">
                <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-600 mb-4">
                  <TrendingUp size={24} />
                </div>
                <p className="text-3xl font-serif mb-1">{successRate}%</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Success Rate</p>
              </div>
            </div>

            {/* Recent Donations */}
            <div className="space-y-6">
              <h3 className="text-xl font-serif mb-4">Recent Donations</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {donations.slice(0, 4).map((donation) => (
                  <div key={donation.id} className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm flex gap-6 group hover:shadow-lg transition-all">
                    <div className="w-16 h-16 bg-radiant-bg rounded-[20px] shrink-0 flex items-center justify-center text-radiant-pink transition-transform group-hover:rotate-6">
                      <Package size={28} />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-serif text-lg italic">{donation.amount} {donation.productType}</h4>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-green-500 bg-green-50 px-3 py-1 rounded-full">
                          {donation.status === 'shipped' || donation.status === 'delivered' ? 'Delivered' : 'Pending'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 mb-6">
                        To {donation.schoolName || "Requesting School"} • {donation.timestamp?.toDate().toISOString().split('T')[0] || "2026-03-28"}
                      </p>
                      <div className="space-y-1">
                        <button className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-radiant-pink hover:text-radiant-pink/80 transition-colors">
                          <MessageCircle size={14} />
                          Contact School
                        </button>
                        <p className="text-[10px] text-gray-400 font-medium">
                          {donation.schoolName || "Requesting School"}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
                {donations.length === 0 && (
                  <div className="col-span-full py-12 text-center bg-gray-50 rounded-[32px] border border-dashed border-gray-200">
                    <p className="text-gray-400 italic">No donations logged yet.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : activeTab === "schools" ? (
        <section className="animate-in fade-in slide-in-from-bottom-4 duration-700 space-y-8">
          <header className="space-y-2">
            <h2 className="text-4xl font-serif font-bold tracking-tight">Registered Schools</h2>
            <p className="text-gray-500 italic">Browse all schools registered with our platform and see their impact potential.</p>
          </header>

          <div className="relative flex-1 group max-w-xl">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-radiant-pink transition-colors" size={18} />
            <input 
              type="text"
              placeholder="Search by school name or city..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-2xl border border-black/5 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 transition-all text-sm"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {schools.filter(school => 
              (school.displayName || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
              (school.onboardingData?.school_basic?.city || "").toLowerCase().includes(searchQuery.toLowerCase())
            ).map((school) => (
              <div key={school.id} className="bg-white rounded-[32px] border border-black/5 shadow-sm hover:shadow-xl transition-all duration-500 overflow-hidden flex flex-col group">
                <div className="relative aspect-video overflow-hidden">
                  <img 
                    src={school.avatarBase64 || `https://picsum.photos/seed/${school.id}/600/400`}
                    alt={school.displayName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute top-4 left-4">
                     <span className={cn(
                       "text-[9px] font-bold uppercase tracking-widest px-3 py-1 rounded-full shadow-lg flex items-center gap-1",
                       school.isVerified !== false ? "bg-green-500 text-white" : "bg-orange-500 text-white"
                     )}>
                        {school.isVerified !== false ? <CheckCircle size={10} /> : <AlertCircle size={10} />}
                        {school.isVerified !== false ? "Verified" : "Pending"}
                     </span>
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col">
                  <div className="mb-4">
                    <h4 className="text-xl font-serif font-bold text-gray-900 group-hover:text-radiant-pink transition-colors leading-tight mb-2">
                      {school.displayName || "Radiant School"}
                    </h4>
                    <div className="space-y-1">
                      <p className="text-[10px] text-gray-500 flex items-center gap-1 font-medium uppercase tracking-wider">
                        <MapPin size={12} className="text-radiant-pink shrink-0" />
                        {school.onboardingData?.school_basic?.city || "Unknown City"}, {school.onboardingData?.school_basic?.country || "Region"}
                      </p>
                      <p className="text-[10px] text-gray-500 flex items-center gap-1 font-medium uppercase tracking-wider">
                        <Users size={12} className="text-radiant-pink shrink-0" />
                        {school.onboardingData?.student_count?.totalStudents || "0"} Students Reached
                      </p>
                    </div>
                  </div>

                  <div className="bg-radiant-bg/50 rounded-2xl p-4 space-y-3 mb-6">
                    <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-gray-400 mb-2">Student Needs Stats</p>
                    <div className="grid grid-cols-1 gap-2">
                      <div className="flex justify-between items-center bg-white/50 p-2 rounded-xl border border-black/5">
                        <span className="text-[10px] font-medium text-gray-600">Sanitary Pads</span>
                        <span className="text-xs font-bold text-radiant-pink">{school.onboardingData?.student_need?.lackSanitary || "0"} missing</span>
                      </div>
                      <div className="flex justify-between items-center bg-white/50 p-2 rounded-xl border border-black/5">
                        <span className="text-[10px] font-medium text-gray-600">Textbooks</span>
                        <span className="text-xs font-bold text-blue-500">{school.onboardingData?.student_need?.lackStationery || "0"} missing</span>
                      </div>
                      <div className="flex justify-between items-center bg-white/50 p-2 rounded-xl border border-black/5">
                        <span className="text-[10px] font-medium text-gray-600">Uniforms</span>
                        <span className="text-xs font-bold text-purple-500">{school.onboardingData?.student_need?.lackUniform || "0"} missing</span>
                      </div>
                    </div>
                  </div>

                  <button 
                    disabled={school.isVerified === false}
                    onClick={() => {
                      setActiveTab("donations");
                      setNewDonation(prev => ({ ...prev, schoolName: school.displayName, donorType: "school" }));
                      setShowDonationModal(true);
                      setDonationStep(2);
                    }}
                    className={cn(
                      "w-full py-4 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg transition-all flex items-center justify-center gap-2",
                      school.isVerified === false ? "bg-gray-100 text-gray-400 cursor-not-allowed" : "bg-radiant-pink text-white shadow-radiant-pink/20 hover:scale-[1.02] active:scale-95"
                    )}
                  >
                    {school.isVerified === false ? "Awaiting Verification" : "Support School"}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {schools.length === 0 && (
            <div className="py-20 text-center">
              <div className="w-20 h-20 bg-radiant-bg rounded-full flex items-center justify-center text-radiant-pink mx-auto mb-6">
                <School size={40} />
              </div>
              <h3 className="text-2xl font-serif mb-2">No schools found</h3>
              <p className="text-gray-500">Wait for schools to join the network.</p>
            </div>
          )}
        </section>
      ) : activeTab === "requests" ? (
        <section className="animate-in fade-in slide-in-from-bottom-4 duration-700 space-y-8">
          {/* Stats Banner */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             <div className="bg-white/50 backdrop-blur-sm p-4 rounded-3xl border border-black/5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-radiant-pink/10 text-radiant-pink flex items-center justify-center">
                   <Clock size={20} />
                </div>
                <div>
                   <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Pending</p>
                   <p className="text-xl font-serif">{requestsPending} Requests</p>
                </div>
             </div>
             <div className="bg-white/50 backdrop-blur-sm p-4 rounded-3xl border border-black/5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-green-50 text-green-500 flex items-center justify-center">
                   <CheckCircle size={20} />
                </div>
                <div>
                   <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Impact</p>
                   <p className="text-xl font-serif">{requestsDelivered} Delivered</p>
                </div>
             </div>
             <div className="bg-white/50 backdrop-blur-sm p-4 rounded-3xl border border-black/5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-500 flex items-center justify-center">
                   <TrendingUp size={20} />
                </div>
                <div>
                   <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Success Rate</p>
                   <p className="text-xl font-serif">{successRate}% Fulfillment</p>
                </div>
             </div>
          </div>

          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 items-center">
             <div className="relative flex-1 group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-radiant-pink transition-colors" size={18} />
                <input 
                  type="text"
                  placeholder="Search schools or locations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 rounded-2xl border border-black/5 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 transition-all text-sm"
                />
             </div>
             <div className="relative min-w-[200px]">
                <select 
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full appearance-none pl-4 pr-10 py-4 rounded-2xl border border-black/5 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 transition-all text-sm font-medium"
                >
                  <option>All Categories</option>
                  <option>Sanitary Pads</option>
                  <option>Stationery</option>
                  <option>Hygiene Kits</option>
                  <option>School Uniforms</option>
                </select>
                <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
             </div>
          </div>

          <div className="flex items-center justify-between">
            <h3 className="text-xl font-serif">Support Local Schools</h3>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {["pending", "approved", "in-progress", "shipped", "delivered"].map((status) => (
                <button
                  key={status}
                  onClick={() => setActiveRequestTab(status as any)}
                  className={cn(
                    "text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full border transition-all whitespace-nowrap",
                    activeRequestTab === status ? "bg-radiant-pink text-white border-radiant-pink" : "bg-white text-gray-400 border-black/5"
                  )}
                >
                  {status.replace("-", " ")} ({requests.filter(r => r.status === status).length})
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Group requests by school for the cards */}
            {(() => {
              const verifiedSchoolIds = new Set(schools.filter(s => s.isVerified !== false).map(s => s.id));
              
              const filtered = displayRequests.filter(r => {
                // Only show verified schools
                if (!verifiedSchoolIds.has(r.requesterUid)) return false;
                
                const matchesSearch = (r.schoolName || "").toLowerCase().includes(searchQuery.toLowerCase()) || 
                                    (r.location?.city || "").toLowerCase().includes(searchQuery.toLowerCase());
                const matchesCategory = selectedCategory === "All Categories" || r.productType === selectedCategory;
                return matchesSearch && matchesCategory;
              });

              // Group by requesterUid to show unique schools with multiple needs
              const groupedSchools = filtered.reduce((acc: any, curr: any) => {
                const uid = curr.requesterUid;
                if (!acc[uid]) {
                  const fallbackName = `School (ID: ${uid.substring(0, 5)})`;
                  acc[uid] = {
                    uid,
                    schoolName: curr.schoolName || fallbackName,
                    location: curr.location,
                    requests: []
                  };
                }
                acc[uid].requests.push(curr);
                return acc;
              }, {});

              return Object.values(groupedSchools).map((schoolGroup: any) => {
                const schoolProfile = schools.find(s => s.id === schoolGroup.uid);
                
                return (
                <div key={schoolGroup.uid} className="bg-white rounded-[32px] border border-black/5 shadow-sm hover:shadow-xl transition-all duration-500 overflow-hidden flex flex-col sm:flex-row group">
                  <div className="relative w-full sm:w-1/3 overflow-hidden bg-gray-50 flex items-center justify-center border-r border-black/5 min-h-[200px]">
                    {schoolProfile?.avatarBase64 ? (
                      <img src={schoolProfile.avatarBase64} alt="School" className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    ) : (
                      <div className="p-8 text-center relative z-10">
                        <School size={48} className="text-gray-300 mx-auto mb-4" />
                      </div>
                    )}
                    <div className="absolute top-4 left-4 z-20">
                      <span className="bg-radiant-pink text-white text-[9px] font-bold uppercase tracking-widest px-3 py-1 rounded-full shadow-lg flex items-center gap-1 justify-center">
                        <CheckCircle size={10} />
                        Verified
                      </span>
                    </div>
                  </div>

                  {/* Content Section */}
                  <div className="flex-1 p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="text-xl font-serif font-bold text-gray-900 group-hover:text-radiant-pink transition-colors leading-tight">
                          {schoolProfile?.displayName || schoolGroup.schoolName}
                        </h4>
                      </div>
                      <div className="space-y-1 mb-6">
                        <p className="text-[10px] text-gray-500 flex items-center gap-1 font-medium uppercase tracking-wider">
                          <MapPin size={12} className="text-radiant-pink shrink-0" />
                          {schoolProfile?.onboardingData?.school_location?.city || schoolGroup.location?.city || "Local Area"}, {schoolProfile?.onboardingData?.school_location?.country || schoolGroup.location?.country || "Region"}
                        </p>
                        <p className="text-[10px] text-gray-500 flex items-center gap-1 font-medium uppercase tracking-wider">
                          <Users size={12} className="text-radiant-pink shrink-0" />
                          {schoolProfile?.onboardingData?.student_count?.totalStudents || "450"} Students
                        </p>
                      </div>

                      {/* Needs List */}
                      <div className="space-y-3 bg-gray-50 rounded-2xl p-4">
                        <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Requested Items</p>
                        {schoolGroup.requests.map((req: any) => (
                          <div key={req.id} className="flex justify-between items-center bg-white p-3 rounded-xl border border-black/5">
                            <div>
                               <span className="text-sm font-bold text-gray-900 block">{req.productType}</span>
                               <span className={cn(
                                 "text-[9px] font-bold uppercase tracking-widest",
                                 req.urgency === "high" ? "text-red-500" : "text-orange-500"
                               )}>
                                 {req.urgency || "medium"} priority
                               </span>
                            </div>
                            <div className="text-right">
                              <span className="text-lg font-serif text-radiant-pink">{req.quantity}</span>
                              <span className="text-[10px] text-gray-400 block uppercase tracking-widest font-bold">Needed</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-6 space-y-2">
                      <button 
                         disabled={profile?.isVerified === false}
                         onClick={() => {
                           schoolGroup.requests.forEach((r: any) => handleUpdateStatus(r.id, "approved"));
                         }}
                         className={cn(
                           "w-full py-3 rounded-2xl text-[10px] font-bold uppercase tracking-widest transition-all",
                           profile?.isVerified === false 
                             ? "bg-gray-200 text-gray-400 cursor-not-allowed" 
                             : "bg-radiant-pink text-white hover:bg-radiant-pink/90 hover:scale-[1.02] active:scale-95 shadow-lg shadow-radiant-pink/20"
                         )}
                      >
                         {profile?.isVerified === false ? "Verification Required to Donate" : "Approve & Donate"}
                      </button>
                      
                      {activeRequestTab === "pending" && profile?.isVerified !== false && (
                        <div className="flex gap-2 mt-2">
                          <button 
                            onClick={() => {
                              setSelectedRequestId(schoolGroup.requests[0].id);
                              setShowRejectionModal(true);
                            }}
                            className="w-full py-2 bg-gray-50 border border-gray-200 rounded-xl text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-red-500 hover:bg-red-50 transition-colors"
                          >
                            Decline All
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            });
          })()}

            {displayRequests.length === 0 && (
              <div className="col-span-full py-20 text-center">
                <div className="w-20 h-20 bg-radiant-bg rounded-full flex items-center justify-center text-radiant-pink mx-auto mb-6">
                  <Search size={40} />
                </div>
                <h3 className="text-2xl font-serif mb-2">No matching requests</h3>
                <p className="text-gray-500">Try adjusting your search or filters to find schools in need.</p>
              </div>
            )}
          </div>
        </div>
      </section>
      ) : activeTab === "donations" ? (
        <section className="animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-serif">Outgoing Donations Log</h3>
            <button 
              onClick={() => setShowDonationModal(true)}
              className="bg-radiant-pink text-white px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform flex items-center gap-2"
            >
              <Plus size={14} />
              Log Donation
            </button>
          </div>
          <div className="space-y-3">
            {donations.map((donation) => (
              <div key={donation.id} className="bg-white p-4 rounded-[20px] border border-black/5 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center",
                    donation.status === "shipped" ? "bg-green-50 text-green-600" : "bg-radiant-bg text-radiant-pink"
                  )}>
                    {donation.status === "shipped" ? <CheckCircle size={20} /> : <TrendingUp size={20} />}
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">
                      {donation.productType} ({donation.amount})
                    </h4>
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider">
                      Target: {donation.donorType === "school" ? donation.schoolName : "Individual"}
                      {donation.brand && ` • Brand: ${donation.brand}`}
                    </p>
                    {donation.urgency && (
                      <p className="text-[9px] text-radiant-pink font-bold uppercase tracking-widest mt-0.5">
                        Urgency: {donation.urgency}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400">
                    {donation.timestamp?.toDate().toLocaleDateString()}
                  </div>
                  {donation.status === "approved" && (
                    <button
                      onClick={() => handleShipDonation(donation.id)}
                      className="px-3 py-1 bg-radiant-pink text-white text-[9px] font-bold uppercase tracking-widest rounded-full hover:scale-105 transition-transform shadow-sm"
                    >
                      Ship Now
                    </button>
                  )}
                </div>
              </div>
            ))}
            {donations.length === 0 && (
              <p className="text-center py-12 text-gray-400 italic text-sm">No donations logged yet. Start by logging one!</p>
            )}
          </div>
        </section>
      ) : (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="bg-white p-8 rounded-[32px] border border-black/5 shadow-sm max-w-2xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <Settings className="text-radiant-pink" size={24} />
              <h3 className="text-xl font-serif">NGO Settings</h3>
            </div>
            <form onSubmit={handleSaveProfile} className="space-y-6">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2 block">Organization Name</label>
                <input 
                  type="text"
                  required
                  value={editProfile.displayName}
                  onChange={(e) => setEditProfile({ ...editProfile, displayName: e.target.value })}
                  className="w-full p-4 rounded-2xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2 block">City</label>
                  <input 
                    type="text"
                    required
                    value={editProfile.ngo_location.city}
                    onChange={(e) => setEditProfile({ 
                      ...editProfile, 
                      ngo_location: { ...editProfile.ngo_location, city: e.target.value }
                    })}
                    className="w-full p-4 rounded-2xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2 block">Country</label>
                  <input 
                    type="text"
                    required
                    value={editProfile.ngo_location.country}
                    onChange={(e) => setEditProfile({ 
                      ...editProfile, 
                      ngo_location: { ...editProfile.ngo_location, country: e.target.value }
                    })}
                    className="w-full p-4 rounded-2xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2 block">Street Address</label>
                <input 
                  type="text"
                  required
                  value={editProfile.ngo_location.address}
                  onChange={(e) => setEditProfile({ 
                    ...editProfile, 
                    ngo_location: { ...editProfile.ngo_location, address: e.target.value }
                  })}
                  className="w-full p-4 rounded-2xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                />
              </div>

              <button 
                type="submit"
                disabled={isSavingProfile}
                className={cn(
                  "w-full py-4 rounded-full text-sm font-medium shadow-lg transition-all transform hover:scale-[1.02]",
                  saveSuccess 
                    ? "bg-green-500 text-white shadow-green-500/20" 
                    : "bg-radiant-pink text-white shadow-radiant-pink/20"
                )}
              >
                {isSavingProfile ? "Saving..." : saveSuccess ? "Settings Saved!" : "Save NGO Profile"}
              </button>
            </form>
          </div>
        </div>
      )}

      {showDonationModal && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl"
          >
            <h2 className="text-2xl font-serif mb-6">Log Donation</h2>
            
            {donationStep === 1 && (
              <div className="space-y-6">
                <p className="text-sm text-gray-500 italic">Who is this donation for?</p>
                <div className="grid gap-4">
                  <button
                    onClick={() => {
                      setNewDonation({ ...newDonation, donorType: "school" });
                      setDonationStep(2);
                    }}
                    className="flex items-center gap-4 p-6 bg-radiant-bg rounded-2xl hover:bg-radiant-pink/5 border border-black/5 transition-all text-left group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-radiant-pink shadow-sm group-hover:bg-radiant-pink group-hover:text-white transition-all">
                      <School size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold">School</h4>
                      <p className="text-xs text-gray-400">Donating to a specific educational institution.</p>
                    </div>
                  </button>
                  <button
                    onClick={() => {
                      setNewDonation({ ...newDonation, donorType: "individual" });
                      setDonationStep(2);
                    }}
                    className="flex items-center gap-4 p-6 bg-radiant-bg rounded-2xl hover:bg-radiant-pink/5 border border-black/5 transition-all text-left group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-radiant-pink shadow-sm group-hover:bg-radiant-pink group-hover:text-white transition-all">
                      <User size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold">Individual</h4>
                      <p className="text-xs text-gray-400">Direct support for a single student or person.</p>
                    </div>
                  </button>
                </div>
                <button 
                  onClick={() => setShowDonationModal(false)}
                  className="w-full py-3 text-sm font-medium text-gray-400 hover:text-gray-600"
                >
                  Cancel
                </button>
              </div>
            )}

            {donationStep === 2 && (
              <form onSubmit={handleSubmitDonation} className="space-y-4">
                {newDonation.donorType === "school" && (
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">School Name</label>
                    <input 
                      type="text"
                      required
                      value={newDonation.schoolName}
                      onChange={(e) => setNewDonation({ ...newDonation, schoolName: e.target.value })}
                      placeholder="e.g. Radiant High"
                      className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                    />
                  </div>
                )}
                
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Product Type</label>
                  <select 
                    value={newDonation.productType}
                    onChange={(e) => setNewDonation({ ...newDonation, productType: e.target.value })}
                    className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                  >
                    <option>Sanitary Pads</option>
                    <option>Uniforms</option>
                    <option>Stationary</option>
                    <option>Hygiene Kits</option>
                    <option>Funds (USD)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Quantity / Amount</label>
                  <input 
                    type="number"
                    required
                    min="1"
                    value={newDonation.amount}
                    onChange={(e) => setNewDonation({ ...newDonation, amount: parseInt(e.target.value) })}
                    className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                  />
                </div>

                {(newDonation.productType === "Pads" || newDonation.productType === "Tampons" || newDonation.productType === "Sanitary Cups") && (
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Brand (Optional)</label>
                    <input 
                      type="text"
                      value={newDonation.brand}
                      onChange={(e) => setNewDonation({ ...newDonation, brand: e.target.value })}
                      placeholder="e.g. Always, Kotex"
                      className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                    />
                  </div>
                )}

                {newDonation.donorType === "school" && (
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 block">Urgency</label>
                    <select 
                      value={newDonation.urgency}
                      onChange={(e) => setNewDonation({ ...newDonation, urgency: e.target.value as any })}
                      className="w-full p-3 rounded-xl border border-black/5 bg-radiant-bg focus:outline-none focus:ring-2 focus:ring-radiant-pink/20"
                    >
                      <option value="within a week">Within a week</option>
                      <option value="within this month">Within this month</option>
                      <option value="within the next 2 months">Within the next 2 months</option>
                    </select>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <button 
                    type="button"
                    onClick={() => setDonationStep(1)}
                    className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                  >
                    Back
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-3 rounded-full text-sm font-medium bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform"
                  >
                    Log Donation
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      )}

      {showRejectionModal && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl"
          >
            {rejectionStep === "reason" ? (
              <div className="space-y-4">
                <h2 className="text-2xl font-serif">Decline Request</h2>
                <p className="text-sm text-gray-500">Please provide a reason for declining this request.</p>
                <textarea 
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Reason for rejection..."
                  className="w-full p-4 rounded-2xl border border-black/5 bg-radiant-bg h-32 focus:outline-none focus:ring-2 focus:ring-radiant-pink/20 text-sm"
                />
                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowRejectionModal(false)}
                    className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    disabled={!rejectionReason.trim()}
                    onClick={() => setRejectionStep("confirm")}
                    className="flex-1 py-3 rounded-full text-sm font-medium bg-red-500 text-white shadow-lg shadow-red-500/20 hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100"
                  >
                    Next
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6 text-center">
                <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center text-red-500 mx-auto">
                  <AlertCircle size={32} />
                </div>
                <div className="space-y-2">
                  <h2 className="text-2xl font-serif">Are you sure?</h2>
                  <p className="text-sm text-gray-500">
                    This will be recorded & may affect your reputation as a reliable donor.
                  </p>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setRejectionStep("reason")}
                    className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
                  >
                    Back
                  </button>
                  <button 
                    onClick={handleRejectRequest}
                    className="flex-1 py-3 rounded-full text-sm font-medium bg-red-500 text-white shadow-lg shadow-red-500/20 hover:scale-105 transition-transform"
                  >
                    Confirm Decline
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}

      {showInfoModal && selectedRequest && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl"
          >
            <h2 className="text-2xl font-serif mb-4">Request Details</h2>
            <div className="space-y-4">
              <div className="bg-radiant-bg p-4 rounded-2xl border border-black/5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">School</p>
                <p className="font-serif italic text-radiant-pink text-lg">{selectedRequest.schoolName || "Requesting School"}</p>
              </div>
              <div className="bg-radiant-bg p-4 rounded-2xl border border-black/5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Product</p>
                <p className="font-medium">{selectedRequest.productType}</p>
              </div>
              <div className="bg-radiant-bg p-4 rounded-2xl border border-black/5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Quantity</p>
                <p className="font-medium">{selectedRequest.quantity}</p>
              </div>
              {selectedRequest.location && (
                <div className="bg-radiant-bg p-4 rounded-2xl border border-black/5">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Location</p>
                  <p className="font-medium">{selectedRequest.location.city}, {selectedRequest.location.country}</p>
                  <p className="text-xs text-gray-500 mt-1">{selectedRequest.location.address}</p>
                </div>
              )}
              <div className="bg-radiant-bg p-4 rounded-2xl border border-black/5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">Requested On</p>
                <p className="font-medium">{selectedRequest.timestamp?.toDate().toLocaleString()}</p>
              </div>
            </div>
            <button 
              onClick={() => setShowInfoModal(false)}
              className="w-full mt-6 py-3 rounded-full text-sm font-medium bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20 hover:scale-105 transition-transform"
            >
              Close
            </button>
          </motion.div>
        </div>
      )}

      {showResetConfirm && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl text-center"
          >
            <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center text-orange-500 mx-auto mb-4">
              <RefreshCw size={32} />
            </div>
            <h2 className="text-2xl font-serif mb-2">Reset Profile?</h2>
            <p className="text-sm text-gray-500 mb-6">
              This will clear all your onboarding data and sign you out. This action is permanent.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-3 rounded-full text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => resetUserData()}
                className="flex-1 py-3 rounded-full text-sm font-medium bg-orange-500 text-white shadow-lg shadow-orange-500/20 hover:scale-105 transition-transform"
              >
                Reset
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
