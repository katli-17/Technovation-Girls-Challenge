import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, ChevronLeft, Sparkles, Filter, ArrowRight, Play, BookOpen, Clock } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ALL_ARTICLES, CATEGORIES, Article } from "../data/resources";

interface ResourceHubProps {
  onBack: () => void;
  onArticleClick: (article: Article) => void;
  recentArticles: Article[];
}

export default function ResourceHub({ onBack, onArticleClick, recentArticles }: ResourceHubProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredArticles = useMemo(() => {
    return ALL_ARTICLES.filter(article => {
      const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          article.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory ? article.category === selectedCategory : true;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Search Header */}
      <div className="bg-white px-6 pt-12 pb-6 border-b border-gray-100 shadow-sm sticky top-0 z-20">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="p-2 -ml-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ChevronLeft size={24} className="text-gray-400" />
            </button>
            <h1 className="text-2xl font-serif">Topic Explorer</h1>
          </div>

          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
              type="text"
              placeholder="Search topics, articles, or feelage..."
              className="w-full bg-gray-100 border-none rounded-2xl py-4 pl-12 pr-4 text-sm focus:ring-2 focus:ring-radiant-pink/20 transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-2 px-2">
            <button 
              onClick={() => setSelectedCategory(null)}
              className={cn(
                "px-5 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap",
                !selectedCategory ? "bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20" : "bg-white text-gray-500 border border-gray-100"
              )}
            >
              All Topics
            </button>
            {CATEGORIES.map((cat) => (
              <button 
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  "px-5 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap",
                  selectedCategory === cat ? "bg-radiant-pink text-white shadow-lg shadow-radiant-pink/20" : "bg-white text-gray-500 border border-gray-100"
                )}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 max-w-4xl mx-auto w-full p-6 space-y-10 pb-32">
        {/* Recommendations */}
        {!searchQuery && !selectedCategory && recentArticles.length > 0 && (
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-radiant-pink" />
              <h2 className="text-lg font-serif">Picked for you</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {recentArticles.slice(0, 4).map((article) => (
                <motion.div 
                  key={article.id}
                  whileHover={{ y: -4 }}
                  onClick={() => onArticleClick(article)}
                  className="bg-white p-4 rounded-[24px] border border-gray-100 shadow-sm flex gap-4 cursor-pointer items-center"
                >
                  <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0">
                    <img src={article.img} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] uppercase tracking-widest text-radiant-pink font-bold">{article.category}</span>
                    </div>
                    <h3 className="text-sm font-bold truncate">{article.title}</h3>
                    <p className="text-[10px] text-gray-400 mt-1 flex items-center gap-1">
                      <Clock size={10} /> 3 min read
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        )}

        {/* Article Grid */}
        <section className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-serif">
              {selectedCategory || "Latest Topics"}
              <span className="text-gray-300 ml-2 text-sm">({filteredArticles.length})</span>
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {filteredArticles.map((article, i) => (
              <motion.div 
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ y: -5 }}
                onClick={() => onArticleClick(article)}
                className="bg-white rounded-[32px] overflow-hidden border border-gray-100 shadow-sm flex flex-col group cursor-pointer"
              >
                <div className="h-32 relative overflow-hidden">
                  <img 
                    src={article.img} 
                    alt="" 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                  />
                  <div className="absolute top-3 left-3">
                    <div className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-wider text-radiant-pink shadow-sm">
                      {article.category}
                    </div>
                  </div>
                </div>
                <div className="p-4 flex flex-col flex-1">
                  <h3 className="text-xs font-bold leading-tight mb-3 flex-1">{article.title}</h3>
                  <div className="flex items-center justify-between mt-auto">
                    <div className="flex items-center gap-1 text-[8px] text-gray-400 uppercase tracking-widest font-bold">
                      <BookOpen size={10} /> Read Life
                    </div>
                    <ArrowRight size={14} className="text-radiant-pink opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </div>
                </div>
              </motion.div>
            ))}

            {filteredArticles.length === 0 && (
              <div className="col-span-full py-20 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
                  <Search size={32} />
                </div>
                <h3 className="font-serif text-gray-500">No articles found</h3>
                <p className="text-xs text-gray-400 mt-1">Try a different search term or category</p>
                <button 
                  onClick={() => { setSearchQuery(""); setSelectedCategory(null); }}
                  className="mt-6 text-xs text-radiant-pink font-bold border-b border-radiant-pink"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
