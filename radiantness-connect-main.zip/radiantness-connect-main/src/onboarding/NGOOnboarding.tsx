import RoleOnboarding from "../components/RoleOnboarding";

interface NGOOnboardingProps {
  onComplete: (data: any) => void;
  onBack: () => void;
  onSignIn: () => void;
}

export default function NGOOnboarding({ onComplete, onBack, onSignIn }: NGOOnboardingProps) {
  return (
    <RoleOnboarding 
      role="ngo_business"
      onComplete={onComplete}
      onBack={onBack}
      onSignIn={onSignIn}
    />
  );
}
